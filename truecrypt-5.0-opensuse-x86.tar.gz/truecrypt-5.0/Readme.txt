This archive contains a TrueCrypt installation package (binaries) for Linux.



Installation
============

.RPM packages:
rpm -i truecrypt.rpm

.DEB packages:
dpkg -i truecrypt.deb



Uninstallation
==============

.RPM packages:
rpm -e truecrypt.rpm

.DEB packages:
dpkg -r truecrypt.deb



Documentation
=============

- /usr/share/truecrypt/doc/TrueCrypt User Guide.pdf

- http://www.truecrypt.org/docs/



What Is New in This Version of Truecrypt
========================================

For a comprehensive list of changes, please refer to the TrueCrypt User Guide
or visit http://www.truecrypt.org/history.php



Frequently Asked Questions
==========================

http://www.truecrypt.org/faq.php



Licensing Information
=====================

By installing and/or running and/or using and/or distributing and/or
modifying any part of this product you accept in full the responsibilities  
and obligations contained in the license whose text may be found in the file
'License.txt' in this package.



Further Information
===================

http://www.truecrypt.org/
