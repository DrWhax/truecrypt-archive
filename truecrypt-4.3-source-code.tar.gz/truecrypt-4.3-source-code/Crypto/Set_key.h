void des_set_odd_parity ( des_cblock (*key ));
int des_is_weak_key ( des_cblock (*key ));
int des_set_key ( des_cblock (*key ), des_key_schedule schedule );
int des_key_sched ( des_cblock (*key ), des_key_schedule schedule );
