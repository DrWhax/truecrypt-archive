//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Setup.rc
//
#define IDD_INSTALL                     101
#define IDI_ICON2                       103
#define IDD_UNINSTALL                   106
#define IDC_DESTINATION                 1000
#define IDC_BROWSE                      1001
#define IDC_LICENSE                     1003
#define IDC_FILES                       1006
#define IDC_FILE_TYPE                   1007
#define IDC_UNINSTALL                   1008
#define IDC_INSTRUCTION                 1009
#define IDC_PROG_GROUP                  1010
#define IDC_UNINSTALL2                  1011
#define IDC_SYSTEM_RESTORE              1011
#define IDC_PROG_GROUP2                 1012
#define IDC_DESKTOP_ICON                1012
#define IDC_PROG_GROUP3                 1014
#define IDC_ALL_USERS                   1014
#define IDI_SETUP                       25002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
