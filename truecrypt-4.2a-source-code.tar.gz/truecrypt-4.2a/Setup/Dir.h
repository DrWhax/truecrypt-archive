int mkfulldir ( char *path , BOOL bCheckonly );
int mkfulldir_internal ( char *path );
