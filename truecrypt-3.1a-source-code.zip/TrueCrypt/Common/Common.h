
#pragma once

typedef struct
{
	BOOL ReadOnly;
	BOOL Removable;
} MountOptions;
