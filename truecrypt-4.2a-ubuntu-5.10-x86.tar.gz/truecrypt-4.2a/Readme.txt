This archive contains TrueCrypt binaries for Linux.


Requirements
============

The Linux kernel with a configuration (e.g., smp) that is installed by default
with the Linux distribution, for which this package has been built for. If a
kernel with a non-default configuration (or a custom kernel) has been installed,
the TrueCrypt kernel module will most likely fail to load.



Installation
============

.RPM packages:
rpm -i truecrypt.rpm

.DEB packages:
dpkg -i truecrypt.deb



Uninstallation
==============

.RPM packages:
rpm -e truecrypt.rpm

.DEB packages:
dpkg -r truecrypt.deb



Non-Administrator Usage
=======================

TrueCrypt requires administrator (root) privileges. If you intend to
use TrueCrypt from a user account, you should execute the following command
as an administrator:

chmod u+s /usr/bin/truecrypt



Documentation
=============

http://www.truecrypt.org/docs/



What Is New in This Version of Truecrypt
========================================

For a comprehensive list of changes, please refer to the TrueCrypt User Guide
or visit http://www.truecrypt.org/history.php



Frequently Asked Questions
==========================

http://www.truecrypt.org/faq.php



Licensing Information
=====================

Before installing/running/using TrueCrypt, you must agree to the license
contained in the file 'License.txt'.



Further Information
===================

http://www.truecrypt.org/

