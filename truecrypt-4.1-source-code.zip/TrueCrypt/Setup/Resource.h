//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Setup.rc
//
#define IDD_INSTALL                     101
#define IDD_UNINSTALL                   102
#define IDI_SETUP                       103
#define IDR_SETUP_RSRC_HEADER           104
#define IDC_DESTINATION                 1000
#define IDC_BROWSE                      1001
#define IDC_LICENSE                     1002
#define IDC_FILES                       1003
#define IDC_FILE_TYPE                   1004
#define IDT_UNINSTALL_DIR               1005
#define IDC_PROG_GROUP                  1006
#define IDC_SYSTEM_RESTORE              1007
#define IDC_DESKTOP_ICON                1008
#define IDC_ALL_USERS                   1009
#define IDT_LICENSE                     1010
#define IDT_INSTALL_OPTIONS             1011
#define IDT_INSTALL_DIR                 1012
#define IDT_UNINSTALL_INFO              1013
#define IDC_UNINSTALL                   1014
#define IDC_INSTALL                     1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
