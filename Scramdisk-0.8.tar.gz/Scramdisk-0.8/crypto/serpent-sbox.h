/* -*-c-*-
 *
 * $Id: serpent-sbox.h,v 1.1 2005/05/22 20:10:22 huj Exp $
 *
 * Bitslice S-box implementations
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------* 
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 * 
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Credit where it's due ---------------------------------------------*
 *
 * These S-box expressions are taken from the paper `Speeding up Serpent', by
 * Dag Arne Osvik, submitted to AES3.
 */

#ifndef CATACOMB_SERPENT_SBOX_H
#define CATACOMB_SERPENT_SBOX_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include "bits.h"

/*----- Macros provided ---------------------------------------------------*/

/* --- @S0@ --- */

#define S0(r0, r1, r2, r3) do {						\
  uint32 r4;								\
  r3 ^= r0; r4  = r1; r1 &= r3; r4 ^= r2;				\
  r1 ^= r0; r0 |= r3; r0 ^= r4; r4 ^= r3;				\
  r3 ^= r2; r2 |= r1; r2 ^= r4; r4 = ~r4;				\
  r4 |= r1; r1 ^= r3; r1 ^= r4; r3 |= r0;				\
  r1 ^= r3; r4 ^= r3;							\
  r3 = r0; r0 = r1; r1 = r4;						\
} while (0)

#define IS0(r0, r1, r2, r3) do {					\
  uint32 r4;								\
  r2 = ~r2; r4  = r1; r1 |= r0; r4 = ~r4;				\
  r1 ^= r2; r2 |= r4; r1 ^= r3; r0 ^= r4;				\
  r2 ^= r0; r0 &= r3; r4 ^= r0; r0 |= r1;				\
  r0 ^= r2; r3 ^= r4; r2 ^= r1; r3 ^= r0;				\
  r3 ^= r1; r2 &= r3; r4 ^= r2;						\
  r2 = r1; r1 = r4;							\
} while (0)

/* --- @S1@ --- */

#define S1(r0, r1, r2, r3) do {						\
  uint32 r4;								\
  r0 = ~r0; r2 = ~r2; r4  = r0; r0 &= r1;				\
  r2 ^= r0; r0 |= r3; r3 ^= r2; r1 ^= r0;				\
  r0 ^= r4; r4 |= r1; r1 ^= r3; r2 |= r0;				\
  r2 &= r4; r0 ^= r1; r1 &= r2; r1 ^= r0;				\
  r0 &= r2; r0 ^= r4;							\
  r4 = r0; r0 = r2; r2 = r3; r3 = r1; r1 = r4;				\
} while (0)

#define IS1(r0, r1, r2, r3) do {					\
  uint32 r4;								\
  r4  = r1; r1 ^= r3; r3 &= r1; r4 ^= r2;				\
  r3 ^= r0; r0 |= r1; r2 ^= r3; r0 ^= r4;				\
  r0 |= r2; r1 ^= r3; r0 ^= r1; r1 |= r3;				\
  r1 ^= r0; r4 = ~r4; r4 ^= r1; r1 |= r0;				\
  r1 ^= r0; r1 |= r4; r3 ^= r1;						\
  r1 = r0; r0 = r4; r4 = r2; r2 = r3; r3 = r4;				\
} while (0)

/* --- @S2@ --- */

#define S2(r0, r1, r2, r3) do {						\
  uint32 r4;								\
  r4  = r0; r0 &= r2; r0 ^= r3; r2 ^= r1;				\
  r2 ^= r0; r3 |= r4; r3 ^= r1; r4 ^= r2;				\
  r1  = r3; r3 |= r4; r3 ^= r0; r0 &= r1;				\
  r4 ^= r0; r1 ^= r3; r1 ^= r4; r4 = ~r4;				\
  r0 = r2; r2 = r1; r1 = r3; r3 = r4;					\
} while (0)

#define IS2(r0, r1, r2, r3) do {					\
  uint32 r4;								\
  r2 ^= r3; r3 ^= r0; r4  = r3; r3 &= r2;				\
  r3 ^= r1; r1 |= r2; r1 ^= r4; r4 &= r3;				\
  r2 ^= r3; r4 &= r0; r4 ^= r2; r2 &= r1;				\
  r2 |= r0; r3 = ~r3; r2 ^= r3; r0 ^= r3;				\
  r0 &= r1; r3 ^= r4; r3 ^= r0;						\
  r0 = r1; r1 = r4;							\
} while (0)

/* --- @S3@ --- */

#define S3(r0, r1, r2, r3) do {						\
  uint32 r4;								\
  r4  = r0; r0 |= r3; r3 ^= r1; r1 &= r4;				\
  r4 ^= r2; r2 ^= r3; r3 &= r0; r4 |= r1;				\
  r3 ^= r4; r0 ^= r1; r4 &= r0; r1 ^= r3;				\
  r4 ^= r2; r1 |= r0; r1 ^= r2; r0 ^= r3;				\
  r2  = r1; r1 |= r3; r1 ^= r0;						\
  r0 = r1; r1 = r2; r2 = r3; r3 = r4;					\
} while (0)

#define IS3(r0, r1, r2, r3) do {					\
  uint32 r4;								\
  r4  = r2; r2 ^= r1; r0 ^= r2; r4 &= r2;				\
  r4 ^= r0; r0 &= r1; r1 ^= r3; r3 |= r4;				\
  r2 ^= r3; r0 ^= r3; r1 ^= r4; r3 &= r2;				\
  r3 ^= r1; r1 ^= r0; r1 |= r2; r0 ^= r3;				\
  r1 ^= r4; r0 ^= r1;							\
  r4 = r0; r0 = r2; r2 = r3; r3 = r4;					\
} while (0)

/* --- @S4@ --- */

#define S4(r0, r1, r2, r3) do {						\
  uint32 r4;								\
  r1 ^= r3; r3 = ~r3; r2 ^= r3; r3 ^= r0;				\
  r4  = r1; r1 &= r3; r1 ^= r2; r4 ^= r3;				\
  r0 ^= r4; r2 &= r4; r2 ^= r0; r0 &= r1;				\
  r3 ^= r0; r4 |= r1; r4 ^= r0; r0 |= r3;				\
  r0 ^= r2; r2 &= r3; r0 = ~r0; r4 ^= r2;				\
  r2 = r0; r0 = r1; r1 = r4;						\
} while (0)

#define IS4(r0, r1, r2, r3) do {					\
  uint32 r4;								\
  r4  = r2; r2 &= r3; r2 ^= r1; r1 |= r3;				\
  r1 &= r0; r4 ^= r2; r4 ^= r1; r1 &= r2;				\
  r0 = ~r0; r3 ^= r4; r1 ^= r3; r3 &= r0;				\
  r3 ^= r2; r0 ^= r1; r2 &= r0; r3 ^= r0;				\
  r2 ^= r4, r2 |= r3; r3 ^= r0; r2 ^= r1;				\
  r1 = r3; r3 = r4;							\
} while (0)

/* --- @S5@ --- */

#define S5(r0, r1, r2, r3) do {						\
  uint32 r4;								\
  r0 ^= r1; r1 ^= r3; r3 = ~r3; r4  = r1;				\
  r1 &= r0; r2 ^= r3; r1 ^= r2; r2 |= r4;				\
  r4 ^= r3; r3 &= r1; r3 ^= r0; r4 ^= r1;				\
  r4 ^= r2; r2 ^= r0; r0 &= r3; r2 = ~r2;				\
  r0 ^= r4; r4 |= r3; r2 ^= r4;						\
  r4 = r3; r3 = r2; r2 = r0; r0 = r1; r1 = r4;				\
} while (0)

#define IS5(r0, r1, r2, r3) do {					\
  uint32 r4;								\
  r1 = ~r1; r4  = r3; r2 ^= r1; r3 |= r0;				\
  r3 ^= r2; r2 |= r1; r2 &= r0; r4 ^= r3;				\
  r2 ^= r4; r4 |= r0; r4 ^= r1; r1 &= r2;				\
  r1 ^= r3; r4 ^= r2; r3 &= r4; r4 ^= r1;				\
  r3 ^= r4; r4 = ~r4; r3 ^= r0;						\
  r0 = r1; r1 = r4; r4 = r3; r3 = r2; r2 = r4;				\
} while (0)

/* --- @S6@ --- */

#define S6(r0, r1, r2, r3) do {						\
  uint32 r4;								\
  r2 = ~r2; r4  = r3; r3 &= r0; r0 ^= r4;				\
  r3 ^= r2; r2 |= r4; r1 ^= r3; r2 ^= r0;				\
  r0 |= r1; r2 ^= r1; r4 ^= r0; r0 |= r3;				\
  r0 ^= r2; r4 ^= r3; r4 ^= r0; r3 = ~r3;				\
  r2 &= r4; r2 ^= r3;							\
  r3 = r2; r2 = r4;							\
} while (0)

#define IS6(r0, r1, r2, r3) do {					\
  uint32 r4;								\
  r0 ^= r2; r4  = r2; r2 &= r0; r4 ^= r3;				\
  r2 = ~r2; r3 ^= r1; r2 ^= r3; r4 |= r0;				\
  r0 ^= r2; r3 ^= r4; r4 ^= r1; r1 &= r3;				\
  r1 ^= r0; r0 ^= r3; r0 |= r2; r3 ^= r1;				\
  r4 ^= r0;								\
  r0 = r1; r1 = r2; r2 = r4;						\
} while (0)

/* --- @S7@ --- */

#define S7(r0, r1, r2, r3) do {						\
  uint32 r4;								\
  r4  = r1; r1 |= r2; r1 ^= r3; r4 ^= r2;				\
  r2 ^= r1; r3 |= r4; r3 &= r0; r4 ^= r2;				\
  r3 ^= r1; r1 |= r4; r1 ^= r0; r0 |= r4;				\
  r0 ^= r2; r1 ^= r4; r2 ^= r1; r1 &= r0;				\
  r1 ^= r4; r2 = ~r2; r2 |= r0; r4 ^= r2;				\
  r2 = r1; r1 = r3; r3 = r0; r0 = r4;					\
} while (0)

#define IS7(r0, r1, r2, r3) do {					\
  uint32 r4;								\
  r4  = r2; r2 ^= r0; r0 &= r3; r4 |= r3;				\
  r2 = ~r2; r3 ^= r1; r1 |= r0; r0 ^= r2;				\
  r2 &= r4; r3 &= r4; r1 ^= r2; r2 ^= r0;				\
  r0 |= r2; r4 ^= r1; r0 ^= r3; r3 ^= r4;				\
  r4 |= r0; r3 ^= r2; r4 ^= r2;						\
  r2 = r1; r1 = r0; r0 = r3; r3 = r4;					\
} while (0)

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
