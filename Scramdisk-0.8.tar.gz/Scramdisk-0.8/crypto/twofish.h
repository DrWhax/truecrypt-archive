/* -*-c-*-
 *
 * $Id: twofish.h,v 1.1 2005/05/22 20:10:22 huj Exp $
 *
 * The Twofish block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------* 
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 * 
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the Twofish block cipher ---------------------------------*
 *
 * Twofish was designed by Bruce Schneier, John Kelsey, Doug Whiting, David
 * Wagner, Chris Hall and Niels Ferguson.  The algorithm is unpatented and
 * free for anyone to use.  It was one of the five AES finalist algorithms.
 *
 * Twofish is a complex cipher offering various space and time tradeoffs.
 * This implementation has a heavy key schedule and fast bulk encryption.
 */

#ifndef CATACOMB_TWOFISH_H
#define CATACOMB_TWOFISH_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifdef __KERNEL__
#include <linux/types.h>
#else
#include <sys/types.h>
#endif

#include "bits.h"

/*----- Magical numbers ---------------------------------------------------*/

#define TWOFISH_BLKSZ 16
#define TWOFISH_KEYSZ 32
#define TWOFISH_CLASS (N, L, 128)

extern const octet twofish_keysz[];

/*----- Data structures ---------------------------------------------------*/

typedef struct twofish_ctx {
  uint32 k[40];
  uint32 g[4][256];
} twofish_ctx;

typedef struct twofish_fk {
  uint32 t0[8], t23[8], t4[2];
  octet t1[32];
} twofish_fk;

/*----- Functions provided ------------------------------------------------*/

/* --- @twofish_initfk@ --- *
 *
 * Arguments:	@twofish_ctx *k@ = pointer to key block to fill in
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of key material
 *		@const twofish_fk *fk@ = family-key information
 *
 * Returns:	---
 *
 * Use:		Does the underlying Twofish key initialization with family
 *		key.  Pass in a family-key structure initialized to
 *		all-bits-zero for a standard key schedule.
 */

extern void twofish_initfk(twofish_ctx* /*k*/, const void* /*buf*/,
			   size_t /*sz*/, const twofish_fk* /*fk*/);

/* --- @twofish_init@ --- *
 *
 * Arguments:	@twofish_ctx *k@ = pointer to key block to fill in
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Twofish key buffer.  Twofish accepts keys of up
 *		to 256 bits in length.
 */

extern void twofish_init(twofish_ctx* /*k*/,
			 const void* /*buf*/, size_t /*sz*/);

/* --- @twofish_fkinit@ --- *
 *
 * Arguments:	@twofish_fk *fk@ = pointer to family key block
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a family-key buffer.  This implementation allows
 *		family keys of any size acceptable to the Twofish algorithm.
 */

extern void twofish_fkinit(twofish_fk* /*fk*/,
			   const void* /*buf*/, size_t /*sz*/);

/* --- @twofish_eblk@, @twofish_dblk@ --- *
 *
 * Arguments:	@const twofish_ctx *k@ = pointer to key block
 *		@const uint32 s[4]@ = pointer to source block
 *		@uint32 d[4]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void twofish_eblk(const twofish_ctx* /*k*/,
			 const uint32* /*s*/, uint32* /*d*/);

extern void twofish_dblk(const twofish_ctx* /*k*/,
			 const uint32* /*s*/, uint32* /*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
