/* -*-c-*-
 *
 * $Id: serpent.h,v 1.1 2005/05/22 20:10:22 huj Exp $
 *
 * The Serpent block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------* 
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 * 
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the Serpent block cipher ---------------------------------*
 *
 * Serpent was designed and proposed for the AES contest by Ross Anderson,
 * Eli Biham and Lars Knudsen.  It's not particularly quick, but is
 * stunningly secure.  The best differential and linear attacks are
 * speculated to require %$2^{256}$% texts (it's a 128-bit block cipher).
 * The designers originally intended to file a patent, but failed to persue
 * it.  Use of the algorithm is completely unencumbered.
 */

#ifndef CATACOMB_SERPENT_H
#define CATACOMB_SERPENT_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifdef __KERNEL__
#include <linux/types.h>
#else
#include <sys/types.h>
#endif

#include "bits.h"

/*----- Magic numbers -----------------------------------------------------*/

#define SERPENT_BLKSZ 16
#define SERPENT_KEYSZ 32
#define SERPENT_CLASS (N, L, 128)

extern const octet serpent_keysz[];

/*----- Data structures ---------------------------------------------------*/

typedef struct serpent_ctx {
  uint32 k[4 * 33];
} serpent_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @serpent_init@ --- *
 *
 * Arguments:	@serpent_ctx *k@ = pointer to context block to initialize
 *		@const void *buf@ = pointer to input buffer
 *		@size_t sz@ = size of input buffer
 *
 * Returns:	---
 *
 * Use:		Initializes a Serpent context.  The key may be any length of
 *		up to 32 bytes (256 bits).
 */

extern void serpent_init(serpent_ctx* /*k*/,
			 const void* /*buf*/, size_t /*sz*/);

/* --- @serpent_eblk@, @serpent_dblk@ --- *
 *
 * Arguments:	@const serpent_ctx *k@ = pointer to key context
 *		@const uint32 s[4]@ = pointer to source block
 *		@uint32 d[4]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption.
 */

extern void serpent_eblk(const serpent_ctx* /*k*/,
			 const uint32* /*s*/, uint32* /*d*/);
extern void serpent_dblk(const serpent_ctx* /*k*/,
			 const uint32* /*s*/, uint32* /*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
