/*----- Licensing notice --------------------------------------------------* 
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 * 
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the RIPEMD-160 hash function -----------------------------*
 *
 * RIPEMD-160 was invented by Hans Dobbertin, Antoon Bosselaers and Bart
 * Preneel.  It's a strengthened version of the original RIPEMD hash
 * function, fixing a vulnerability discovered by Hans Dobbertin.  The
 * RIPEMD-160 design team appears well respected in the cryptographic
 * community.  The author finds them more plausible than SHA-1, which is the
 * best alternative hash function.
 */

#ifndef CATACOMB_RMD160_H
#define CATACOMB_RMD160_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifdef __KERNEL__
#include <linux/types.h>
#else
#include <sys/types.h>
#endif

#include "bits.h"

/*----- Magic numbers -----------------------------------------------------*/

#define RMD160_BUFSZ 64
#define RMD160_HASHSZ 20
#define RMD160_STATESZ 20

/*----- Data structures ---------------------------------------------------*/

typedef struct rmd160_ctx {
  uint32 a, b, c, d, e;			/* Chaining variables */
  uint32 nl, nh;			/* Byte count so far */
  unsigned off;				/* Offset into buffer */
  octet buf[RMD160_BUFSZ];		/* Accumulation buffer */
} rmd160_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @rmd160_compress@ --- *
 *
 * Arguments:	@rmd160_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		RIPEMD-160 compression function.
 */

extern void rmd160_compress(rmd160_ctx* /*ctx*/, const void* /*sbuf*/);

/* --- @rmd160_init@ --- *
 *
 * Arguments:	@rmd160_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

extern void rmd160_init(rmd160_ctx* /*ctx*/);

/* --- @rmd160_set@ --- *
 *
 * Arguments:	@rmd160_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

extern void rmd160_set(rmd160_ctx* /*ctx*/,
		       const void */*buf*/, unsigned long /*count*/);

/* --- @rmd160_hash@ --- *
 *
 * Arguments:	@rmd160_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

extern void rmd160_hash(rmd160_ctx* /*ctx*/,
			const void */*buf*/, size_t /*sz*/);

/* --- @rmd160_done@ --- *
 *
 * Arguments:	@rmd160_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

extern void rmd160_done(rmd160_ctx* /*ctx*/, void* /*hash*/);

/* --- @rmd160_state@ --- *
 *
 * Arguments:	@rmd160_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @rmd160_set@.
 */

extern unsigned long rmd160_state(rmd160_ctx* /*ctx*/, void* /*state*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
