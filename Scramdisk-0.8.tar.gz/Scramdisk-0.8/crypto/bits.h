/* -*-c-*-
 *
 * $Id: bits.h,v 1.1 2005/05/22 20:10:22 huj Exp $
 *
 * Portable bit-level manipulation macros
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------* 
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 * 
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef SD_BITS_H
#define SD_BITS_H

typedef unsigned char octet;
typedef unsigned short uint16;
typedef unsigned int uint32;

/* --- Useful masks --- */

#define MASK8 0xffu
#define MASK16 0xffffu
#define MASK24 0xffffffu
#define MASK32 0xffffffffu

/* --- Type coercions --- */

#define U8(x) ((octet)((x) & MASK8))
#define U16(x) ((uint16)((x) & MASK16))
#define U24(x) ((uint24)((x) & MASK24))
#define U32(x) ((uint32)((x) & MASK32))

/* --- Safe shifting macros --- */

#define LSL8(v, s) U8(U8(v) << ((s) & 7u))
#define LSR8(v, s) U8(U8(v) >> ((s) & 7u))
#define LSL16(v, s) U16(U16(v) << ((s) & 15u))
#define LSR16(v, s) U16(U16(v) >> ((s) & 15u))
#define LSL24(v, s) U24(U24(v) << ((s) % 24u))
#define LSR24(v, s) U24(U24(v) >> ((s) % 24u))
#define LSL32(v, s) U32(U32(v) << ((s) & 31u))
#define LSR32(v, s) U32(U32(v) >> ((s) & 31u))

/* --- Rotation macros --- */

#define ROL8(v, s) (LSL8((v), (s)) | (LSR8((v), 8u - (s))))
#define ROR8(v, s) (LSR8((v), (s)) | (LSL8((v), 8u - (s))))
#define ROL16(v, s) (LSL16((v), (s)) | (LSR16((v), 16u - (s))))
#define ROR16(v, s) (LSR16((v), (s)) | (LSL16((v), 16u - (s))))
#define ROL24(v, s) (LSL24((v), (s)) | (LSR24((v), 24u - (s))))
#define ROR24(v, s) (LSR24((v), (s)) | (LSL24((v), 24u - (s))))
#define ROL32(v, s) (LSL32((v), (s)) | (LSR32((v), 32u - (s))))
#define ROR32(v, s) (LSR32((v), (s)) | (LSL32((v), 32u - (s))))

/* --- Storage and retrieval --- */

#define GETBYTE(p, o) (((octet *)(p))[o] & MASK8)
#define PUTBYTE(p, o, v) (((octet *)(p))[o] = U8((v)))

#define LOAD8(p) (GETBYTE((p), 0))
#define STORE8(p, v) (PUTBYTE((p), 0, (v)))

#define LOAD16_B(p) \
  (((uint16)GETBYTE((p), 0) << 8) | \
   ((uint16)GETBYTE((p), 1) << 0))
#define LOAD16_L(p) \
  (((uint16)GETBYTE((p), 0) << 0) | \
   ((uint16)GETBYTE((p), 1) << 8))
#define LOAD16(p) LOAD16_B((p))

#define STORE16_B(p, v) \
  (PUTBYTE((p), 0, (uint16)(v) >> 8), \
   PUTBYTE((p), 1, (uint16)(v) >> 0))
#define STORE16_L(p, v) \
  (PUTBYTE((p), 0, (uint16)(v) >> 0), \
   PUTBYTE((p), 1, (uint16)(v) >> 8))
#define STORE16(p, v) STORE16_B((p), (v))

#define LOAD24_B(p) \
  (((uint24)GETBYTE((p), 0) << 16) | \
   ((uint24)GETBYTE((p), 1) <<  8) | \
   ((uint24)GETBYTE((p), 2) <<  0))
#define LOAD24_L(p) \
  (((uint24)GETBYTE((p), 0) <<  0) | \
   ((uint24)GETBYTE((p), 1) <<  8) | \
   ((uint24)GETBYTE((p), 2) << 16))
#define LOAD24(p) LOAD24_B((p))

#define STORE24_B(p, v) \
  (PUTBYTE((p), 0, (uint24)(v) >> 16), \
   PUTBYTE((p), 1, (uint24)(v) >>  8), \
   PUTBYTE((p), 2, (uint24)(v) >>  0))
#define STORE24_L(p, v) \
  (PUTBYTE((p), 0, (uint24)(v) >>  0), \
   PUTBYTE((p), 1, (uint24)(v) >>  8), \
   PUTBYTE((p), 2, (uint24)(v) >> 16))
#define STORE24(p, v) STORE24_B((p), (v))

#define LOAD32_B(p) \
  (((uint32)GETBYTE((p), 0) << 24) | \
   ((uint32)GETBYTE((p), 1) << 16) | \
   ((uint32)GETBYTE((p), 2) <<  8) | \
   ((uint32)GETBYTE((p), 3) <<  0))
#define LOAD32_L(p) \
  (((uint32)GETBYTE((p), 0) <<  0) | \
   ((uint32)GETBYTE((p), 1) <<  8) | \
   ((uint32)GETBYTE((p), 2) << 16) | \
   ((uint32)GETBYTE((p), 3) << 24))
#define LOAD32(p) LOAD32_B((p))

#define STORE32_B(p, v) \
  (PUTBYTE((p), 0, (uint32)(v) >> 24), \
   PUTBYTE((p), 1, (uint32)(v) >> 16), \
   PUTBYTE((p), 2, (uint32)(v) >>  8), \
   PUTBYTE((p), 3, (uint32)(v) >>  0))
#define STORE32_L(p, v) \
  (PUTBYTE((p), 0, (uint32)(v) >>  0), \
   PUTBYTE((p), 1, (uint32)(v) >>  8), \
   PUTBYTE((p), 2, (uint32)(v) >> 16), \
   PUTBYTE((p), 3, (uint32)(v) >> 24))
#define STORE32(p, v) STORE32_B((p), (v))

#endif
