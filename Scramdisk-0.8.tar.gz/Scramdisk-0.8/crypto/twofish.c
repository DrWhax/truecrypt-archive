/* -*-c-*-
 *
 * $Id: twofish.c,v 1.1 2005/05/22 20:10:22 huj Exp $
 *
 * Implementation of the Twofish cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------* 
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 * 
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#ifdef __KERNEL__
#include <linux/string.h>
#else
#include <string.h>
#endif
#include "block.h"
#include "twofish.h"
#include "twofish-tab.h"

/*----- Global variables --------------------------------------------------*/

const octet twofish_keysz[] = { KSZ_RANGE, TWOFISH_KEYSZ, 0, 32, 1 };

/*----- Important tables --------------------------------------------------*/

static const octet q0[256] = TWOFISH_Q0, q1[256] = TWOFISH_Q1;
static const uint32 qmds[4][256] = TWOFISH_QMDS;
static const octet rslog[] = TWOFISH_RSLOG, rsexp[] = TWOFISH_RSEXP;
static const octet rs[32] = TWOFISH_RS;

/*----- Key initialization ------------------------------------------------*/

/* --- @h@ --- *
 *
 * Arguments:	@uint32 x@ = input to the function
 *		@const uint32 *l@ = key values to mix in
 *		@unsigned k@ = number of key values there are
 *
 * Returns:	The output of the function @h@.
 *
 * Use:		Implements the Twofish function @h@.
 */

static uint32 h(uint32 x, const uint32 *l, unsigned k)
{
  /* --- Apply a series of @q@ tables to an integer --- */

# define Q(x, qa, qb, qc, qd)						\
  ((qa[((x) >>  0) & 0xff] <<  0) |					\
   (qb[((x) >>  8) & 0xff] <<  8) |					\
   (qc[((x) >> 16) & 0xff] << 16) |					\
   (qd[((x) >> 24) & 0xff] << 24))

  /* --- Grind through the tables --- */

  switch (k) {
    case 4: x = Q(x, q1, q0, q0, q1) ^ l[3];
    case 3: x = Q(x, q1, q1, q0, q0) ^ l[2];
    case 2: x = Q(x, q0, q1, q0, q1) ^ l[1];
	    x = Q(x, q0, q0, q1, q1) ^ l[0];
      break;
  }

#undef Q

  /* --- Apply the MDS matrix --- */

  return (qmds[0][U8(x >>  0)] ^ qmds[1][U8(x >>  8)] ^
	  qmds[2][U8(x >> 16)] ^ qmds[3][U8(x >> 24)]);
}

/* --- @twofish_initfk@ --- *
 *
 * Arguments:	@twofish_ctx *k@ = pointer to key block to fill in
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of key material
 *		@const twofish_fk *fk@ = family-key information
 *
 * Returns:	---
 *
 * Use:		Does the underlying Twofish key initialization with family
 *		key.  Pass in a family-key structure initialized to
 *		all-bits-zero for a standard key schedule.
 */

void twofish_initfk(twofish_ctx *k, const void *buf, size_t sz,
		    const twofish_fk *fk)
{
# define KMAX 4

  uint32 mo[KMAX], me[KMAX];
  octet s[4][KMAX];

  /* --- Expand the key into the three word arrays --- */

  {
    size_t ssz;
    const octet *p, *q;
    octet b[32];
    int i;

    /* --- Sort out the key size --- */

    if (sz <= 16)
      ssz = 16;
    else if (sz <= 24)
      ssz = 24;
    else if (sz <= 32)
      ssz = 32;
    else
      return;

    /* --- Extend the key if necessary --- */

    if (sz == ssz)
      p = buf;
    else {
      memcpy(b, buf, sz);
      memset(b + sz, 0, ssz - sz);
      p = b;
    }

    /* --- Finally get the word count --- */

    sz = ssz / 8;

    /* --- Extract words from the key --- *
     *
     * The @s@ table, constructed using the Reed-Solomon matrix, is cut into
     * sequences of bytes, since this is actually more useful for computing
     * the S-boxes.
     */

    q = p;
    for (i = 0; i < sz; i++) {
      octet ss[4];
      const octet *r = rs;
      int j;

      /* --- Extract the easy subkeys --- */

      me[i] = LOAD32_L(q) ^ fk->t0[2 * i];
      mo[i] = LOAD32_L(q + 4) ^ fk->t0[2 * i + 1];

      /* --- Now do the Reed-Solomon thing --- */

      for (j = 0; j < 4; j++) {
	const octet *qq = q;
	unsigned a = 0;
	int k;

	for (k = 0; k < 8; k++) {
	  unsigned char x = *qq ^ fk->t1[i * 8 + k];
	  if (x) a ^= rsexp[rslog[x] + *r];
	  qq++;
	  r++;
	}
	
	s[j][sz - 1 - i] = ss[j] = a;
      }
      q += 8;
    }

    /* --- Clear away the temporary buffer --- */

    if (p == b)
      memset(&b, 0, sizeof(b));
  }

  /* --- Construct the expanded key --- */

  {
    uint32 p = 0x01010101;
    uint32 ip = 0;
    int i;

    for (i = 0; i < 40; i += 2) {
      uint32 a, b;
      a = h(ip, me, sz);
      b = h(ip + p, mo, sz);
      b = ROL32(b, 8);
      a += b; b += a;
      k->k[i] = U32(a);
      k->k[i + 1] = ROL32(b, 9);
      ip += 2 * p;
    }

    for (i = 0; i < 8; i++)
      k->k[i] ^= fk->t23[i];
    for (i = 8; i < 40; i += 2) {
      k->k[i] ^= fk->t4[0];
      k->k[i + 1] ^= fk->t4[1];
    }
  }

  /* --- Construct the S-box tables --- */

  {
    unsigned i;
    static const octet *q[4][KMAX + 1] = {
      { q1, q0, q0, q1, q1 },
      { q0, q0, q1, q1, q0 },
      { q1, q1, q0, q0, q0 },
      { q0, q1, q1, q0, q1 }
    };

    for (i = 0; i < 4; i++) {
      unsigned j;
      uint32 x;

      for (j = 0; j < 256; j++) {
	x = j;

	/* --- Push the byte through the q tables --- */

	switch (sz) {
	  case 4: x = q[i][4][x] ^ s[i][3];
	  case 3: x = q[i][3][x] ^ s[i][2];
	  case 2: x = q[i][2][x] ^ s[i][1];
		  x = q[i][1][x] ^ s[i][0];
	    break;
	}

	/* --- Write it in the key schedule --- */

	k->g[i][j] = qmds[i][x];
      }
    }
  }

  /* --- Clear everything away --- */

  memset(&me, 0, sizeof(me));
  memset(&mo, 0, sizeof(mo));
  memset(&s, 0, sizeof(s));
}

/* --- @twofish_init@ --- *
 *
 * Arguments:	@twofish_ctx *k@ = pointer to key block to fill in
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Twofish key buffer.  Twofish accepts key sizes
 *		of up to 256 bits (32 bytes).
 */

void twofish_init(twofish_ctx *k, const void *buf, size_t sz)
{
  static twofish_fk fk = { { 0 } };
  twofish_initfk(k, buf, sz, &fk);
}

/* --- @twofish_fkinit@ --- *
 *
 * Arguments:	@twofish_fk *fk@ = pointer to family key block
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a family-key buffer.  This implementation allows
 *		family keys of any size acceptable to the Twofish algorithm.
 */

void twofish_fkinit(twofish_fk *fk, const void *buf, size_t sz)
{
  twofish_ctx k;
  uint32 pt[4], ct[4];
  const octet *kk;
  unsigned i;

  twofish_init(&k, buf, sz);

  for (i = 0; i < 4; i++) pt[i] = (uint32)-1;
  twofish_eblk(&k, pt, fk->t0 + 4);

  kk = buf; sz /= 4;
  for (i = 0; i < sz; i++) { fk->t0[i] = LOAD32_L(kk); kk += 4; }

  for (i = 0; i < 4; i++) pt[i] = 0; twofish_eblk(&k, pt, ct);
  for (i = 0; i < 4; i++) STORE32_L(fk->t1 + i * 4, ct[i]);
  pt[0] = 1; twofish_eblk(&k, pt, ct);
  for (i = 0; i < 4; i++) STORE32_L(fk->t1 + 4 + i * 4, ct[i]);

  pt[0] = 2; twofish_eblk(&k, pt, fk->t23 + 0);
  pt[0] = 3; twofish_eblk(&k, pt, fk->t23 + 4);
  pt[0] = 4; twofish_eblk(&k, pt, ct);
  fk->t4[0] = ct[0]; fk->t4[1] = ct[1];

  memset(&k, 0, sizeof(k));
}

/*----- Main encryption ---------------------------------------------------*/

/* --- Feistel function --- */

#define GG(k, t0, t1, x, y, kk) do {					\
  t0 = (k->g[0][U8(x >>  0)] ^						\
	k->g[1][U8(x >>  8)] ^						\
	k->g[2][U8(x >> 16)] ^						\
	k->g[3][U8(x >> 24)]);						\
  t1 = (k->g[1][U8(y >>  0)] ^						\
	k->g[2][U8(y >>  8)] ^						\
	k->g[3][U8(y >> 16)] ^						\
	k->g[0][U8(y >> 24)]);						\
  t0 += t1;								\
  t1 += t0;								\
  t0 += kk[0];								\
  t1 += kk[1];								\
} while (0)

/* --- Round operations --- */

#define EROUND(k, w, x, y, z, kk) do {					\
  uint32 _t0, _t1;							\
  GG(k, _t0, _t1, w, x, kk);						\
  kk += 2;								\
  y ^= _t0; y = ROR32(y, 1);						\
  z = ROL32(z, 1); z ^= _t1;						\
} while (0)

#define DROUND(k, w, x, y, z, kk) do {					\
  uint32 _t0, _t1;							\
  kk -= 2;								\
  GG(k, _t0, _t1, w, x, kk);						\
  y = ROL32(y, 1); y ^= _t0;						\
  z ^= _t1; z = ROR32(z, 1);						\
} while (0)

/* --- Complete encryption functions --- */

#define EBLK(k, a, b, c, d, w, x, y, z) do {				\
  const uint32 *_kk = k->k + 8;						\
  uint32 _a = a, _b = b, _c = c, _d = d;				\
  _a ^= k->k[0]; _b ^= k->k[1]; _c ^= k->k[2]; _d ^= k->k[3];		\
  EROUND(k, _a, _b, _c, _d, _kk);					\
  EROUND(k, _c, _d, _a, _b, _kk);					\
  EROUND(k, _a, _b, _c, _d, _kk);					\
  EROUND(k, _c, _d, _a, _b, _kk);					\
  EROUND(k, _a, _b, _c, _d, _kk);					\
  EROUND(k, _c, _d, _a, _b, _kk);					\
  EROUND(k, _a, _b, _c, _d, _kk);					\
  EROUND(k, _c, _d, _a, _b, _kk);					\
  EROUND(k, _a, _b, _c, _d, _kk);					\
  EROUND(k, _c, _d, _a, _b, _kk);					\
  EROUND(k, _a, _b, _c, _d, _kk);					\
  EROUND(k, _c, _d, _a, _b, _kk);					\
  EROUND(k, _a, _b, _c, _d, _kk);					\
  EROUND(k, _c, _d, _a, _b, _kk);					\
  EROUND(k, _a, _b, _c, _d, _kk);					\
  EROUND(k, _c, _d, _a, _b, _kk);					\
  _c ^= k->k[4]; _d ^= k->k[5]; _a ^= k->k[6]; _b ^= k->k[7];		\
  w = U32(_c); x = U32(_d); y = U32(_a); z = U32(_b);			\
} while (0)

#define DBLK(k, a, b, c, d, w, x, y, z) do {				\
  const uint32 *_kk = k->k + 40;					\
  uint32 _a = a, _b = b, _c = c, _d = d;				\
  _a ^= k->k[4]; _b ^= k->k[5]; _c ^= k->k[6]; _d ^= k->k[7];		\
  DROUND(k, _a, _b, _c, _d, _kk);					\
  DROUND(k, _c, _d, _a, _b, _kk);					\
  DROUND(k, _a, _b, _c, _d, _kk);					\
  DROUND(k, _c, _d, _a, _b, _kk);					\
  DROUND(k, _a, _b, _c, _d, _kk);					\
  DROUND(k, _c, _d, _a, _b, _kk);					\
  DROUND(k, _a, _b, _c, _d, _kk);					\
  DROUND(k, _c, _d, _a, _b, _kk);					\
  DROUND(k, _a, _b, _c, _d, _kk);					\
  DROUND(k, _c, _d, _a, _b, _kk);					\
  DROUND(k, _a, _b, _c, _d, _kk);					\
  DROUND(k, _c, _d, _a, _b, _kk);					\
  DROUND(k, _a, _b, _c, _d, _kk);					\
  DROUND(k, _c, _d, _a, _b, _kk);					\
  DROUND(k, _a, _b, _c, _d, _kk);					\
  DROUND(k, _c, _d, _a, _b, _kk);					\
  _c ^= k->k[0]; _d ^= k->k[1]; _a ^= k->k[2]; _b ^= k->k[3];		\
  w = U32(_c); x = U32(_d); y = U32(_a); z = U32(_b);			\
} while (0)

/* --- @twofish_eblk@, @twofish_dblk@ --- *
 *
 * Arguments:	@const twofish_ctx *k@ = pointer to key block
 *		@const uint32 s[4]@ = pointer to source block
 *		@uint32 d[4]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

void twofish_eblk(const twofish_ctx *k, const uint32 *s, uint32 *d)
{
  EBLK(k, s[0], s[1], s[2], s[3], d[0], d[1], d[2], d[3]);
}

void twofish_dblk(const twofish_ctx *k, const uint32 *s, uint32 *d)
{
  DBLK(k, s[0], s[1], s[2], s[3], d[0], d[1], d[2], d[3]);
}

/*----- That's all, folks -------------------------------------------------*/
