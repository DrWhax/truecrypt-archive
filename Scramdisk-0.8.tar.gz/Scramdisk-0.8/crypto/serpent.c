/* -*-c-*-
 *
 * $Id: serpent.c,v 1.1 2005/05/22 20:10:22 huj Exp $
 *
 * The Serpent block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------* 
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 * 
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "block.h"
#include "serpent.h"
#include "serpent-sbox.h"

/*----- Global variables --------------------------------------------------*/

const octet serpent_keysz[] = { KSZ_RANGE, SERPENT_KEYSZ, 0, 32, 1 };

/*----- Main code ---------------------------------------------------------*/

/* --- @serpent_init@ --- *
 *
 * Arguments:	@serpent_ctx *k@ = pointer to context block to initialize
 *		@const void *buf@ = pointer to input buffer
 *		@size_t sz@ = size of input buffer
 *
 * Returns:	---
 *
 * Use:		Initializes a Serpent context.  The key may be any length of
 *		up to 32 bytes (256 bits).
 */

void serpent_init(serpent_ctx *k, const void *buf, size_t sz)
{
  uint32 a;
  unsigned b;
  const octet *p, *q;
  size_t i;
  uint32 pk[8 + 132];

  /* --- Read the key into the buffer --- */

  if (sz > 32)
    sz = 32;
  i = 0; p = buf; q = p + sz;
  a = 0; b = 0;
  while (p < q) {
    a |= (uint32)*p++ << b;
    b += 8;
    if (b == 32) {
      pk[i++] = a;
      a = 0; b = 0;
    }
  }

  /* --- Pad short keys --- */

  if (i < 8) {
    a |= 0x01 << b;
    b += 8;
    pk[i++] = a;
    for (; i < 8; i++)
      pk[i] = 0;
  }

  /* --- Expand the prekeys to fill the buffer --- */

  for (i = 8; i < 8 + 132; i++) {
    uint32 x = (pk[i - 8] ^ pk[i - 5] ^ pk[i - 3] ^ pk[i - 1] ^
		(i - 8) ^ 0x9e3779b9);
    k->k[i - 8] = pk[i] = ROL32(x, 11);
  }

  /* --- Now substitute everything --- */

  i = 0;
  goto midway;
  while (i < 132) {
#define KSUB(r) do {							\
    uint32 a, b, c, d;							\
    a = k->k[i]; b = k->k[i + 1]; c = k->k[i + 2]; d = k->k[i + 3];	\
    S##r(a, b, c, d);							\
    k->k[i] = a; k->k[i + 1] = b; k->k[i + 2] = c; k->k[i + 3] = d;	\
    i += 4;								\
} while (0)
    KSUB(2); KSUB(1); KSUB(0); KSUB(7);
    KSUB(6); KSUB(5); KSUB(4);
  midway:
    KSUB(3);
#undef KSUB
  }
}

/* --- @serpent_eblk@, @serpent_dblk@ --- *
 *
 * Arguments:	@const serpent_ctx *k@ = pointer to key context
 *		@const uint32 s[4]@ = pointer to source block
 *		@uint32 d[4]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption.
 */

#define EROUND(a, b, c, d, r, k) do {					\
  a ^= *k++; b ^= *k++; c ^= *k++; d ^= *k++;				\
  S##r(a, b, c, d);							\
  a = ROL32(a, 13); c = ROL32(c,  3); b ^= a ^ c; d ^= c ^ (a << 3);	\
  b = ROL32(b,  1); d = ROL32(d,  7); a ^= b ^ d; c ^= d ^ (b << 7);	\
  a = ROL32(a,  5); c = ROL32(c, 22);					\
} while (0)

#define DROUND(a, b, c, d, r, k) do {					\
  IS##r(a, b, c, d);							\
  d ^= *--k; c ^= *--k; b ^= *--k; a ^= *--k;				\
  a = ROR32(a,  5); c = ROR32(c, 22); a ^= b ^ d; c ^= d ^ (b << 7);	\
  b = ROR32(b,  1); d = ROR32(d,  7); b ^= a ^ c; d ^= c ^ (a << 3);	\
  a = ROR32(a, 13); c = ROR32(c,  3);					\
} while (0)

void serpent_eblk(const serpent_ctx *k, const uint32 *s, uint32 *d)
{
  uint32 aa = s[0], bb = s[1], cc = s[2], dd = s[3];
  const uint32 *kk = k->k;

  EROUND(aa, bb, cc, dd, 0, kk); EROUND(aa, bb, cc, dd, 1, kk);
  EROUND(aa, bb, cc, dd, 2, kk); EROUND(aa, bb, cc, dd, 3, kk);
  EROUND(aa, bb, cc, dd, 4, kk); EROUND(aa, bb, cc, dd, 5, kk);
  EROUND(aa, bb, cc, dd, 6, kk); EROUND(aa, bb, cc, dd, 7, kk);

  EROUND(aa, bb, cc, dd, 0, kk); EROUND(aa, bb, cc, dd, 1, kk);
  EROUND(aa, bb, cc, dd, 2, kk); EROUND(aa, bb, cc, dd, 3, kk);
  EROUND(aa, bb, cc, dd, 4, kk); EROUND(aa, bb, cc, dd, 5, kk);
  EROUND(aa, bb, cc, dd, 6, kk); EROUND(aa, bb, cc, dd, 7, kk);

  EROUND(aa, bb, cc, dd, 0, kk); EROUND(aa, bb, cc, dd, 1, kk);
  EROUND(aa, bb, cc, dd, 2, kk); EROUND(aa, bb, cc, dd, 3, kk);
  EROUND(aa, bb, cc, dd, 4, kk); EROUND(aa, bb, cc, dd, 5, kk);
  EROUND(aa, bb, cc, dd, 6, kk); EROUND(aa, bb, cc, dd, 7, kk);

  EROUND(aa, bb, cc, dd, 0, kk); EROUND(aa, bb, cc, dd, 1, kk);
  EROUND(aa, bb, cc, dd, 2, kk); EROUND(aa, bb, cc, dd, 3, kk);
  EROUND(aa, bb, cc, dd, 4, kk); EROUND(aa, bb, cc, dd, 5, kk);
  EROUND(aa, bb, cc, dd, 6, kk);

  aa ^= *kk++; bb ^= *kk++; cc ^= *kk++; dd ^= *kk++;
  S7(aa, bb, cc, dd);
  aa ^= *kk++; bb ^= *kk++; cc ^= *kk++; dd ^= *kk++;
  d[0] = aa; d[1] = bb; d[2] = cc; d[3] = dd;
}

void serpent_dblk(const serpent_ctx *k, const uint32 *s, uint32 *d)
{
  uint32 aa = s[0], bb = s[1], cc = s[2], dd = s[3];
  const uint32 *kk = k->k + 132;

  dd ^= *--kk; cc ^= *--kk; bb ^= *--kk; aa ^= *--kk;

  DROUND(aa, bb, cc, dd, 7, kk); DROUND(aa, bb, cc, dd, 6, kk);
  DROUND(aa, bb, cc, dd, 5, kk); DROUND(aa, bb, cc, dd, 4, kk);
  DROUND(aa, bb, cc, dd, 3, kk); DROUND(aa, bb, cc, dd, 2, kk);
  DROUND(aa, bb, cc, dd, 1, kk); DROUND(aa, bb, cc, dd, 0, kk);

  DROUND(aa, bb, cc, dd, 7, kk); DROUND(aa, bb, cc, dd, 6, kk);
  DROUND(aa, bb, cc, dd, 5, kk); DROUND(aa, bb, cc, dd, 4, kk);
  DROUND(aa, bb, cc, dd, 3, kk); DROUND(aa, bb, cc, dd, 2, kk);
  DROUND(aa, bb, cc, dd, 1, kk); DROUND(aa, bb, cc, dd, 0, kk);

  DROUND(aa, bb, cc, dd, 7, kk); DROUND(aa, bb, cc, dd, 6, kk);
  DROUND(aa, bb, cc, dd, 5, kk); DROUND(aa, bb, cc, dd, 4, kk);
  DROUND(aa, bb, cc, dd, 3, kk); DROUND(aa, bb, cc, dd, 2, kk);
  DROUND(aa, bb, cc, dd, 1, kk); DROUND(aa, bb, cc, dd, 0, kk);

  DROUND(aa, bb, cc, dd, 7, kk); DROUND(aa, bb, cc, dd, 6, kk);
  DROUND(aa, bb, cc, dd, 5, kk); DROUND(aa, bb, cc, dd, 4, kk);
  DROUND(aa, bb, cc, dd, 3, kk); DROUND(aa, bb, cc, dd, 2, kk);
  DROUND(aa, bb, cc, dd, 1, kk);

  IS0(aa, bb, cc, dd);
  dd ^= *--kk; cc ^= *--kk; bb ^= *--kk; aa ^= *--kk;
  d[0] = aa; d[1] = bb; d[2] = cc; d[3] = dd;
}

/*----- That's all, folks -------------------------------------------------*/
