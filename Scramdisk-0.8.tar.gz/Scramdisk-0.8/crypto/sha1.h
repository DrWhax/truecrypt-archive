/* -*-c-*-
 *
 * $Id: sha1.h,v 1.1 2005/05/22 20:10:22 huj Exp $
 *
 * Implementation of the SHA-1 hash function
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------* 
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 * 
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the SHA-1 hash function ----------------------------------*
 *
 * SHA (Secure Hash Algorithm) was designed by the NSA, for use with the
 * Digital Signature Algorithm.  It is defined by FIPS 180-1.  It has gained
 * wide acceptance since its initial publication, and is probably now most
 * people's collision-resistant function of choice.  The author prefers
 * RIPEMD-160, for no particularly good reasons.
 */

#ifndef CATACOMB_SHA1_H
#define CATACOMB_SHA1_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifdef __KERNEL__
#include <linux/types.h>
#else
#include <sys/types.h>
#endif

/*----- Magic numbers -----------------------------------------------------*/

#define SHA1_BUFSZ 64
#define SHA1_HASHSZ 20
#define SHA1_STATESZ 20

/*----- Data structures ---------------------------------------------------*/

typedef struct sha1_ctx {
  uint32 a, b, c, d, e;		/* Chaining variables */
  uint32 nl, nh;		/* Byte count so far */
  unsigned off;			/* Offset into buffer */
  octet buf[SHA1_BUFSZ];		/* Accumulation buffer */
} sha1_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @sha1_compress@ --- *
 *
 * Arguments:	@sha1_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		SHA compression function.
 */

extern void sha1_compress(sha1_ctx* /*ctx*/, const void* /*sbuf*/);

/* --- @sha1_init@ --- *
 *
 * Arguments:	@sha1_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

extern void sha1_init(sha1_ctx* /*ctx*/);

/* --- @sha1_set@ --- *
 *
 * Arguments:	@sha1_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

extern void sha1_set(sha1_ctx* /*ctx*/, const void* /*buf*/,
		    unsigned long /*count*/);

/* --- @sha1_hash@ --- *
 *
 * Arguments:	@sha1_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

extern void sha1_hash(sha1_ctx* /*ctx*/, const void* /*buf*/, size_t /*sz*/);

/* --- @sha1_done@ --- *
 *
 * Arguments:	@sha1_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

extern void sha1_done(sha1_ctx* /*ctx*/, void* /*hash*/);

/* --- @sha1_state@ --- *
 *
 * Arguments:	@sha1_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @sha1_set@.
 */

extern unsigned long sha1_state(sha1_ctx* /*ctx*/, void* /*state*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
