/* -*-c-*-
 *
 * $Id: rijndael.c,v 1.1 2005/05/22 20:10:22 huj Exp $
 *
 * The Rijndael block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------* 
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 * 
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "block.h"
#include "rijndael.h"
#include "rijndael-tab.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @rijndael_setup@ --- *
 *
 * Arguments:	@rijndael_ctx *k@ = pointer to context to initialize
 *		@unsigned nb@ = number of words in the block
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of the key material
 *
 * Returns:	---
 *
 * Use:		Low-level key-scheduling.
 */

void rijndael_setup(rijndael_ctx *k, unsigned nb, const void *buf, size_t sz)
{
  unsigned nk, nr, nw;
  unsigned i, j, jj;
  const octet *p;
  uint32 ww;

  /* --- Sort out the key size --- */

  nk = sz / 4;

  /* --- Select the number of rounds --- */

  nr = (nk > nb ? nk : nb) + 6;
  if (nr < 10)
    nr = 10;
  k->nr = nr;

  /* --- Fetch the first key words out --- */

  p = buf;
  for (i = 0; i < nk; i++) {
    k->w[i] = LOAD32_L(p);
    p += 4;
  }

  /* --- Expand this material to fill the rest of the table --- */

  nw = (nr + 1) * nb;
  ww = k->w[i - 1];
  p = RCON;
  for (; i < nw; i++) {
    uint32 w = k->w[i - nk];
    if (i % nk == 0) {
      ww = ROR32(ww, 8);
      w ^= SUB(S, ww, ww, ww, ww) ^ *p++;
    } else if (nk > 6 && i % nk == 4)
      w ^= SUB(S, ww, ww, ww, ww);
    else
      w ^= ww;
    k->w[i] = ww = w;
  }

  /* --- Make the decryption keys --- */

  j = nw; i = 0;

  j -= nb; jj = 0;
  for (; i < nb; i++)
    k->wi[i] = k->w[j + jj++];

  for (; i < nw - nb; i += nb) {
    j -= nb;
    for (jj = 0; jj < nb; jj++) {
      uint32 w = k->w[j + jj];
      k->wi[i + jj] = MIX(U, w, w, w, w);
    }
  }

  j -= nb; jj = 0;
  for (; i < nw; i++)
    k->wi[i] = k->w[j + jj++];
}

/* --- @rijndael_init@ --- *
 *
 * Arguments:	@rijndael_ctx *k@ = pointer to context to initialize
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of the key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Rijndael context with a particular key.  This
 *		implementation of Rijndael doesn't impose any particular
 *		limits on the key size except that it must be multiple of 4
 *		bytes long.  256 bits seems sensible, though.
 */

void rijndael_init(rijndael_ctx *k, const void *buf, size_t sz)
{
  rijndael_setup(k, RIJNDAEL_BLKSZ / 4, buf, sz);
}

/* --- @rijndael_eblk@, @rijndael_dblk@ --- *
 *
 * Arguments:	@const rijndael_ctx *k@ = pointer to Rijndael context
 *		@const uint32 s[4]@ = pointer to source block
 *		@uint32 d[4]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

#define DO(what, t, aa, bb, cc, dd, a, b, c, d, w) do {			\
  aa = what(t, a, b, c, d) ^ *w++;					\
  bb = what(t, b, c, d, a) ^ *w++;					\
  cc = what(t, c, d, a, b) ^ *w++;					\
  dd = what(t, d, a, b, c) ^ *w++;					\
} while (0)

#define UNDO(what, t, aa, bb, cc, dd, a, b, c, d, w) do {		\
  aa = what(t, a, d, c, b) ^ *w++;					\
  bb = what(t, b, a, d, c) ^ *w++;					\
  cc = what(t, c, b, a, d) ^ *w++;					\
  dd = what(t, d, c, b, a) ^ *w++;					\
} while (0)

void rijndael_eblk(const rijndael_ctx *k, const uint32 *s, uint32 *dst)
{
  uint32 a = s[0], b = s[1], c = s[2], d = s[3];
  uint32 aa, bb, cc, dd;
  uint32 *w = k->w;

  a ^= *w++; b ^= *w++; c ^= *w++; d ^= *w++;
  aa = a; bb = b; cc = c; dd = d;

  switch (k->nr) {
    case 14:
      DO(MIX, T, aa, bb, cc, dd, a, b, c, d, w);
    case 13:
      DO(MIX, T, a, b, c, d, aa, bb, cc, dd, w);
    case 12:
      DO(MIX, T, aa, bb, cc, dd, a, b, c, d, w);
    case 11:
      DO(MIX, T, a, b, c, d, aa, bb, cc, dd, w);
    case 10:
    default:
      DO(MIX, T, aa, bb, cc, dd, a, b, c, d, w);
      DO(MIX, T, a, b, c, d, aa, bb, cc, dd, w);
      DO(MIX, T, aa, bb, cc, dd, a, b, c, d, w);
      DO(MIX, T, a, b, c, d, aa, bb, cc, dd, w);
      DO(MIX, T, aa, bb, cc, dd, a, b, c, d, w);
      DO(MIX, T, a, b, c, d, aa, bb, cc, dd, w);
      DO(MIX, T, aa, bb, cc, dd, a, b, c, d, w);
      DO(MIX, T, a, b, c, d, aa, bb, cc, dd, w);
      DO(MIX, T, aa, bb, cc, dd, a, b, c, d, w);
  }
  DO(SUB, S, a, b, c, d, aa, bb, cc, dd, w);

  dst[0] = a; dst[1] = b; dst[2] = c; dst[3] = d;
}

void rijndael_dblk(const rijndael_ctx *k, const uint32 *s, uint32 *dst)
{
  uint32 a = s[0], b = s[1], c = s[2], d = s[3];
  uint32 aa, bb, cc, dd;
  uint32 *w = k->wi;

  a ^= *w++; b ^= *w++; c ^= *w++; d ^= *w++;
  aa = a; bb = b; cc = c; dd = d;

  switch (k->nr) {
    case 14:
      UNDO(MIX, TI, aa, bb, cc, dd, a, b, c, d, w);
    case 13:
      UNDO(MIX, TI, a, b, c, d, aa, bb, cc, dd, w);
    case 12:
      UNDO(MIX, TI, aa, bb, cc, dd, a, b, c, d, w);
    case 11:
      UNDO(MIX, TI, a, b, c, d, aa, bb, cc, dd, w);
    case 10:
    default:
      UNDO(MIX, TI, aa, bb, cc, dd, a, b, c, d, w);
      UNDO(MIX, TI, a, b, c, d, aa, bb, cc, dd, w);
      UNDO(MIX, TI, aa, bb, cc, dd, a, b, c, d, w);
      UNDO(MIX, TI, a, b, c, d, aa, bb, cc, dd, w);
      UNDO(MIX, TI, aa, bb, cc, dd, a, b, c, d, w);
      UNDO(MIX, TI, a, b, c, d, aa, bb, cc, dd, w);
      UNDO(MIX, TI, aa, bb, cc, dd, a, b, c, d, w);
      UNDO(MIX, TI, a, b, c, d, aa, bb, cc, dd, w);
      UNDO(MIX, TI, aa, bb, cc, dd, a, b, c, d, w);
  }
  UNDO(SUB, SI, a, b, c, d, aa, bb, cc, dd, w);

  dst[0] = a; dst[1] = b; dst[2] = c; dst[3] = d;
}

/*----- Global variables --------------------------------------------------*/

const octet rijndael_keysz[] = { KSZ_RANGE, RIJNDAEL_KEYSZ, 4, 32, 4 };

/*----- Constant tables ---------------------------------------------------*/

const octet rijndael_s[256] = RIJNDAEL_S;
const octet rijndael_si[256] = RIJNDAEL_SI;
const uint32 rijndael_t[4][256] = RIJNDAEL_T;
const uint32 rijndael_ti[4][256] = RIJNDAEL_TI;
const uint32 rijndael_u[4][256] = RIJNDAEL_U;
const octet rijndael_rcon[] = RIJNDAEL_RCON;

/*----- That's all, folks -------------------------------------------------*/
