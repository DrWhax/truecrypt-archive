/* -*-c-*-
 *
 * $Id: blowfish.c,v 1.1 2005/05/22 20:10:22 huj Exp $
 *
 * The Blowfish block cipher
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------* 
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 * 
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#ifdef __KERNEL__
#include <linux/string.h>
#else
#include <string.h>
#endif
#include "block.h"
#include "blowfish.h"
#include "blowfish-tab.h"

/*----- Global variables --------------------------------------------------*/

static blowfish_ctx ikey = BLOWFISH_IKEY;

const octet blowfish_keysz[] = { KSZ_RANGE, BLOWFISH_KEYSZ, 1, 56, 1 };

/*----- Macros ------------------------------------------------------------*/

#define ROUND(k, x, y, r) do {						\
  x ^= *r;								\
  y ^= ((k->s0[U8(x >> 24)] +						\
	 k->s1[U8(x >> 16)]) ^						\
	 k->s2[U8(x >>  8)]) +						\
	 k->s3[U8(x >>  0)];						\
} while (0)

#define EBLK(k, a, b, c, d) do {					\
  const uint32 *_r = k->p;						\
  uint32 _x = a;							\
  uint32 _y = b;							\
  ROUND(k, _x, _y, _r++);						\
  ROUND(k, _y, _x, _r++);						\
  ROUND(k, _x, _y, _r++);						\
  ROUND(k, _y, _x, _r++);						\
  ROUND(k, _x, _y, _r++);						\
  ROUND(k, _y, _x, _r++);						\
  ROUND(k, _x, _y, _r++);						\
  ROUND(k, _y, _x, _r++);						\
  ROUND(k, _x, _y, _r++);						\
  ROUND(k, _y, _x, _r++);						\
  ROUND(k, _x, _y, _r++);						\
  ROUND(k, _y, _x, _r++);						\
  ROUND(k, _x, _y, _r++);						\
  ROUND(k, _y, _x, _r++);						\
  ROUND(k, _x, _y, _r++);						\
  ROUND(k, _y, _x, _r++);						\
  c = _y ^ k->p[17];							\
  d = _x ^ k->p[16];							\
} while (0)

#define DBLK(k, a, b, c, d) do {					\
  const uint32 *_r = k->p + 18;						\
  uint32 _x = a;							\
  uint32 _y = b;							\
  ROUND(k, _x, _y, --_r);						\
  ROUND(k, _y, _x, --_r);						\
  ROUND(k, _x, _y, --_r);						\
  ROUND(k, _y, _x, --_r);						\
  ROUND(k, _x, _y, --_r);						\
  ROUND(k, _y, _x, --_r);						\
  ROUND(k, _x, _y, --_r);						\
  ROUND(k, _y, _x, --_r);						\
  ROUND(k, _x, _y, --_r);						\
  ROUND(k, _y, _x, --_r);						\
  ROUND(k, _x, _y, --_r);						\
  ROUND(k, _y, _x, --_r);						\
  ROUND(k, _x, _y, --_r);						\
  ROUND(k, _y, _x, --_r);						\
  ROUND(k, _x, _y, --_r);						\
  ROUND(k, _y, _x, --_r);						\
  c = _y ^ k->p[0];							\
  d = _x ^ k->p[1];							\
} while (0)

/*----- Low-level encryption interface ------------------------------------*/

/* --- @blowfish_init@ --- *
 *
 * Arguments:	@blowfish_ctx *k@ = pointer to key block to fill in
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Blowfish key buffer.  Blowfish accepts
 *		a more-or-less arbitrary size key.
 */

void blowfish_init(blowfish_ctx *k, const void *buf, size_t sz)
{
  /* --- Copy the initial value over --- */

  memcpy(k, &ikey, sizeof(ikey));

  /* --- Initialize the %$P$% array --- */

  {
    const octet *p = buf;
    const octet *q = p + sz;
    int i = 0, j = 0;
    uint32 x = 0;

    while (i < 18) {
      x = (x << 8) | U8(*p++);
      if (p >= q)
	p = buf;
      if (++j >= 4) {
	k->p[i++] ^= x;
	x = 0;
	j = 0;
      }
    }

    x = 0;
  }

  /* --- Now mangle the complete array of keys --- */

  {
    uint32 b[2];
    int i;

    b[0] = b[1] = 0;

    for (i = 0; i < 18; i += 2) {
      blowfish_eblk(k, b, b);
      k->p[i] = b[0]; k->p[i + 1] = b[1];
    }

    for (i = 0; i < 256; i += 2) {
      blowfish_eblk(k, b, b);
      k->s0[i] = b[0]; k->s0[i + 1] = b[1];
    }

    for (i = 0; i < 256; i += 2) {
      blowfish_eblk(k, b, b);
      k->s1[i] = b[0]; k->s1[i + 1] = b[1];
    }

    for (i = 0; i < 256; i += 2) {
      blowfish_eblk(k, b, b);
      k->s2[i] = b[0]; k->s2[i + 1] = b[1];
    }

    for (i = 0; i < 256; i += 2) {
      blowfish_eblk(k, b, b);
      k->s3[i] = b[0]; k->s3[i + 1] = b[1];
    }

    memset(&b, 0, sizeof(b));
  }
}

/* --- @blowfish_eblk@, @blowfish_dblk@ --- *
 *
 * Arguments:	@const blowfish_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

void blowfish_eblk(const blowfish_ctx *k, const uint32 *s, uint32 *d)
{
  EBLK(k, s[0], s[1], d[0], d[1]);
}

void blowfish_dblk(const blowfish_ctx *k, const uint32 *s, uint32 *d)
{
  DBLK(k, s[0], s[1], d[0], d[1]);
}

/*----- That's all, folks -------------------------------------------------*/
