/* -*-c-*-
 *
 * $Id: des3.c,v 1.1 2005/05/22 20:10:22 huj Exp $
 *
 * Implementation of double- and triple-DES
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------* 
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 * 
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "block.h"
#include "des-base.h"
#include "des3.h"

/*----- Global variables --------------------------------------------------*/

const octet des3_keysz[] = { KSZ_SET, 21, 7, 8, 14, 16, 24, 0 };

/*----- Main code ---------------------------------------------------------*/

/* --- @des3_init@ --- *
 *
 * Arguments:	@des3_ctx *k@ = pointer to key block
 *		@const void *buf@ = pointer to key buffer
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a DES key buffer.  The key buffer may have length
 *              7, 8, 14, 16, 21, or 24.  These correspond to one, two or
 *              three DES keys, either packed or unpacked (i.e., still
 *              containing parity bits).
 */

void des3_init(des3_ctx *k, const void *buf, size_t sz)
{
  size_t step;
  const octet *p = buf;

  if (sz % 7 == 0)
    step = 7;
  else
    step = 8;

  des_init(&k->a, p, step);
  if (sz > 8) p += step;
  des_init(&k->b, p, step);
  if (sz > 16) p += step; else p = buf;
  des_init(&k->c, p, step);
}

/* --- @des3_eblk@, @des3_dblk@ --- *
 *
 * Arguments:	@const des3_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

void des3_eblk(const des3_ctx *k, const uint32 *s, uint32 *d)
{
  uint32 x = s[0], y = s[1];
  DES_IP(x, y);
  DES_EBLK(k->a.k, x, y, x, y);
  DES_DBLK(k->b.k, x, y, x, y);
  DES_EBLK(k->c.k, x, y, x, y);
  DES_IPINV(x, y);
  d[0] = x, d[1] = y;
}

void des3_dblk(const des3_ctx *k, const uint32 *s, uint32 *d)
{
  uint32 x = s[0], y = s[1];
  DES_IP(x, y);
  DES_DBLK(k->c.k, x, y, x, y);
  DES_EBLK(k->b.k, x, y, x, y);
  DES_DBLK(k->a.k, x, y, x, y);
  DES_IPINV(x, y);
  d[0] = x, d[1] = y;
}

/*----- That's all, folks -------------------------------------------------*/
