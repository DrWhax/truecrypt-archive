/* -*-c-*-
 *
 * $Id: des.h,v 1.1 2005/05/22 20:10:22 huj Exp $
 *
 * The Data Encryption Standard
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------* 
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 * 
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the Data Encryption Standard -----------------------------*
 *
 * Almost twenty years after it was first accepted, DES is still the standard
 * block cipher.  It's showing its age in its small key size and poor
 * optimiziation for software implementations, but it's not really been badly
 * dented by the intensive analysis thrown at it.
 *
 * This interface is here for compatibility with existing protocols, and
 * because it's a trivial veneer over the base DES code which is used by the
 * @des3@ interface which implements proper strong triple-DES.
 */

#ifndef CATACOMB_DES_H
#define CATACOMB_DES_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifdef __KERNEL__
#include <linux/types.h>
#else
#include <sys/types.h>
#endif

#include "bits.h"

/*----- Magical numbers ---------------------------------------------------*/

#define DES_BLKSZ 8
#define DES_KEYSZ 7
#define DES_CLASS (N, B, 64)

extern const octet des_keysz[];

/*----- Data structures ---------------------------------------------------*/

typedef struct des_ctx {
  uint32 k[32];
} des_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @des_init@ --- *
 *
 * Arguments:	@des_ctx *k@ = pointer to key block
 *		@const void *buf@ = pointer to key buffer
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a DES key buffer.  The key buffer may be either 7
 *		or 8 bytes long.  If it's 8 bytes, the key is assumed to be
 *		padded with parity bits in the low order bit of each octet.
 *		These are stripped out without checking prior to the actual
 *		key scheduling.
 */

extern void des_init(des_ctx* /*k*/, const void* /*buf*/, size_t /*sz*/);

/* --- @des_eblk@, @des_dblk@ --- *
 *
 * Arguments:	@const des_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void des_eblk(const des_ctx* /*k*/,
		     const uint32* /*s*/, uint32* /*d*/);
extern void des_dblk(const des_ctx* /*k*/,
		     const uint32* /*s*/, uint32* /*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
