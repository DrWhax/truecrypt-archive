/* -*-c-*-
 *
 * $Id: tea.c,v 1.1 2005/05/22 20:10:22 huj Exp $
 *
 * The Tiny Encryption Algorithm
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------* 
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 * 
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#ifdef __KERNEL__
#include <linux/string.h>
#else
#include <string.h>
#endif
#include "block.h"
#include "tea.h"

/*----- Global variables --------------------------------------------------*/

const octet tea_keysz[] = { KSZ_RANGE, TEA_KEYSZ, 0, 16, 1 };

/*----- Main code ---------------------------------------------------------*/

/* --- @tea_init@ --- *
 *
 * Arguments:   @tea_ctx *k@ = pointer to key block
 *              @const void *buf@ = pointer to key buffer
 *              @size_t sz@ = size of key material
 *
 * Returns:     ---
 *
 * Use:         Initializes a TEA key buffer.  The key buffer must be 16
 *		bytes long.
 */

void tea_init(tea_ctx *k, const void *buf, size_t sz)
{
  octet kb[16];
  const octet *p;

  if (sz >= sizeof(kb))
    p = buf;
  else {
    memcpy(kb, buf, sz);
    memset(kb + sz, 0, sizeof(kb) - sz);
    p = kb;
  }

  k->ka = LOAD32(p +  0); k->kb = LOAD32(p +  4);
  k->kc = LOAD32(p +  8); k->kd = LOAD32(p + 12);
  k->r = 32;

  if (p == kb)
    memset(&kb, 0, sizeof(kb));
}

/* --- @tea_eblk@, @tea_dblk@ --- *
 *
 * Arguments:   @const tea_ctx *k@ = pointer to key block
 *              @const uint32 s[2]@ = pointer to source block
 *              @uint32 d[2]@ = pointer to teatination block
 *
 * Returns:     ---
 *
 * Use:         Low-level block encryption and decryption.
 */

#define DELTA 0x9e3779b9

void tea_eblk(const tea_ctx *k, const uint32 *s, uint32 *d)
{
  uint32 y = s[0], z = s[1];
  uint32 ka = k->ka, kb = k->kb, kc = k->kc, kd = k->kd;
  uint32 n = 0;
  unsigned i;

  for (i = 0; i < k->r; i++) {
    n += DELTA;
    y = U32(y + (((z << 4) + ka) ^ (z + n) ^ ((z >> 5) + kb)));
    z = U32(z + (((y << 4) + kc) ^ (y + n) ^ ((y >> 5) + kd)));
  }
  d[0] = y; d[1] = z;
}

void tea_dblk(const tea_ctx *k, const uint32 *s, uint32 *d)
{
  uint32 y = s[0], z = s[1];
  uint32 ka = k->ka, kb = k->kb, kc = k->kc, kd = k->kd;
  uint32 n = DELTA * k->r;
  unsigned i;

  for (i = 0; i < k->r; i++) {
    z = U32(z - (((y << 4) + kc) ^ (y + n) ^ ((y >> 5) + kd)));
    y = U32(y - (((z << 4) + ka) ^ (z + n) ^ ((z >> 5) + kb)));
    n -= DELTA;
  }
  d[0] = y; d[1] = z;
}

/*----- That's all, folks -------------------------------------------------*/
