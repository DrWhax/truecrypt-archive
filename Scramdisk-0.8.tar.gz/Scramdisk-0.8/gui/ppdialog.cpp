/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: ppdialog.cpp,v 1.2 2005/08/11 20:49:31 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: ppdialog.cpp,v $
 *  Revision 1.2  2005/08/11 20:49:31  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <qlayout.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qmessagebox.h>
#include "ppdialog.h"

PassphraseDialog::PassphraseDialog(QWidget* parent)
  : QDialog(parent, NULL, true), set(false)
{
  memset(ppbuf, 0, 160u);
  vbox = new QVBoxLayout(this, 10, 8);
  label0 = new QLabel("Enter Passphrase", this);
  label0->setFont(QFont("Times", 12, QFont::Bold));
  vbox->addWidget(label0);
  box1 = new QHBoxLayout(NULL, 0, 10);
  label1 = new QLabel("Line 1:\t", this);
  label1->setFont(QFont("Times", 12, QFont::Bold));
  box1->addWidget(label1);
  line1 = new QLineEdit(this);
  line1->setMaxLength(40);
  line1->setEchoMode(QLineEdit::Password);
  box1->addWidget(line1);
  vbox->addLayout(box1);
  box2 = new QHBoxLayout(NULL, 0, 10);
  label2 = new QLabel("Line 2:\t", this);
  label2->setFont(QFont("Times", 12, QFont::Bold));
  box2->addWidget(label2);
  line2 = new QLineEdit(this);
  line2->setMaxLength(40);
  line2->setEchoMode(QLineEdit::Password);
  box2->addWidget(line2);
  vbox->addLayout(box2);
  box3 = new QHBoxLayout(NULL, 0, 10);
  label3 = new QLabel("Line 3:\t", this);
  label3->setFont(QFont("Times", 12, QFont::Bold));
  box3->addWidget(label3);
  line3 = new QLineEdit(this);
  line3->setMaxLength(40);
  line3->setEchoMode(QLineEdit::Password);
  box3->addWidget(line3);
  vbox->addLayout(box3);
  box4 = new QHBoxLayout(NULL, 0, 10);
  label4 = new QLabel("Line 4:\t", this);
  label4->setFont(QFont("Times", 12, QFont::Bold));
  box4->addWidget(label4);
  line4 = new QLineEdit(this);
  line4->setMaxLength(40);
  line4->setEchoMode(QLineEdit::Password);
  box4->addWidget(line4);
  vbox->addLayout(box4);
  vbox->addSpacing(10);
  action_box = new QHBoxLayout(NULL, 0, 10);
  cancel = new QPushButton("Cancel", this);
  cancel->setFont(QFont("Times", 11, QFont::Bold));
  cancel->setMinimumWidth(140);
  action_box->addWidget(cancel);
  ok = new QPushButton("OK", this);
  ok->setFont(QFont("Times", 11, QFont::Bold));
  ok->setMinimumWidth(140);
  ok->setDefault(true);
  action_box->addWidget(ok);
  action_box->addSpacing(30);
  mode = new QPushButton("Show Passphrase", this);
  mode->setFont(QFont("Times", 11, QFont::Bold));
  mode->setMinimumWidth(300);
  action_box->addWidget(mode);
  vbox->addLayout(action_box);
  connect(line1, SIGNAL(textChanged(const QString&)),
          this, SLOT(SetLine1(const QString&)));
  connect(line2, SIGNAL(textChanged(const QString&)),
          this, SLOT(SetLine2(const QString&)));
  connect(line3, SIGNAL(textChanged(const QString&)),
          this, SLOT(SetLine3(const QString&)));
  connect(line4, SIGNAL(textChanged(const QString&)),
          this, SLOT(SetLine4(const QString&)));
  connect(mode, SIGNAL(clicked()), this, SLOT(Show()));
  connect(cancel, SIGNAL(clicked()), this, SLOT(Reject()));
  connect(ok, SIGNAL(clicked()), this, SLOT(Accept()));
}

PassphraseDialog::~PassphraseDialog()
{
  memset(ppbuf, 0, 160u);
  delete mode;
  delete ok;
  delete cancel;
  delete line1;
  delete line2;
  delete line3;
  delete line4;
  delete label0;
  delete label1;
  delete label2;
  delete label3;
  delete label4;
  delete box1;
  delete box2;
  delete box3;
  delete box4;
  delete action_box;
  delete vbox;
}

bool PassphraseDialog::Verify()
{
  bool ok = false;
  if (set)
  {
    octet verify_buf[160];
    memcpy(verify_buf, ppbuf, 160u);
    Clear();
    label0->setText("Verify Passphrase");
    line1->setFocus();
    exec();
    if (set && memcmp(ppbuf, verify_buf, 160u) == 0)
      ok = true;
    else
      Clear();
    memset(verify_buf, 0, 160u);
    label0->setText("Enter Passphrase");
  }
  return ok;
}

void PassphraseDialog::SetNew()
{
  Clear();
  label0->setText("Enter New Passphrase");
  line1->setFocus();
  exec();
  label0->setText("Enter Passphrase");
}

void PassphraseDialog::Show()
{
  line1->setEchoMode(QLineEdit::Normal);
  line2->setEchoMode(QLineEdit::Normal);
  line3->setEchoMode(QLineEdit::Normal);
  line4->setEchoMode(QLineEdit::Normal);
  mode->disconnect(SIGNAL(clicked()));
  mode->setText("Hide Passphrase");
  connect(mode, SIGNAL(clicked()), this, SLOT(Hide()));
}

void PassphraseDialog::Hide()
{
  line1->setEchoMode(QLineEdit::Password);
  line2->setEchoMode(QLineEdit::Password);
  line3->setEchoMode(QLineEdit::Password);
  line4->setEchoMode(QLineEdit::Password);
  mode->disconnect(SIGNAL(clicked()));
  mode->setText("Show Passphrase");
  connect(mode, SIGNAL(clicked()), this, SLOT(Show()));
}

void PassphraseDialog::Clear()
{
  set = false;
  memset(ppbuf, 0, 160u);
  line1->clear();
  line2->clear();
  line3->clear();
  line4->clear();
  line1->clearModified();
  line2->clearModified();
  line3->clearModified();
  line4->clearModified();
  line1->setFocus();
  Hide();
}

void PassphraseDialog::Accept()
{
  if (line1->isModified() || line2->isModified() ||
      line3->isModified() || line4->isModified() || set)
  {
    set = true;
    Hide();
    accept();
  }
  else
  {
    QMessageBox msg(this);
    msg.setCaption("Scramdisk");
    msg.setText("Please type a passphrase\nor click \"Cancel\"");
    msg.setButtonText(0, "OK");
    msg.setIcon(QMessageBox::Warning);
    msg.exec();
  }
  line1->setFocus();
}

void PassphraseDialog::Reject()
{
  Clear();
  reject();
}

void PassphraseDialog::SetLine1(const QString& s)
{
  size_t size = s.length() > 40u ? 40u : s.length();
  memset(ppbuf, 0, 40u);
  memcpy(ppbuf, s.ascii(), size);
}

void PassphraseDialog::SetLine2(const QString& s)
{
  size_t size = s.length() > 40u ? 40u : s.length();
  memset(ppbuf+40, 0, 40u);
  memcpy(ppbuf+40, s.ascii(), size);
}

void PassphraseDialog::SetLine3(const QString& s)
{
  size_t size = s.length() > 40u ? 40u : s.length();
  memset(ppbuf+80, 0, 40u);
  memcpy(ppbuf+80, s.ascii(), size);
}

void PassphraseDialog::SetLine4(const QString& s)
{
  size_t size = s.length() > 40u ? 40u : s.length();
  memset(ppbuf+120, 0, 40u);
  memcpy(ppbuf+120, s.ascii(), size);
}
