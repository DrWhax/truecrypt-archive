
/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: createdialog.cpp,v 1.2 2005/08/11 20:49:31 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: createdialog.cpp,v $
 *  Revision 1.2  2005/08/11 20:49:31  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <qlayout.h>
#include <qlabel.h>
#include <qcheckbox.h>
#include <qspinbox.h>
#include <qmessagebox.h>
#include <qpushbutton.h>
#include <qradiobutton.h>
#include <qbuttongroup.h>
#include "name_utils.h"
#include "createdialog.h"

CreateDialog::CreateDialog(QWidget* parent, bool w,
                           int d, int c, int f, int s, int u)
  : QDialog(parent, NULL, true), win_compatible(w), digest_id(d), cipher_id(c),
    fs_id(f), size(u == 1 ? (s > 1 ? s : 1) : (s > 512 ? s : 512))
{
  setCaption("Scramdisk Create: Container Properties");
  vbox = new QVBoxLayout(this, 10, 8);
  size_box = new QHBoxLayout(NULL, 0, 10);
  compat_label = new QLabel("Windows Container Compatibility:", this);
  compat_label->setFont(QFont("Times", 11, QFont::Bold));
  size_box->addWidget(compat_label);
  win_compat_button = new QCheckBox(this);
  win_compat_button->setChecked(win_compatible);
  size_box->addWidget(win_compat_button);
  size_label = new QLabel("\tContainer Size:", this);
  size_label->setFont(QFont("Times", 11, QFont::Bold));
  size_box->addWidget(size_label);
  size_value = new QSpinBox(this);
  if (win_compatible)
  {
    digest_id = 1;
    if (cipher_id == 0 || cipher_id == 4 || cipher_id == 7)
      cipher_id = 1;
    fs_id = 5;
  }
  if (u == 0)
  {
    size_value->setMinValue(512);
    size_value->setMaxValue(9999);
    size_value->setValue(size);
  }
  else
  {
    size_value->setMinValue(1);
    size_value->setMaxValue(2047);
    size_value->setValue(size);
    size *= 1024;
  }
  size_value->setLineStep(1);
  size_box->addWidget(size_value);
  size_group = new QButtonGroup(2, Qt::Vertical, this);
  size_group->setInsideSpacing(2);
  size_button_kb = new QRadioButton("KB", size_group);
  size_button_kb->setFont(QFont("Times", 9, QFont::Bold));
  size_button_kb->setChecked(u == 0);
  size_button_mb = new QRadioButton("MB", size_group);
  size_button_mb->setFont(QFont("Times", 9, QFont::Bold));
  size_button_mb->setChecked(u == 1);
  size_box->addWidget(size_group);
  vbox->addLayout(size_box);
  dgst_group = new QButtonGroup(undef_digest, Qt::Horizontal, "Digest:", this);
  dgst_group->setFont(QFont("Times", 11, QFont::Bold));
  dgst_group->setInsideSpacing(10);
  for (int d_id = 0; d_id < undef_digest; ++d_id)
  {
    digest_buttons[d_id] = new QRadioButton(digest_name(d_id), dgst_group);
    digest_buttons[d_id]->setFont(QFont("Times", 9, QFont::Bold));
  }
  if (digest_id < undef_digest)
    digest_buttons[digest_id]->setChecked(true);
  vbox->addWidget(dgst_group);
  cphr_group = new QButtonGroup(undef_cipher, Qt::Horizontal, "Cipher:", this);
  cphr_group->setFont(QFont("Times", 11, QFont::Bold));
  cphr_group->setInsideSpacing(10);
  for (int c_id = 0; c_id < undef_cipher; ++c_id)
  {
    cipher_buttons[c_id] = new QRadioButton(cipher_name(c_id), cphr_group);
    cipher_buttons[c_id]->setFont(QFont("Times", 9, QFont::Bold));
  }
  if (cipher_id < undef_cipher)
    cipher_buttons[cipher_id]->setChecked(true);
  vbox->addWidget(cphr_group);
  fs_group = new QButtonGroup(6, Qt::Horizontal, "File System:", this);
  fs_group->setFont(QFont("Times", 11, QFont::Bold));
  fs_group->setInsideSpacing(10);
  for (int f_id = 1; f_id < 5; ++f_id)
  {
    fs_buttons[f_id - 1] = new QRadioButton(fs_name(f_id), fs_group);
    fs_buttons[f_id - 1]->setFont(QFont("Times", 9, QFont::Bold));
  }
  fs_buttons[4] = new QRadioButton(fs_name(5) + " / " + fs_name(6), fs_group);
  fs_buttons[4]->setFont(QFont("Times", 9, QFont::Bold));
  fs_buttons[5] = new QRadioButton(fs_name(7), fs_group);
  fs_buttons[5]->setFont(QFont("Times", 9, QFont::Bold));
  fs_buttons[fs_id - 1]->setChecked(true);
  vbox->addWidget(fs_group);
  vbox->addSpacing(20);
  action_box = new QHBoxLayout(NULL, 0, 160);
  action_box->addSpacing(80);
  cancel = new QPushButton("Cancel", this);
  cancel->setFont(QFont("Times", 12, QFont::Bold));
  action_box->addWidget(cancel);
  ok = new QPushButton("OK", this);
  ok->setFont(QFont("Times", 12, QFont::Bold));
  ok->setDefault(true);
  action_box->addWidget(ok);
  action_box->addSpacing(80);
  vbox->addLayout(action_box);
  connect(cancel, SIGNAL(clicked()), this, SLOT(Reject()));
  connect(ok, SIGNAL(clicked()), this, SLOT(Accept()));
  connect(size_value, SIGNAL(valueChanged(int)), this, SLOT(SetSize(int)));
  connect(size_group, SIGNAL(clicked(int)), this, SLOT(SetUnit(int)));
}

CreateDialog::~CreateDialog()
{
  for (int d_id = 0; d_id < undef_digest; ++d_id)
    delete digest_buttons[d_id];
  for (int c_id = 0; c_id < undef_cipher; ++c_id)
    delete cipher_buttons[c_id];
  delete compat_label;
  delete win_compat_button;
  delete size_button_kb;
  delete size_button_mb;
  delete size_value;
  delete size_label;
  delete size_group;
  delete cancel;
  delete ok;
  delete dgst_group;
  delete cphr_group;
  delete size_box;
  delete action_box;
  delete vbox;
}

void CreateDialog::Accept()
{
  win_compatible = win_compat_button->isChecked();
  digest_id = dgst_group->selectedId();
  cipher_id = cphr_group->selectedId();
  fs_id = fs_group->selectedId() + 1;
  if (win_compatible)
  {
    if (digest_id != 1)
    {
      QMessageBox::critical(this, "Scramdisk Create", "Sorry, for Windows "
                            "compatible containers the digest must be SHA1!");
      return;
    }
    if (cipher_id == 0 || cipher_id == 4 || cipher_id == 7)
    {
      QMessageBox::critical(this, "Scramdisk Create", "Sorry, for Windows "
                            "compatible containers the cipher must be\n"
                            "Blowfish, DES, DES3, Square or Tea!");
      return;
    }
    if (fs_id != 5)
    {
      QMessageBox::critical(this, "Scramdisk Create", "Sorry, for Windows "
                            "compatible containers the filesystem must be "
                            "vfat/msdos!");
      return;
    }
  }
  accept();
}

void CreateDialog::Reject()
{
  reject();
}

void CreateDialog::SetSize(int value)
{
  size = value;
  if (size_button_mb->isChecked())
    size *= 1024u;
}

void CreateDialog::SetUnit(int id)
{
  if (id == 0)
  {
    size_value->setMinValue(512);
    size_value->setMaxValue(8191);
  }
  else
  {
    size_value->setMinValue(1);
    size_value->setMaxValue(2047);
  }
  SetSize(size_value->value());
}
