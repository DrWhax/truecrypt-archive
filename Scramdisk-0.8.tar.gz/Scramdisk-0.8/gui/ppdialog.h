/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: ppdialog.h,v 1.2 2005/08/11 20:49:31 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: ppdialog.h,v $
 *  Revision 1.2  2005/08/11 20:49:31  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#ifndef PPDIALOG_H
#define PPDIALOG_H

#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QLabel;
class QLineEdit;
class QPushButton;
class QWidget;

typedef unsigned char octet;

class PassphraseDialog : public QDialog
{
  Q_OBJECT
  private:
    bool set;
    octet ppbuf[160];
    QVBoxLayout* vbox;
    QHBoxLayout* box1;
    QHBoxLayout* box2;
    QHBoxLayout* box3;
    QHBoxLayout* box4;
    QHBoxLayout* action_box;
    QLabel* label0;
    QLabel* label1;
    QLabel* label2;
    QLabel* label3;
    QLabel* label4;
    QLineEdit* line1;
    QLineEdit* line2;
    QLineEdit* line3;
    QLineEdit* line4;
    QPushButton* cancel;
    QPushButton* ok;
    QPushButton* mode;
    
  public:
    PassphraseDialog(QWidget* parent);
    ~PassphraseDialog();
    const octet* Passphrase() { return ppbuf; }
    bool Set() { return set; }
    bool Verify();
    void SetNew();

  public slots:
    void Show();
    void Hide();
    void Clear();
    void Accept();
    void Reject();
    void SetLine1(const QString&);
    void SetLine2(const QString&);
    void SetLine3(const QString&);
    void SetLine4(const QString&);
};

#endif
