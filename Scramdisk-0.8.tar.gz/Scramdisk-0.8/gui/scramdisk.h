/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: scramdisk.h,v 1.2 2005/08/11 20:49:31 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: scramdisk.h,v $
 *  Revision 1.2  2005/08/11 20:49:31  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#ifndef SCRAMDISK_H
#define SCRAMDISK_H

#define SD_FSTYPES 8

#ifndef _PATH_MOUNTED
#define _PATH_MOUNTED "/etc/mtab" 
#endif

#include <qvbox.h>
#include "sdmount.h"

class QHBox;
class QLabel;
class QPixmap;
class QIconSet;
class QMenuBar;
class QPopupMenu;
class QLineEdit;
class QListView;
class QListViewItem;
class QVGroupBox;
class QCheckBox;
class QPushButton;
class QButtonGroup;
class QRadioButton;
class QMessageBox;
class QFileDialog;
class PassphraseDialog;

class Scramdisk : public QVBox
{
  Q_OBJECT
  private:
    bool win;
    int cphr;
    int dgst;
    int fs;
    int size;
    int unit;
    QString home_dir;
    QString cfg_dir;
    QString container;
    QString mnt_point;
    QString rnd_dev;
    QString mkfs_cmd;
    QString item_text;
    QMenuBar* menubar;
    QPopupMenu* file_menu;
    QPopupMenu* pp_menu;
    QPopupMenu* option_menu;
    QPopupMenu* about_menu;
    QVGroupBox* group;
    QHBox* action_box;
    QPixmap* sd_pxm;
    QPixmap* mount_pxm;
    QPixmap* umount_pxm;
    QPixmap* create_pxm;
    QPixmap* change_pxm;
    QIconSet* mount_icon;
    QIconSet* umount_icon;
    QIconSet* create_icon;
    QIconSet* change_icon;
    QPushButton* mount;
    QPushButton* umount;
    QPushButton* create;
    QPushButton* change;
    QHBox* container_box;
    QLabel* container_label;
    QLineEdit* container_line;
    QPushButton* container_browse;
    QHBox* mnt_point_box;
    QLabel* mnt_point_label;
    QLineEdit* mnt_point_line;
    QPushButton* mnt_point_browse;
    QHBox* options_box;
    QLabel* rdonly_label;
    QCheckBox* read_only;
    QButtonGroup* fstype_group;
    QRadioButton* fstype_buttons[SD_FSTYPES];
    QListView* volume_list;
    QListViewItem* volume;
    QListViewItem* option;
    QMessageBox* msg;
    QFileDialog* container_dialog;
    PassphraseDialog* pp_dialog;

  public:
    Scramdisk(QWidget* parent = 0, const char* name = 0);
    ~Scramdisk();
    void ErrorMessage(const QString& str, const QString& arg = QString::null);
    void ClearVolumeText(QListViewItem* vol_it);
    void SetVolumeText(int j, QListViewItem* vol_it);
    void LoadVolumeList();

  public slots:
    void Configure();
    void PrintVersion();
    void Documentation();
    void Mount();
    void UnMount();
    void Create();
    void Change();
    void SetPath();
    void BrowseMountPoint();
    void SetContainer(const QString&);
    void SetMountPoint(const QString&);
    void SetOption(QListViewItem*);
    void SetVolume(QListViewItem*);
    void SetItemText(QListViewItem*);
    void CheckOption(QListViewItem*, int);
};

#endif
