/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: rnd.cpp,v 1.2 2005/08/11 20:49:31 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: rnd.cpp,v $
 *  Revision 1.2  2005/08/11 20:49:31  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <qapplication.h>
#include <qprogressdialog.h>
#include "rnd.h"

Random::Random(const char* device)
  : capacity(0U), size(0U), last_size(0U), buf(NULL), pool(NULL), last(NULL)
{
  fd = open(device, O_RDONLY | O_NONBLOCK, 0U);
}

Random::~Random()
{
  if (buf)
  {
    memset(buf, 0, capacity);
    delete[] buf;
  }
  close(fd);
}

size_t Random::Gather(QWidget* creator, size_t n)
{
  int r;
  int i = 0;
  octet *p = buf;
  QProgressDialog progress(creator);
  progress.setCaption("Scramdisk Create");
  progress.setLabelText("Please move the mouse to gather random");
  progress.setCancelButtonText("Cancel");
  progress.setTotalSteps(static_cast<int>(n));
  progress.setProgress(0);
  qApp->processEvents();
  if (n == 0 || fd == -1)
    return 0U;
  if (buf == NULL)
  {
    size = 0U;
    pool = buf = p = new octet[n];
    if (p != NULL)
    {
      size = 0U;
      capacity = n;
    }
    else
    {
      size = capacity = 0U;
      return 0U;
    }
  }
  else if (n + size > capacity)
  {
    p = new octet[n + size];
    if (p != NULL)
    {
      memcpy(p, pool, size);
      memset(buf, 0, capacity);
      delete[] buf;
      capacity = n + size;
      pool = buf = p;
      p += size;
    }
    else
    {
      size = capacity = 0U;
      return 0U;
    }
  }
  else if (pool != NULL)
    p = pool;
  else
    return 0U;
  r = read(fd, p, n);
  if (r < 0 && errno != EINTR && errno != EAGAIN)
    return 0U;
  if (r > 0)
    p += r;
  progress.setProgress(r);
  qApp->processEvents();
  if (!progress.wasCanceled())
  {
    while (r < static_cast<int>(n))
    {
      sleep(1);
      i = read(fd, p, n - r);
      if (i < 0)
      {
        if (errno != EINTR && errno != EAGAIN)
          break;
      }
      else
      {
        p += i;
        r += i;
        progress.setProgress(r);
        qApp->processEvents();
        if (progress.wasCanceled())
          break;
      }
    }
  }
  size += r;
  return r;
}

size_t Random::Get(octet* buffer, size_t n)
{
  last_size = n < size ? n : size;
  last = pool;
  if (pool != NULL)
  {
    memcpy(buffer, pool, last_size);
    pool += last_size;
    size -= last_size;
  }
  else
    last_size = 0U;
  return last_size;
}

size_t Random::GetLast(octet* buffer, size_t n)
{
  size_t s = n < last_size ? n : last_size;
  if (last != NULL)
    memcpy(buffer, last, s);
  else
    s = 0U;
  return s;
}
