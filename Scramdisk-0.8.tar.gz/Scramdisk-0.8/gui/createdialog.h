/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: createdialog.h,v 1.2 2005/08/11 20:49:31 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: createdialog.h,v $
 *  Revision 1.2  2005/08/11 20:49:31  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#ifndef CREATEDIALOG_H
#define CREATEDIALOG_H

#include <qdialog.h>
#include "cipher.h"
#include "digest.h"

class QVBoxLayout;
class QHBoxLayout;
class QLabel;
class QCheckBox;
class QSpinBox;
class QPushButton;
class QRadioButton;
class QButtonGroup;
class QWidget;

class CreateDialog : public QDialog
{
  Q_OBJECT
  private:
    bool win_compatible;
    int digest_id;
    int cipher_id;
    int fs_id;
    unsigned int size;
    QVBoxLayout* vbox;
    QHBoxLayout* size_box;
    QLabel* compat_label;
    QLabel* size_label;
    QCheckBox* win_compat_button;
    QSpinBox* size_value;
    QButtonGroup* size_group;
    QRadioButton* size_button_kb;
    QRadioButton* size_button_mb;
    QButtonGroup* dgst_group;
    QRadioButton* digest_buttons[undef_digest];
    QButtonGroup* cphr_group;
    QRadioButton* cipher_buttons[undef_cipher];
    QButtonGroup* fs_group;
    QRadioButton* fs_buttons[6];
    QHBoxLayout* action_box;
    QPushButton* cancel;
    QPushButton* ok;

  public:
    CreateDialog(QWidget* parent, bool w, int d, int c, int f, int s, int u);
    ~CreateDialog();
    bool WinCompatible() { return win_compatible; }
    unsigned int Size() { return size; }
    int DigestId() { return digest_id; }
    int CipherId() { return cipher_id; }
    int FsId() { return fs_id < 6 ? fs_id : fs_id + 1; }

  public slots:
    void Accept();
    void Reject();
    void SetSize(int value);
    void SetUnit(int id);
};

#endif
