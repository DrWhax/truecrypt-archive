/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: scramdisk.cpp,v 1.2 2005/08/11 20:49:31 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: scramdisk.cpp,v $
 *  Revision 1.2  2005/08/11 20:49:31  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <pwd.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <limits.h>
#include <stdlib.h>
#include <mntent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/mount.h>
#include <qfont.h>
#include <qlabel.h>
#include <qmenubar.h>
#include <qlineedit.h>
#include <qlistview.h>
#include <qvgroupbox.h>
#include <qpushbutton.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qcheckbox.h>
#include <qstringlist.h>
#include <qfiledialog.h>
#include <qfileinfo.h>
#include <qprogressdialog.h>
#include <qmessagebox.h>
#include <qnamespace.h>
#include <qsettings.h>
#include <qtextbrowser.h>
#include <qapplication.h>
#include "mtab.h"
#include "sdctx.h"
#include "sdmnt.h"
#include "version.h"
#include "rnd.h"
#include "name_utils.h"
#include "createdialog.h"
#include "ppdialog.h"
#include "scramdisk.h"

Scramdisk::Scramdisk(QWidget* parent, const char* name)
  : QVBox(parent, name), win(true), cphr(1), dgst(1), fs(1), size(-1), unit(0)
{
  QString entry;
  bool rdonly;
  bool nofs;
  int j;
  QSettings config;
  home_dir = getenv("HOME");
  cfg_dir = home_dir + "/.scramdisk";
  config.insertSearchPath(QSettings::Unix, cfg_dir);
  config.setPath("scramdisk4linux.de", "scramdisk", QSettings::User);
  size = config.readNumEntry("/scramdisk/sdcreate/kb", -1);
  if (size < 0)
  {
    size = config.readNumEntry("/scramdisk/sdcreate/mb", -1);
    unit = 1;
  }
  config.removeSearchPath(QSettings::Unix, cfg_dir);
  config.insertSearchPath(QSettings::Unix, "/usr/share/scramdisk");
  if (size < 0)
  {
    size = config.readNumEntry("/scramdisk/sdcreate/kb", -1);
    if (size < 0)
    {
      size = config.readNumEntry("/scramdisk/sdcreate/mb", -1);
      unit = 1;
    }
  }
  config.insertSearchPath(QSettings::Unix, cfg_dir);
  rdonly = config.readBoolEntry("/scramdisk/sdmount/read-only", false);
  nofs = config.readBoolEntry("/scramdisk/sdcreate/no-fs", false);
  win = config.readBoolEntry("/scramdisk/sdcreate/win-compatible", true);
  entry = config.readEntry("/scramdisk/sdcreate/digest", "sha1");
  for (j = 0; j < 3; ++j)
  {
    if (entry.lower() == digest_name(j).lower())
    {
      dgst = j;
      break;
    }
  }
  entry = config.readEntry("/scramdisk/sdcreate/cipher", "blowfish");
  for (j = 0; j < 8; ++j)
  {
    if (entry.lower() == cipher_name(j).lower())
    {
      cphr = j;
      break;
    }
  }
  entry = config.readEntry("/scramdisk/sdcreate/fs-type", "ext2");
  if (nofs)
    fs = 6;
  else if (entry.lower() == "ext3")
    fs = 2;
  else if (entry.lower() == "reiserfs")
    fs = 3;
  else if (entry.lower() == "minix")
    fs = 4;
  else if (entry.lower() == "vfat" || entry.lower() == "msdos")
    fs = 5;
  rnd_dev = config.readEntry("/scramdisk/sdcreate/random", "/dev/random");
  mkfs_cmd = config.readEntry("/scramdisk/sdcreate/mkfs-command", "/sbin/mkfs");
  setMargin(10);
  setSpacing(8);
  setCaption("Scramdisk");
  menubar = new QMenuBar(this);
  file_menu = new QPopupMenu(this);
  menubar->insertItem(" &File ", file_menu);
  file_menu->insertItem("Mount", this, SLOT(Mount()), CTRL+Key_M);
  file_menu->insertItem("Unmount", this, SLOT(UnMount()), CTRL+Key_U);
  file_menu->insertItem("Create", this, SLOT(Create()), CTRL+Key_R);
  file_menu->insertItem("Change", this, SLOT(Change()), CTRL+Key_H);
  file_menu->insertItem("Quit", qApp, SLOT(quit()), CTRL+Key_Q);
  pp_dialog = new PassphraseDialog(this);
  pp_menu = new QPopupMenu(this);
  menubar->insertItem(" &Passphrases ", pp_menu);
  pp_menu->insertItem("Enter", pp_dialog, SLOT(exec()), CTRL+Key_P);
  pp_menu->insertItem("Erase", pp_dialog, SLOT(Clear()), CTRL+Key_E);
  option_menu = new QPopupMenu(this);
  menubar->insertItem(" &Options ", option_menu);
  option_menu->insertItem("Configure", this, SLOT(Configure()), CTRL+Key_C);
  about_menu = new QPopupMenu(this);
  menubar->insertItem(" &About ", about_menu);
  about_menu->insertItem("Version", this, SLOT(PrintVersion()), CTRL+Key_V);
  about_menu->insertItem("Documentation", this, SLOT(Documentation()),
                         CTRL+Key_D);
  group = new QVGroupBox(this);
  action_box = new QHBox(group);
  action_box->setSpacing(10);
  QSize icon_size_small(32, 32);
  QSize icon_size_large(48, 48);
  QIconSet::setIconSize(QIconSet::Large, icon_size_large);
  QIconSet::setIconSize(QIconSet::Small, icon_size_small);
  sd_pxm = new QPixmap("/usr/share/scramdisk/scramdisk.png");
  setIcon(*sd_pxm);
  mount_pxm = new QPixmap("/usr/share/scramdisk/mount.png");
  mount_icon = new QIconSet(*mount_pxm);
  mount = new QPushButton(*mount_icon, "Mount", action_box);
  mount->setFont(QFont("Times", 11, QFont::Bold));
  umount_pxm = new QPixmap("/usr/share/scramdisk/umount.png");
  umount_icon = new QIconSet(*umount_pxm);
  umount = new QPushButton(*umount_icon, "UnMount", action_box);
  umount->setFont(QFont("Times", 11, QFont::Bold));
  create_pxm = new QPixmap("/usr/share/scramdisk/create.png");
  create_icon = new QIconSet(*create_pxm);
  create = new QPushButton(*create_icon, "Create", action_box);
  create->setFont(QFont("Times", 11, QFont::Bold));
  change_pxm = new QPixmap("/usr/share/scramdisk/change.png");
  change_icon = new QIconSet(*change_pxm);
  change = new QPushButton(*change_icon, "Change", action_box);
  change->setFont(QFont("Times", 11, QFont::Bold));
  container_box = new QHBox(group);
  container_box->setSpacing(10);
  container_label = new QLabel("Container:\t", container_box);
  container_label->setFont(QFont("Times", 11, QFont::Bold));
  container_line = new QLineEdit(container_box);
  container_browse = new QPushButton("Browse", container_box);
  container_browse->setFont(QFont("Times", 11, QFont::Bold));
  mnt_point_box = new QHBox(group);
  mnt_point_box->setSpacing(10);
  mnt_point_label = new QLabel("Mount Point:\t", mnt_point_box);
  mnt_point_label->setFont(QFont("Times", 11, QFont::Bold));
  mnt_point_line = new QLineEdit(mnt_point_box);
  mnt_point_browse = new QPushButton("Browse", mnt_point_box);
  mnt_point_browse->setFont(QFont("Times", 11, QFont::Bold));
  options_box = new QHBox(group);
  options_box->setSpacing(10);
  fstype_group = new QButtonGroup(SD_FSTYPES, Qt::Horizontal,
                                  "File System:", options_box);
  fstype_group->setFont(QFont("Times", 11, QFont::Bold));
  fstype_group->setInsideSpacing(10);
  for (int fs_id = 0; fs_id < SD_FSTYPES; ++fs_id)
  {
    QString name(fs_name(fs_id));
    if (name == "none")
      name.append(" (don't mount)");
    fstype_buttons[fs_id] = new QRadioButton(name, fstype_group);
    fstype_buttons[fs_id]->setFont(QFont("Times", 9, QFont::Bold));
  }
  nofs = config.readBoolEntry("/scramdisk/sdmount/no-fs", false);
  if (nofs)
    fstype_buttons[SD_FSTYPES - 1]->setChecked(true);
  else
  {
    int f;
    entry = config.readEntry("/scramdisk/sdmount/fs-type");
    if (entry.lower() == "ext2")
      f = 1;
    else if (entry.lower() == "ext3")
      f = 2;
    else if (entry.lower() == "reiserfs")
      f = 3;
    else if (entry.lower() == "minix")
      f = 4;
    else if (entry.lower() == "vfat")
      f = 5;
    else if (entry.lower() == "msdos")
      f = 6;
    else
      f = 0;
    fstype_buttons[f]->setChecked(true);
  }
  rdonly_label = new QLabel("Mount Read Only:", options_box);
  rdonly_label->setFont(QFont("Times", 11, QFont::Bold));
  read_only = new QCheckBox(options_box);
  read_only->setChecked(rdonly);
  QStringList c_filter;
  c_filter << "All files (*)";
  c_filter << "SVL files (*.svl)";
  container_dialog = new QFileDialog(home_dir, "", this, NULL, true);
  container_dialog->setCaption("Scramdisk Container Choice");
  container_dialog->setFilters(c_filter);
  container_dialog->setMode(QFileDialog::AnyFile);
  container_dialog->setViewMode(QFileDialog::Detail);
  entry = config.readEntry("/scramdisk/sdmount/container");
  if (!entry.isNull())
  {
    QFileInfo finfo(entry);
    container = entry;
    container_line->setText(entry);
    if (finfo.exists())
      container_dialog->setDir(finfo.dir());
  }
  entry = config.readEntry("/scramdisk/sdmount/mount-point");
  if (!entry.isNull())
  {
    mnt_point = entry;
    mnt_point_line->setText(entry);
  }
  volume_list = new QListView(this);
  volume_list->addColumn("Device");
  volume_list->addColumn("Owner");
  volume_list->addColumn("Container");
  volume_list->setColumnWidth(2, 184);
  volume_list->addColumn("Mount Point");
  volume_list->setColumnWidth(3, 128);
  volume_list->addColumn("Cipher");
  volume_list->setColumnWidth(4, 78);
  volume_list->addColumn("Digest");
  volume_list->setColumnWidth(5, 78);
  volume_list->addColumn("File System");
  volume_list->addColumn("Mode");
  volume_list->setColumnWidth(7, 78);
  volume_list->addColumn("Size");
  volume_list->setColumnWidth(8, 78);
  volume_list->setColumnAlignment(8, Qt::AlignRight);
  volume_list->setAllColumnsShowFocus(true);
  volume_list->setSelectionMode(QListView::Extended);
  msg = NULL;
  option = NULL;
  volume = NULL;
  LoadVolumeList();
  connect(container_browse, SIGNAL(clicked()), container_dialog, SLOT(exec()));
  connect(container_dialog, SIGNAL(fileSelected(const QString&)),
          container_line, SLOT(setText(const QString&)));
  connect(container_line, SIGNAL(textChanged(const QString&)),
          this, SLOT(SetContainer(const QString&)));
  connect(mnt_point_browse, SIGNAL(clicked()), this, SLOT(BrowseMountPoint()));
  connect(mnt_point_line, SIGNAL(textChanged(const QString&)),
          this, SLOT(SetMountPoint(const QString&)));
  connect(volume_list, SIGNAL(selectionChanged(QListViewItem*)),
          this, SLOT(SetVolume(QListViewItem*)));
  connect(mount, SIGNAL(clicked()), this, SLOT(Mount()));
  connect(umount, SIGNAL(clicked()), this, SLOT(UnMount()));
  connect(create, SIGNAL(clicked()), this, SLOT(Create()));
  connect(change, SIGNAL(clicked()), this, SLOT(Change()));
}

Scramdisk::~Scramdisk()
{
  if (msg)
    delete msg;
  for (int fs_id = 0; fs_id < SD_FSTYPES; ++fs_id)
    delete fstype_buttons[fs_id];
  delete fstype_group;
  delete pp_dialog;
  delete volume_list;
  delete menubar;
  delete file_menu;
  delete pp_menu;
  delete option_menu;
  delete about_menu;
  delete sd_pxm;
  delete mount_icon;
  delete umount_icon;
  delete create_icon;
  delete change_icon;
  delete mount_pxm;
  delete umount_pxm;
  delete create_pxm;
  delete change_pxm;
  delete mount;
  delete umount;
  delete create;
  delete change;
  delete container_label;
  delete container_line;
  delete container_browse;
  delete mnt_point_label;
  delete mnt_point_line;
  delete mnt_point_browse;
  delete rdonly_label;
  delete read_only;
  delete action_box;
  delete container_box;
  delete mnt_point_box;
  delete options_box;
  delete group;
  delete container_dialog;
}

void Scramdisk::ClearVolumeText(QListViewItem* vol_it)
{
  QString empty;
  for (int j = 1; j < 9; ++j)
    vol_it->setText(j, empty);
}

void Scramdisk::SetVolumeText(int j, QListViewItem* vol_it)
{
  int fd;
  bool selectable = false;
  sd_info_t sd_info;
  sd_info.slot = j;
  sd_info.rd_only = 0;
  sd_info.uid = 0u;
  sd_info.size = 0u;
  sd_info.container = new char[PATH_MAX];
  sd_info.mnt_point = new char[PATH_MAX];
  sd_info.cphr_id = undef_cipher;
  sd_info.dgst_id = undef_digest;
  fd = open("/dev/scramdisk/master", O_RDONLY);
  if (fd > 0 && ioctl(fd, SCRAMDISK_IOC_INQUIRE, &sd_info) > 0)
  {
    char str_sz[16];
    char str_fs[16];
    const char* mode;
    const char* owner = getpwuid(sd_info.uid)->pw_name;
    if (sd_info.rd_only < 0)
    {
      mode = "-";
      strcpy(str_sz, "-");
      strcpy(str_fs, "-");
    }
    else
    {
      FILE* fmt;
      struct mntent* pmnt;

      fmt = setmntent(_PATH_MOUNTED, "r");
      if (fmt != NULL)
      {
        while ((pmnt = getmntent(fmt)) != NULL)
        {
          if (strcmp(pmnt->mnt_fsname, sd_info.container) == 0)
            break;
        }
        endmntent(fmt);
        if (pmnt != NULL)
          strcpy(str_fs, pmnt->mnt_type);
        else
          strcpy(str_fs, "none");
      }
      else
        strcpy(str_fs, "-");
      mode = sd_info.rd_only ? "read only" : "read/write";
      if (sd_info.size >> 10 > 99999)
        sprintf(str_sz, "%u MB", sd_info.size >> 20);
      else
        sprintf(str_sz, "%u KB", sd_info.size >> 10);
      selectable = true;
    }
    vol_it->setText(1, owner);
    vol_it->setText(2, sd_info.container);
    vol_it->setText(3, sd_info.mnt_point);
    vol_it->setText(4, cipher_name(sd_info.cphr_id));
    vol_it->setText(5, digest_name(sd_info.dgst_id));
    vol_it->setText(6, str_fs);
    vol_it->setText(7, mode);
    vol_it->setText(8, str_sz);
    vol_it->setSelectable(selectable);
  }
}

void Scramdisk::LoadVolumeList()
{
  for (int j = 1; j < MAX_SLOTS; ++j)
  {
    char dev[32];
    sprintf(dev, "/dev/scramdisk/vol%2.2d", j);
    QListViewItem* vol_it = new QListViewItem(volume_list, dev);
    SetVolumeText(j, vol_it);
  }
}

void Scramdisk::Configure()
{
  QString entry;
  QListViewItem* sec_it;
  QListViewItem* opt_it;
  QSettings* config = new QSettings;
  config->insertSearchPath(QSettings::Unix, cfg_dir);
  config->setPath("scramdisk4linux.de", "scramdisk", QSettings::User);
  QDialog config_dialog(this);
  config_dialog.setCaption("Scramdisk Configuration");
  QVBox vbox(&config_dialog);
  vbox.setMargin(10);
  vbox.setSpacing(8);
  vbox.setMinimumHeight(550);
  vbox.setMinimumWidth(800);
  QVGroupBox frame(&vbox);
  QLabel label("Select and Item and click on the value you want to change "
               "or browse for pathnames", &frame);
  label.setFont(QFont("Times", 11));
  QListView config_list(&frame);
  config_list.addColumn("Option", 150);
  config_list.addColumn("Type", 90);
  config_list.addColumn("Value", 500);
  config_list.setDefaultRenameAction(QListView::Accept);
  sec_it = new QListViewItem(&config_list, "sdchange");
  sec_it->setOpen(true);
  sec_it->setSelectable(false);
  entry = config->readEntry("/scramdisk/sdchange/container");
  opt_it = new QListViewItem(sec_it, "container", "pathname", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdchange/show-pass");
  opt_it = new QListViewItem(sec_it, "show-pass", "boolean", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdchange/use-backup");
  opt_it = new QListViewItem(sec_it, "use-backup", "boolean", entry);
  opt_it->setRenameEnabled(2, true);
  sec_it = new QListViewItem(&config_list, "sdcreate");
  sec_it->setOpen(true);
  sec_it->setSelectable(false);
  entry = config->readEntry("/scramdisk/sdcreate/cipher");
  opt_it = new QListViewItem(sec_it, "cipher", "cipher", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdcreate/container");
  opt_it = new QListViewItem(sec_it, "container", "pathname", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdcreate/digest");
  opt_it = new QListViewItem(sec_it, "digest", "digest", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdcreate/fs-type");
  opt_it = new QListViewItem(sec_it, "fs-type", "filesystem", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdcreate/kb");
  opt_it = new QListViewItem(sec_it, "kb", "integer", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdcreate/mb");
  opt_it = new QListViewItem(sec_it, "mb", "integer", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdcreate/mkfs-command");
  opt_it = new QListViewItem(sec_it, "mkfs-command", "pathname", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdcreate/no-fs");
  opt_it = new QListViewItem(sec_it, "no-fs", "boolean", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdcreate/random");
  opt_it = new QListViewItem(sec_it, "random", "pathname", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdcreate/show-pass");
  opt_it = new QListViewItem(sec_it, "show-pass", "boolean", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdcreate/win-compatible");
  opt_it = new QListViewItem(sec_it, "win-compatible", "boolean", entry);
  opt_it->setRenameEnabled(2, true);
  sec_it = new QListViewItem(&config_list, "sdmount");
  sec_it->setOpen(true);
  sec_it->setSelectable(false);
  entry = config->readEntry("/scramdisk/sdmount/container");
  opt_it = new QListViewItem(sec_it, "container", "pathname", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdmount/fs-type");
  opt_it = new QListViewItem(sec_it, "fs-type", "filesystem", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdmount/mount-point");
  opt_it = new QListViewItem(sec_it, "mount-point", "pathname", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdmount/no-fs");
  opt_it = new QListViewItem(sec_it, "no-fs", "boolean", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdmount/read-only");
  opt_it = new QListViewItem(sec_it, "read-only", "boolean", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdmount/show-pass");
  opt_it = new QListViewItem(sec_it, "show-pass", "boolean", entry);
  opt_it->setRenameEnabled(2, true);
  sec_it = new QListViewItem(&config_list, "sdumount");
  sec_it->setOpen(true);
  sec_it->setSelectable(false);
  entry = config->readEntry("/scramdisk/sdumount/container");
  opt_it = new QListViewItem(sec_it, "container", "pathname", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdumount/mount-point");
  opt_it = new QListViewItem(sec_it, "mount-point", "pathname", entry);
  opt_it->setRenameEnabled(2, true);
  entry = config->readEntry("/scramdisk/sdumount/no-fs");
  opt_it = new QListViewItem(sec_it, "no-fs", "boolean", entry);
  opt_it->setRenameEnabled(2, true);
  delete config;
  QHBox box(&vbox);
  box.setSpacing(40);
  QPushButton browse("Browse", &box);
  browse.setFont(QFont("Times", 11, QFont::Bold));
  QPushButton cancel("Cancel", &box);
  cancel.setFont(QFont("Times", 11, QFont::Bold));
  QPushButton ok("OK", &box);
  ok.setFont(QFont("Times", 11, QFont::Bold));
  ok.setDefault(true);
  connect(&browse, SIGNAL(clicked()), this, SLOT(SetPath()));
  connect(&cancel, SIGNAL(clicked()), &config_dialog, SLOT(reject()));
  connect(&ok, SIGNAL(clicked()), &config_dialog, SLOT(accept()));
  connect(&config_list, SIGNAL(selectionChanged(QListViewItem*)),
          this, SLOT(SetOption(QListViewItem*)));
  connect(&config_list, SIGNAL(selectionChanged(QListViewItem*)),
          this, SLOT(SetItemText(QListViewItem*)));
  connect(&config_list, SIGNAL(itemRenamed(QListViewItem*, int)),
          this, SLOT(CheckOption(QListViewItem*, int)));
  if (config_dialog.exec() == QDialog::Accepted)
  {
    QSettings settings;
    settings.insertSearchPath(QSettings::Unix, cfg_dir);
    QListViewItemIterator it(&config_list);
    while (it.current())
    {
      if (it.current()->parent())
      {
        QString opt("/scramdisk/");
        opt.append(it.current()->parent()->text(0));
        opt.append("/");
        opt.append(it.current()->text(0));
        if (it.current()->text(2).isEmpty())
          settings.removeEntry(opt);
        else
          settings.writeEntry(opt, it.current()->text(2));
        if (it.current()->parent()->text(0) == "sdcreate" &&
            !it.current()->text(2).isEmpty())
        {
          if (it.current()->text(0) == "cipher")
          {
            for (int j = 0; j < 8; ++j)
            {
              if (it.current()->text(2) == cipher_name(j).lower())
              {
                cphr = j;
                break;
              }
            }
          }
          else if (it.current()->text(0) == "digest")
          {
            for (int j = 0; j < 3; ++j)
            {
              if (it.current()->text(2) == digest_name(j).lower())
              {
                dgst = j;
                break;
              }
            }
          }
          else if (it.current()->text(0) == "fs-type")
          {
            if (it.current()->text(2) == "ext2")
              fs = 1;
            else if (it.current()->text(2) == "ext3")
              fs = 2;
            else if (it.current()->text(2) == "reiserfs")
              fs = 3;
            else if (it.current()->text(2) == "minix")
              fs = 4;
            else if (it.current()->text(2) == "vfat")
              fs = 5;
            else if (it.current()->text(2) == "msdos")
              fs = 5;
          }
          else if (it.current()->text(0) == "kb")
          {
            size = it.current()->text(2).toInt();
            unit = 0;
          }
          else if (it.current()->text(0) == "mb")
          {
            size = it.current()->text(2).toInt();
            unit = 1;
          }
          else if (it.current()->text(0) == "no-fs")
          {
            if (it.current()->text(2) == "true")
              fs = 6;
          }
          else if (it.current()->text(0) == "win-compatible")
            win = it.current()->text(2) != "false";
          else if (it.current()->text(0) == "random")
            rnd_dev = it.current()->text(2);
          else if (it.current()->text(0) == "mkfs-command")
            mkfs_cmd = it.current()->text(2);
        }
      }
      ++it;
    }
  }
  option = NULL;
}

void Scramdisk::SetPath()
{
  if (option && option->text(1) == "pathname")
  {
    QString path;
    if (option->text(0).contains("mount-point"))
      path = QFileDialog::getExistingDirectory(home_dir, this);
    else
      path = QFileDialog::getSaveFileName(home_dir, QString::null, this);
    if (!path.isNull())
      option->setText(2, path);
  }
}

void Scramdisk::SetOption(QListViewItem* v)
{
  option = v;
}

void Scramdisk::SetItemText(QListViewItem* v)
{
  item_text = v->text(2);
}

void Scramdisk::CheckOption(QListViewItem* v, int col)
{
  if (col == 2)
  {
    bool ok = false;
    if (v->text(1) == "boolean")
    {
      if (v->text(2).lower() == "true" || v->text(2).lower() == "false")
      {
        v->setText(2, v->text(2).lower());
        ok = true;
      }
      else if (v->text(2).isEmpty())
        ok = true;
    }
    else if (v->text(1) == "integer")
    {
      uint w = v->text(2).toUInt();
      if (w > 0u)
      {
        v->setText(2, QString::number(w));
        if (v->text(0) == "kb")
        {
          if (w <= 9999)
            v->itemBelow()->setText(2, QString());
          else
          {
            v->setText(2, QString());
            v->itemBelow()->setText(2, QString::number(w >> 10));
          }
        }
        if (v->text(0) == "mb")
          v->itemAbove()->setText(2, QString());
        ok = true;
      }
      else if (v->text(2).isEmpty())
        ok = true;
    }
    else if (v->text(1) == "cipher")
    {
      for (int j = 0; j < 8; ++j)
      {
        if (v->text(2).lower() == cipher_name(j).lower())
        {
          v->setText(2, v->text(2).lower());
          ok = true;
          break;
        }
      }
      if (v->text(2).isEmpty())
        ok = true;
    }
    else if (v->text(1) == "digest")
    {
      for (int j = 0; j < 3; ++j)
      {
        if (v->text(2).lower() == digest_name(j).lower())
        {
          v->setText(2, v->text(2).lower());
          ok = true;
          break;
        }
      }
      if (v->text(2).isEmpty())
        ok = true;
    }
    else if (v->text(1) == "filesystem")
    {
      for (int j = 0; j < 7; ++j)
      {
        if (v->text(2).lower() == fs_name(j))
        {
          v->setText(2, v->text(2).lower());
          ok = true;
          break;
        }
      }
      if (v->text(2).isEmpty())
        ok = true;
    }
    else if (v->text(1) == "pathname")
      ok = true;
    if (!ok)
    {
      QString warn("The value must be of type ");
      if (v->text(1) == "integer")
        warn.append("positive ");
      warn.append(v->text(1));
      warn.append("\nResetting it to its previous value");
      if (msg)
        delete msg;
      msg = new QMessageBox(this, "msg");
      msg->setCaption("Scramdisk Configuration");
      msg->setText(warn);
      msg->setButtonText(0, "OK");
      msg->setIcon(QMessageBox::Warning);
      msg->exec();
      v->setText(2, item_text);
    }
  }
  else
    ErrorMessage("Illegal rename action in column", QString::number(col));
}

void Scramdisk::PrintVersion()
{
  QString ver("Scramdisk Version\t\n\t");
  ver.append(SD_VERSION);
  if (msg)
    delete msg;
  msg = new QMessageBox(this, "msg");
  msg->setCaption("Scramdisk Version");
  msg->setText(ver);
  msg->setButtonText(0, "OK");
  msg->setIcon(QMessageBox::Information);
  msg->exec();
}

void Scramdisk::Documentation()
{
  QDialog dialog(this);
  QVBox vbox(&dialog);
  dialog.setCaption("Scramdisk Documentation");
  vbox.setMargin(10);
  vbox.setSpacing(8);
  vbox.setMinimumHeight(900);
  vbox.setMinimumWidth(720);
  QTextBrowser browser(&vbox);
  browser.setSource("/usr/share/scramdisk/index.html");
  QHBox hbox(&vbox);
  hbox.setSpacing(20);
  QPushButton b_home("Home", &hbox);
  b_home.setFont(QFont("Times", 11, QFont::Bold));
  QPushButton b_backward("Backward", &hbox);
  b_backward.setFont(QFont("Times", 11, QFont::Bold));
  QPushButton b_forward("Forward", &hbox);
  b_forward.setFont(QFont("Times", 11, QFont::Bold));
  QPushButton b_close("Close", &hbox);
  b_close.setFont(QFont("Times", 11, QFont::Bold));
  connect(&b_home, SIGNAL(clicked()), &browser, SLOT(home()));
  connect(&b_backward, SIGNAL(clicked()), &browser, SLOT(backward()));
  connect(&b_forward, SIGNAL(clicked()), &browser, SLOT(forward()));
  connect(&b_close, SIGNAL(clicked()), &dialog, SLOT(close()));
  dialog.exec();
}

void Scramdisk::Mount()
{
  int rdonly = 0;
  unsigned long flags = MS_MGC_VAL | MS_NODEV;
  uid_t uid = getuid();
  MTabLock mtl;
  
  if (access(container.ascii(), F_OK | R_OK) != 0)
  {
    ErrorMessage("No access to container file", container.ascii());
    return;
  }
  if (read_only->isChecked() || access(container.ascii(), F_OK | W_OK) != 0)
  {
    rdonly = 1;
    flags |= MS_RDONLY;
  }
  if (!pp_dialog->Set())
    pp_dialog->exec();
  if (!pp_dialog->Set())
  {
    ErrorMessage("Sorry, a Passphrase must be given!");
    return;
  }
  if (seteuid(0) == 0 && mtl.Lock())
  {
    int ret;
    int slotno;
    char* usr;
    char fsname[32];
    char device[32];
    char options[256];
    FILE* fmt;
    struct mntent mnt;
    struct mntent* pmnt;
    SdMount sd_mount(Mnt);
    QListViewItem* vol_it;

    if (!sd_mount.Good())
    {
      ErrorMessage("No more memory");
      mtl.UnLock();
      seteuid(uid); // ignore erros
      return;
    }
    sd_mount.SetReadOnly(rdonly);
    if (realpath(container.ascii(), sd_mount.Filename()) == NULL)
    {
      ErrorMessage("Couldn't resolve container pathname",
                   QString::fromUtf8(strerror(errno)));
      mtl.UnLock();
      seteuid(uid); // ignore erros
      return;
    }
    fmt = setmntent(_PATH_MOUNTED, "r");
    if (fmt == NULL)
    {
      ErrorMessage("Could not open", _PATH_MOUNTED);
      seteuid(uid); // ignore erros
      return;
    }
    while ((pmnt = getmntent(fmt)) != NULL)
    {
      if (strcmp(pmnt->mnt_fsname, sd_mount.Filename()) == 0)
        break;
    }
    endmntent(fmt);
    if (pmnt != NULL)
    {
      ErrorMessage("Container file already mounted:", sd_mount.Filename());
      mtl.UnLock();
      seteuid(uid); // ignore erros
      return;
    }
    if (fstype_group->selectedId() != 7)
    {
      if (realpath(mnt_point.ascii(), sd_mount.MountPoint()) == NULL)
      {
        ErrorMessage("Couldn't resolve mount point pathname",
                     QString::fromUtf8(strerror(errno)));
        mtl.UnLock();
        seteuid(uid); // ignore erros
        return;
      }
      fmt = setmntent(_PATH_MOUNTED, "r");
      if (fmt == NULL)
      {
        ErrorMessage("Could not open", _PATH_MOUNTED);
        seteuid(uid); // ignore erros
        return;
      }
      while ((pmnt = getmntent(fmt)) != NULL)
      {
        if (strcmp(pmnt->mnt_dir, sd_mount.MountPoint()) == 0)
          break;
      }
      endmntent(fmt);
      if (pmnt != NULL)
      {
        ErrorMessage("Mount point already in use:", sd_mount.MountPoint());
        mtl.UnLock();
        seteuid(uid); // ignore erros
        return;
      }
    }
    else
      strcpy(sd_mount.MountPoint(), "-");
    sd_mount.SetPhrase(pp_dialog->Passphrase(), 160u);
    slotno = sd_mount.Mount();
    if (slotno == -2 && errno == EBUSY)
    {
      ErrorMessage("No free slot to mount");
      mtl.UnLock();
      seteuid(uid); // ignore erros
      return;
    }
    else if (slotno == -2 && errno == EEXIST)
    {
      ErrorMessage("Container file already mounted:", sd_mount.Filename());
      mtl.UnLock();
      seteuid(uid); // ignore erros
      return;
    }
    else if (slotno == -2 && errno == EACCES)
    {
      ErrorMessage("Sorry, the passphrase is wrong");
      mtl.UnLock();
      seteuid(uid); // ignore erros
      pp_dialog->Clear();
      return;
    }
    else if (slotno < 0)
    {
      ErrorMessage("Mounting failed:", QString::fromUtf8(strerror(errno)));
      mtl.UnLock();
      seteuid(uid); // ignore erros
      return;
    }
    sprintf(device, "/dev/scramdisk/vol%2.2d", slotno);
    if (fstype_group->selectedId() != 7)
    {
      if (fstype_group->selectedId() == 0)
      {
        int fstype;
        ret = 1;
        for (fstype = 1; ret && fstype < 7; ++fstype)
        {
          errno = 0;
          strcpy(fsname, fs_name(fstype).ascii());
          ret = ::mount(device, sd_mount.MountPoint(), fsname, flags, NULL);
        }
      }
      else
      {
        strcpy(fsname, fs_name(fstype_group->selectedId()).ascii());
        ret = ::mount(device, sd_mount.MountPoint(), fsname, flags, NULL);
      }
      if (ret)
      {
        ErrorMessage("Could not mount device:",
                     QString::fromUtf8(strerror(errno)));
        mtl.UnLock();
        seteuid(uid); // ignore erros
        return;
      }
      usr = getenv("USER");
      if (usr != NULL)
      {
        strcpy(options, sd_mount.ReadOnly() ? "ro,user=" : "rw,user=");
        strncat(options, usr, 247);
      }
      else
        strcpy(options, sd_mount.ReadOnly() ? "ro" : "rw");
      mnt.mnt_fsname = sd_mount.Filename();
      mnt.mnt_dir = sd_mount.MountPoint();
      mnt.mnt_type = fsname;
      mnt.mnt_opts = options;
      mnt.mnt_freq = 0;
      mnt.mnt_passno = 0;
      fmt = setmntent(_PATH_MOUNTED, "a");
      if (fmt != NULL)
      {
        addmntent(fmt, &mnt);
        endmntent(fmt);
      }
      else
      {
        ErrorMessage("Could not add entry to", _PATH_MOUNTED);
        QString warn("Could not add entry to " _PATH_MOUNTED);
        if (msg)
          delete msg;
        msg = new QMessageBox(this, "msg");
        msg->setCaption("Scramdisk Mount");
        msg->setText(warn);
        msg->setButtonText(0, "OK");
        msg->setIcon(QMessageBox::Warning);
        msg->exec();
      }
    }
    vol_it = volume_list->findItem(device, 0);
    if (vol_it != NULL)
    {
      SetVolumeText(slotno, vol_it);
      vol_it->setSelected(true);
    }
  }
  else
    ErrorMessage("Could not lock", _PATH_MOUNTED);
  mtl.UnLock();
  seteuid(uid); // ignore erros
  return;
}

void Scramdisk::UnMount()
{
  uid_t uid = getuid();

  for (int j = 1; j < MAX_SLOTS; ++j)
  {
    char device[32];
    sprintf(device, "/dev/scramdisk/vol%2.2d", j);
    QListViewItem* vol_it = volume_list->findItem(device, 0);

    if (vol_it->isSelected() && !vol_it->text(2).isEmpty())
    {
      MTabLock mtl;
      SdMount sd_mount(UMnt);

      if (!sd_mount.Good())
      {
        ErrorMessage("No more memory");
        return;
      }
      strcpy(sd_mount.Filename(), vol_it->text(2).ascii());
      strcpy(sd_mount.MountPoint(), vol_it->text(3).ascii());
      if (vol_it->text(6) != "none" && seteuid(0) == 0 && mtl.Lock())
      {
        bool mounted = false;
        FILE* fmt;
        struct mntent* pmnt;
        class MTabContainer mtab;

        fmt = setmntent(_PATH_MOUNTED, "r");
        if (fmt == NULL)
        {
          ErrorMessage("Could not open", _PATH_MOUNTED);
          mtl.UnLock();
          seteuid(uid); // ignore erros
          continue;
        }
        while ((pmnt = getmntent(fmt)) != NULL)
        {
          if (!mounted && vol_it->text(2) == pmnt->mnt_fsname)
          {
            mounted = true;
            if (vol_it->text(3) != pmnt->mnt_dir)
            {
              ErrorMessage("Wrong mount point in " _PATH_MOUNTED ":",
                           pmnt->mnt_dir);
              endmntent(fmt);
              mtl.UnLock();
              seteuid(uid); // ignore erros
              continue;
            }
          }
          else
            mtab.Add(pmnt);
        }
        endmntent(fmt);
        if (!mounted)
        {
          ErrorMessage("Container seems not to be mounted:", vol_it->text(2));
          mtl.UnLock();
          seteuid(uid); // ignore erros
          continue;
        }
        if (::umount(sd_mount.MountPoint()))
        {
          ErrorMessage("Could not unmount container:",
                       QString::fromUtf8(strerror(errno)));
          mtl.UnLock();
          seteuid(uid); // ignore erros
          continue;
        }
        fmt = setmntent(MOUNTED_TMP, "w");
        while ((pmnt = mtab.Next()) != NULL)
        {
          addmntent(fmt, pmnt);
          mtab.Step();
        }
        endmntent(fmt);
        rename(MOUNTED_TMP, _PATH_MOUNTED);
        mtl.UnLock();
      }
      seteuid(uid); // ignore erros
      if (!sd_mount.UMount())
      {
        ErrorMessage("Couldn't unmount device", vol_it->text(2));
        continue;
      }
      vol_it->setSelected(false);
      ClearVolumeText(vol_it);
    }
  }
  return;
}

void Scramdisk::Create()
{
  int result;
  uid_t uid = getuid();
  gid_t gid = getgid();
  CreateDialog create_dialog(this, win, dgst, cphr, fs, size, unit);
  QSettings* config = new QSettings;

  config->insertSearchPath(QSettings::Unix, cfg_dir);
  config->setPath("scramdisk4linux.de", "scramdisk", QSettings::User);
  QString entry = config->readEntry("/scramdisk/sdcreate/container");
  delete config;

  if (!entry.isEmpty())
  {
    QFileInfo finfo(entry);
    if (finfo.isWritable())
    {
      container = entry;
      container_dialog->setDir(finfo.dirPath(true));
    }
    else
      container_dialog->setDir(home_dir);
  }
  result = container_dialog->exec();
  if (result == QDialog::Accepted)
    result = create_dialog.exec();
  if (result == QDialog::Accepted && seteuid(uid) == 0)
  {
    if (!pp_dialog->Set())
      pp_dialog->exec();
    if (!pp_dialog->Set())
    {
      ErrorMessage("Sorry, a Passphrase must be given!");
      return;
    }
    if (pp_dialog->Verify())
    {
      QString digest(digest_name(create_dialog.DigestId()).lower());
      SdContext sdctx(container.ascii(), create_dialog.WinCompatible());
      if (!sdctx.HashPhrase(digest.ascii(), pp_dialog->Passphrase(), 160u))
      {
        ErrorMessage("Sorry, the digest is not supported:", digest);
        return;
      }
      if (sdctx.Ready())
      {
        size_t size;
        int fs_id = create_dialog.FsId();
        unsigned int blocks = 2u*create_dialog.Size();
        unsigned int j = 0u;
        bool ok = true;
        octet header_buf[HEADER_BLOCK_SIZE];
        octet stock1_buf[HEADER_BLOCK_SIZE];
        octet stock2_buf[HEADER_BLOCK_SIZE];
        octet backup_buf[HEADER_BLOCK_SIZE];
        octet sect_buf[SD_BLOCK_SIZE];
        Random rnd(rnd_dev.ascii());
        QString cipher(cipher_name(create_dialog.CipherId()).lower());

        size = rnd.Gather(this, 2u*HEADER_BLOCK_SIZE + SD_BLOCK_SIZE);
        if (size != 2u*HEADER_BLOCK_SIZE + SD_BLOCK_SIZE)
        {
          remove(container.ascii());
          return;
        }
        rnd.Get(header_buf, HEADER_BLOCK_SIZE);
        QProgressDialog progress(this);
        progress.setCaption("Scramdisk Create");
        progress.setLabelText("Encrypting and writing container file");
        progress.setCancelButtonText("Cancel");
        progress.setTotalSteps(static_cast<int>(blocks) + 20);
        progress.setProgress(0);
        qApp->processEvents();
        if (!sdctx.InitHashCipher(cipher.ascii()))
        {
          ErrorMessage("Sorry, the cipher is not supported:", cipher);
          return;
        }
        sdctx.SetWhiteTable(header_buf);
        sdctx.EncryptWhiteTable(header_buf);
        rnd.Get(stock1_buf, HEADER_BLOCK_SIZE);
        sdctx.EncryptWhiteTable(stock1_buf);
        memset(stock2_buf, 0, HEADER_BLOCK_SIZE);
        sdctx.EncryptWhiteTable(stock2_buf);
        memcpy(backup_buf, header_buf, HEADER_BLOCK_SIZE);
        sdctx.EncryptWhiteTable(backup_buf);
        sdctx.EncryptWhiteTable(backup_buf);
        if (!sdctx.Write(header_buf, HEADER_BLOCK_SIZE) ||
            !sdctx.Write(stock1_buf, HEADER_BLOCK_SIZE) ||
            !sdctx.Write(stock2_buf, HEADER_BLOCK_SIZE) ||
            !sdctx.Write(backup_buf, HEADER_BLOCK_SIZE))
        {
          ErrorMessage("Error writing to file", container);
          return;
        }
        progress.setProgress(16);
        qApp->processEvents();
        if (progress.wasCanceled())
        {
          remove(container.ascii());
          return;
        }
        rnd.Get(sect_buf, SD_BLOCK_SIZE);
        if (!sdctx.InitRealCipher(cipher.ascii()))
        {
          ErrorMessage("Sorry, the cipher is not supported:", cipher);
          return;
        }
        while (ok && j < 4u)
        {
          sdctx.EncryptSector(sect_buf, j++);
          ok = sdctx.Write(sect_buf, SD_BLOCK_SIZE);
          if (j < 3u)
            rnd.GetLast(sect_buf, SD_BLOCK_SIZE);
          else
            memset(sect_buf, 0, SD_BLOCK_SIZE);
        }
        if (!ok)
        {
          ErrorMessage("Error writing to file", container);
          return;
        }
        for (j = 0u; ok && j < blocks; ++j)
        {
          if (j%1024u == 0u)
          {
            progress.setProgress(static_cast<int>(j) + 20);
            qApp->processEvents();
            if (progress.wasCanceled())
            {
              remove(container.ascii());
              return;
            }
          }
          memset(sect_buf, 0, SD_BLOCK_SIZE);
          sdctx.EncryptSector(sect_buf, j + 4u);
          ok = sdctx.Write(sect_buf, SD_BLOCK_SIZE);
        }
        if (fs_id != 7)
        {
          int slotno;
          char* fsopt;
          char cmd[256];
          SdMount sd_mount(TmpMnt);
          if (!sd_mount.Good())
          {
            ErrorMessage("No more memory");
            return;
          }
          progress.setLabelText("Creating file system in container");
          progress.setTotalSteps(10);
          progress.setProgress(0);
          qApp->processEvents();
          sd_mount.SetPhrase(pp_dialog->Passphrase(), 160u);
          if (create_dialog.WinCompatible())
            fsopt = "msdos";
          else
          {
            switch (fs_id)
            {
              case 0:
              case 1:
                fsopt = "ext2";
                break;
              case 2:
                fsopt = "ext2 -j";
                break;
              case 3:
                fsopt = "reiserfs";
                break;
              case 4:
                fsopt = "minix";
                break;
              case 5:
              case 6:
                fsopt = "msdos";
                break;
              default:
                ErrorMessage("Can't create a filesystem", fs_name(fs_id));
                return;
            }
          }
          if (realpath(container.ascii(), sd_mount.Filename()) == NULL)
          {
            ErrorMessage("Couldn't resolve container pathname:",
                         QString::fromUtf8(strerror(errno)));
            return;
          }
          slotno = sd_mount.Mount();
          if (slotno == -2 && errno == EBUSY)
          {
            ErrorMessage("No free slot to mount");
            return;
          }
          else if (slotno == -2 && errno == EEXIST)
          {
            ErrorMessage("Container file already mounted:",
                         sd_mount.Filename());
            return;
          }
          else if (slotno == -2 && errno == EACCES)
          {
            ErrorMessage("Sorry, the passphrase is wrong");
            return;
          }
          else if (slotno < 0)
          {
            ErrorMessage("Mounting failed:",
                         QString::fromUtf8(strerror(errno)));
            return;
          }
          progress.setProgress(1);
          qApp->processEvents();
          if (progress.wasCanceled())
          {
            remove(container.ascii());
            return;
          }
          if (snprintf(cmd, 256ul, "%s -t %s /dev/scramdisk/vol%2.2d",
                       mkfs_cmd.ascii(), fsopt, slotno) == -1)
          {
            ErrorMessage("Command too long");
            return;
          }
          if (seteuid(0) == 0 && setreuid(0, 0) == 0)
          {
            if (system(cmd) == -1)
            {
              setreuid(uid, 0);
              seteuid(uid);
              ErrorMessage("Couldn't create file system:",
                           QString::fromUtf8(strerror(errno)));
              return;
            }
          }
          else
          {
            setreuid(uid, 0);
            seteuid(uid);
            ErrorMessage("Couldn't change user ID to super user:",
                         QString::fromUtf8(strerror(errno)));
            return;
          }
          if (fs_id != 5 && fs_id != 6)
          {
            char tmpmnt[32];
            char device[32];
            char lostfound[64];
            progress.setProgress(2);
            qApp->processEvents();
            if (progress.wasCanceled())
            {
              remove(container.ascii());
              setreuid(uid, 0);
              seteuid(uid);
              return;
            }
            sprintf(device, "/dev/scramdisk/vol%2.2d", slotno);
            sprintf(tmpmnt, "/tmp/sdmnt-%u",
                    static_cast<unsigned int>(getpid()));
            strcpy(lostfound, tmpmnt);
            strcat(lostfound, "/lost+found");
            sleep(2);
            progress.setProgress(8);
            qApp->processEvents();
            if (mkdir(tmpmnt, 0755) == -1)
            {
              ErrorMessage("Couldn't create mount point:",
                           QString::fromUtf8(strerror(errno)));
              rmdir(tmpmnt);
              setreuid(uid, 0);
              seteuid(uid);
              return;
            }
            if (fs_id == 2)
              fsopt = "ext3";
            if (::mount(device, tmpmnt, fsopt, MS_MGC_VAL, NULL))
            {
              ErrorMessage("Couldn't mount device:",
                           QString::fromUtf8(strerror(errno)));
              rmdir(tmpmnt);
              setreuid(uid, 0);
              seteuid(uid);
              return;
            }
            progress.setProgress(9);
            qApp->processEvents();
            if (progress.wasCanceled())
            {
              remove(container.ascii());
              setreuid(uid, 0);
              seteuid(uid);
              return;
            }
            chown(tmpmnt, uid, gid);
            if (fs_id != 4)
              chown(lostfound, uid, gid);
            errno = 0; // ignore errors of chown
            if (::umount(tmpmnt))
            {
              ErrorMessage("Couldn't unmount device:",
                           QString::fromUtf8(strerror(errno)));
              setreuid(uid, 0);
              seteuid(uid);
              return;
            }
            if (rmdir(tmpmnt) == -1)
              ErrorMessage("Couldn't remove mount point:",
                           QString::fromUtf8(strerror(errno)));
          }
          progress.setProgress(10);
          qApp->processEvents();
          setreuid(uid, 0);
          seteuid(uid);
          errno = 0; // ignore errors of seteuid
          if (msg)
            delete msg;
          msg = new QMessageBox(this, "msg");
          msg->setCaption("Scramdisk Create");
          msg->setText("The container has been created successfully");
          msg->setButtonText(0, "OK");
          msg->setIcon(QMessageBox::Information);
          msg->exec();
        }
      }
    }
    else
    {
      QString warn("Passphrase could not be verified");
      if (msg)
        delete msg;
      msg = new QMessageBox(this, "msg");
      msg->setCaption("Scramdisk Create");
      msg->setText(warn);
      msg->setButtonText(0, "OK");
      msg->setIcon(QMessageBox::Warning);
      msg->exec();
    }
  }
}

void Scramdisk::Change()
{
  int result = QDialog::Accepted;
  if (!container_line->isModified())
    result = container_dialog->exec();
  if (result == QDialog::Accepted)
  {
    SdContext sdctx(container.ascii());
    octet header_buffer[HEADER_BLOCK_SIZE];
    octet backup_buffer[HEADER_BLOCK_SIZE];
    octet check_buffer[CHECK_BLOCK_SIZE];
    octet header_buf[HEADER_BLOCK_SIZE];
    octet backup_buf[HEADER_BLOCK_SIZE];
    octet check_buf[CHECK_BLOCK_SIZE];
    octet stock1_buf[HEADER_BLOCK_SIZE];
    octet stock2_buf[HEADER_BLOCK_SIZE];
    if (sdctx.Ready())
    {
      int j;
      int k = 0;
      bool pw_bad = true;
      bool use_backup;
      octet* p1;
      octet* p2;
      QString cipher;
      QString digest;
      QString info;

      j = QMessageBox::question(this, "Scramdisk Change",
                                "Use backup block to repair damaged container?",
                                QMessageBox::No | QMessageBox::Default,
                                QMessageBox::Yes, QMessageBox::NoButton);
      use_backup = j == QMessageBox::Yes;
      if (!pp_dialog->Set())
        pp_dialog->exec();
      if (!pp_dialog->Set())
      {
        ErrorMessage("Sorry, a Passphrase must be given!");
        return;
      }
      if (!sdctx.Read(header_buf, HEADER_BLOCK_SIZE) ||
          !sdctx.Read(stock1_buf, HEADER_BLOCK_SIZE) ||
          !sdctx.Read(stock2_buf, HEADER_BLOCK_SIZE) ||
          !sdctx.Read(backup_buf, HEADER_BLOCK_SIZE) ||
          !sdctx.Read(check_buf, CHECK_BLOCK_SIZE))
      {
        ErrorMessage("Error reading file", container);
        return;
      }
      for (j = 0; pw_bad && !digest_name(j).isNull(); ++j)
      {
        k = 0;
        digest = digest_name(j).lower();
        while (!cipher_name(k).isNull())
        {
          cipher = cipher_name(k).lower();
          memcpy(header_buffer, header_buf, HEADER_BLOCK_SIZE);
          memcpy(backup_buffer, backup_buf, HEADER_BLOCK_SIZE);
          memcpy(check_buffer, check_buf, CHECK_BLOCK_SIZE);
          if (!sdctx.HashPhrase(digest.ascii(), pp_dialog->Passphrase(), 160u))
          {
            ErrorMessage("Sorry, the digest is not supported:", digest);
            return;
          }
          if (!sdctx.InitHashCipher(cipher.ascii()))
          {
            ErrorMessage("Sorry, the cipher is not supported:", cipher);
            return;
          }
          if (use_backup)
          {
            sdctx.DecryptWhiteTable(backup_buffer);
            sdctx.DecryptWhiteTable(backup_buffer);
            sdctx.DecryptWhiteTable(backup_buffer);
            memcpy(header_buffer, backup_buffer, HEADER_BLOCK_SIZE);
          }
          else
          {
            sdctx.DecryptWhiteTable(header_buffer);
            memcpy(backup_buffer, header_buffer, HEADER_BLOCK_SIZE);
          }
          sdctx.SetWhiteTable(header_buffer);
          if (!sdctx.InitRealCipher(cipher.ascii()))
          {
            ErrorMessage("Sorry, the cipher is not supported:", cipher);
            return;
          }
          p1 = check_buffer + SD_BLOCK_SIZE;
          p2 = p1 + SD_BLOCK_SIZE;
          sdctx.DecryptSector(check_buffer, 0);
          sdctx.DecryptSector(p1, 1);
          sdctx.DecryptSector(p2, 2);
          if (memcmp(check_buffer, p1, SD_BLOCK_SIZE) == 0 ||
              memcmp(check_buffer, p2, SD_BLOCK_SIZE) == 0 ||
              memcmp(p1, p2, SD_BLOCK_SIZE) == 0)
          {
            pw_bad = false;
            break;
          }
          if (sdctx.BlockSize() == 16u && !sdctx.WinCompatible())
            sdctx.SetWinCompatible(true);
          else
          {
            sdctx.SetWinCompatible(false);
            ++k;
          }
        }
      }
      if (pw_bad)
      {
        if (use_backup)
          ErrorMessage("Sorry, the passphrase is wrong");
        else
          ErrorMessage("Sorry, the passphrase is wrong",
                       "If you are sure, try using the backup block");
        pp_dialog->Clear();
        return;
      }
      if (msg)
        delete msg;
      msg = new QMessageBox(this, "msg");
      msg->setCaption("Scramdisk Change");
      info = "OK, cipher is ";
      info.append(cipher);
      info.append(", digest is ");
      info.append(digest);
      msg->setText(info);
      msg->setButtonText(0, "OK");
      msg->setIcon(QMessageBox::Information);
      msg->exec();
      if (!sdctx.HashPhrase(digest.ascii(), pp_dialog->Passphrase(), 160u))
      {
        ErrorMessage("Sorry, the digest is not supported:", digest);
        return;
      }
      if (!sdctx.InitHashCipher(cipher.ascii()))
      {
        ErrorMessage("Sorry, the cipher is not supported:", cipher);
        return;
      }
      sdctx.DecryptWhiteTable(stock1_buf);
      sdctx.DecryptWhiteTable(stock2_buf);
      pp_dialog->SetNew();
      if (!pp_dialog->Set())
      {
        ErrorMessage("Sorry, a Passphrase must be given!");
        return;
      }
      if (!pp_dialog->Verify())
      {
        QString warn("Passphrase could not be verified, try again:");
        if (msg)
          delete msg;
        msg = new QMessageBox(this, "msg");
        msg->setCaption("Scramdisk Change");
        msg->setText(warn);
        msg->setButtonText(0, "OK");
        msg->setIcon(QMessageBox::Warning);
        msg->exec();
        pp_dialog->Clear();
        pp_dialog->exec();
        if (!pp_dialog->Verify())
        {
          warn = "Sorry, passphrases differ again";
          msg->setText(warn);
          msg->exec();
          return;
        }
      }
      if (!sdctx.HashPhrase(digest.ascii(), pp_dialog->Passphrase(), 160u))
      {
        ErrorMessage("Sorry, the digest is not supported:", digest);
        return;
      }
      if (!sdctx.InitHashCipher(cipher.ascii()))
      {
        ErrorMessage("Sorry, the cipher is not supported:", cipher);
        return;
      }
      if (!sdctx.Rewind())
      {
        ErrorMessage("Error rewinding file", container);
        return;
      }
      sdctx.EncryptWhiteTable(header_buffer);
      sdctx.EncryptWhiteTable(stock1_buf);
      sdctx.EncryptWhiteTable(stock2_buf);
      memcpy(backup_buffer, header_buffer, HEADER_BLOCK_SIZE);
      sdctx.EncryptWhiteTable(backup_buffer);
      sdctx.EncryptWhiteTable(backup_buffer);
      if (!sdctx.Write(header_buffer, HEADER_BLOCK_SIZE) ||
          !sdctx.Write(stock1_buf, HEADER_BLOCK_SIZE) ||
          !sdctx.Write(stock2_buf, HEADER_BLOCK_SIZE) ||
          !sdctx.Write(backup_buffer, HEADER_BLOCK_SIZE))
      {
        ErrorMessage("Error writing to file", container);
        return;
      }
      if (msg)
        delete msg;
      msg = new QMessageBox(this, "msg");
      msg->setCaption("Scramdisk Change");
      msg->setText("The passphrase has been changed successfully");
      msg->setButtonText(0, "OK");
      msg->setIcon(QMessageBox::Information);
      msg->exec();
    }
    else
    {
      ErrorMessage("Error opening file", container);
      return;
    }
  }
}

void Scramdisk::SetContainer(const QString& s)
{
  container = s;
}

void Scramdisk::SetMountPoint(const QString& s)
{
  mnt_point = s;
}

void Scramdisk::BrowseMountPoint()
{
  QString dir = home_dir;
  QFileInfo finfo(mnt_point_line->text());
  if (finfo.exists())
    dir = finfo.dirPath(true);
  QString path = QFileDialog::getExistingDirectory(dir, this);
  if (!path.isNull())
    mnt_point_line->setText(path);
}

void Scramdisk::SetVolume(QListViewItem* v)
{
  volume = v;
  container = v->text(2);
  mnt_point = v->text(3);
  container_line->setText(container);
  mnt_point_line->setText(mnt_point);
}

void Scramdisk::ErrorMessage(const QString& str, const QString& arg)
{
  QString err_str(str);
  if (msg)
    delete msg;
  if (!arg.isEmpty())
  {
    err_str.append("\n");
    err_str.append(arg);
  }
  msg = new QMessageBox(this, "msg");
  msg->setCaption("Scramdisk - Error:");
  msg->setText(err_str);
  msg->setButtonText(0, "OK");
  msg->setIcon(QMessageBox::Critical);
  msg->exec();
}

int main(int argc, char **argv)
{
  uid_t uid = getuid();

  if (seteuid(uid) == 0)
  {
    QApplication app(argc, argv);

    Scramdisk* sd = new Scramdisk;
    app.setMainWidget(sd);
    sd->show();
    return app.exec();
  }
  else
    return 1;
}
