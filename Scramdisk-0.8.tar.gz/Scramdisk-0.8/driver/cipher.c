/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: cipher.c,v 1.2 2005/08/11 20:49:30 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: cipher.c,v $
 *  Revision 1.2  2005/08/11 20:49:30  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <linux/slab.h>
#include "cipher.h"

#define DES_FULLKEYSZ 8
#define DES3_FULLKEYSZ 24

/* Reverse the byte order of the buffer
 */
void reorder_memory(octet* buf, size_t size)
{
  size_t n;
  octet tmp;

  for (n = 3u; n < size; n += 4u)
  {
    tmp = buf[n];
    buf[n] = buf[n-3u];
    buf[n-3u] = tmp;
    
    tmp = buf[n-1u];
    buf[n-1u] = buf[n-2u];
    buf[n-2u] = tmp;
  }
}

/* Initialize the cipher with provided key
 * Attention:
 * except for Blowfish the key size must be the fixed cipher key size or greater
 */
void init_cipher(cipher_t* cphr, cipher_id id, const octet* key, size_t ksz)
{
  cphr->id = undef_cipher;
  cphr->name = NULL;
  cphr->block_size = 0u;
  cphr->key_size = 0u;
  cphr->ctx = NULL;
  switch (id)
  {
    case aes:
      cphr->ctx = kmalloc(sizeof(rijndael_ctx), GFP_KERNEL);
      if (cphr->ctx != NULL)
      {
        cphr->id = id;
        cphr->name = "AES";
        cphr->block_size = RIJNDAEL_BLKSZ;
        cphr->key_size = RIJNDAEL_KEYSZ;
        rijndael_init((rijndael_ctx*) cphr->ctx, key, RIJNDAEL_KEYSZ);
      }
      break;
    case blowfish:
      cphr->ctx = kmalloc(sizeof(blowfish_ctx), GFP_KERNEL);
      if (cphr->ctx != NULL)
      {
        cphr->id = id;
        cphr->name = "Blowfish";
        cphr->block_size = BLOWFISH_BLKSZ;
        if (ksz > BLOWFISH_KEYSZ)
          ksz = BLOWFISH_KEYSZ;
        cphr->key_size = ksz;
        blowfish_init((blowfish_ctx*) cphr->ctx, key, ksz);
      }
      break;
    case des:
      cphr->ctx = kmalloc(sizeof(des_ctx), GFP_KERNEL);
      if (cphr->ctx != NULL)
      {
        cphr->id = id;
        cphr->name = "DES";
        cphr->block_size = DES_BLKSZ;
        cphr->key_size = DES_FULLKEYSZ;
        des_init((des_ctx*) cphr->ctx, key, DES_FULLKEYSZ);
      }
      break;
    case des3:
      cphr->ctx = kmalloc(sizeof(des3_ctx), GFP_KERNEL);
      if (cphr->ctx != NULL)
      {
        cphr->id = id;
        cphr->name = "DES3";
        cphr->block_size = DES3_BLKSZ;
        cphr->key_size = DES3_FULLKEYSZ;
        des3_init((des3_ctx*) cphr->ctx, key, DES3_FULLKEYSZ);
      }
      break;
    case serpent:
      cphr->ctx = kmalloc(sizeof(serpent_ctx), GFP_KERNEL);
      if (cphr->ctx != NULL)
      {
        cphr->id = id;
        cphr->name = "Serpent";
        cphr->block_size = SERPENT_BLKSZ;
        cphr->key_size = SERPENT_KEYSZ;
        serpent_init((serpent_ctx*) cphr->ctx, key, SERPENT_KEYSZ);
      }
      break;
    case square:
      cphr->ctx = kmalloc(sizeof(square_ctx), GFP_KERNEL);
      if (cphr->ctx != NULL)
      {
        cphr->id = id;
        cphr->name = "Square";
        cphr->block_size = SQUARE_BLKSZ;
        cphr->key_size = SQUARE_KEYSZ;
        square_init((square_ctx*) cphr->ctx, key, SQUARE_KEYSZ);
      }
      break;
    case tea:
      cphr->ctx = kmalloc(sizeof(tea_ctx), GFP_KERNEL);
      if (cphr->ctx != NULL)
      {
        octet k[TEA_KEYSZ];
        memcpy(k, key, TEA_KEYSZ);
        reorder_memory(k, TEA_KEYSZ);
        cphr->id = id;
        cphr->name = "Tea";
        cphr->block_size = TEA_BLKSZ;
        cphr->key_size = TEA_KEYSZ;
        tea_init((tea_ctx*) cphr->ctx, k, TEA_KEYSZ);
        memset(k, 0, TEA_KEYSZ);
      }
      break;
    case twofish:
      cphr->ctx = kmalloc(sizeof(twofish_ctx), GFP_KERNEL);
      if (cphr->ctx != NULL)
      {
        cphr->id = id;
        cphr->name = "Twofish";
        cphr->block_size = TWOFISH_BLKSZ;
        cphr->key_size = TWOFISH_KEYSZ;
        twofish_init((twofish_ctx*) cphr->ctx, key, TWOFISH_KEYSZ);
      }
      break;
    default:
      break;
  }
}

/* Encrypt a block in buffer
 */
void encrypt_block(cipher_t* cphr, uint32* buf)
{
  switch (cphr->id)
  {
    case aes:
      rijndael_eblk(cphr->ctx, buf, buf);
      break;
    case blowfish:
      blowfish_eblk(cphr->ctx, buf, buf);
      break;
    case des:
      reorder_memory((octet*) buf, cphr->block_size);
      des_eblk(cphr->ctx, buf, buf);
      reorder_memory((octet*) buf, cphr->block_size);
      break;
    case des3:
      reorder_memory((octet*) buf, cphr->block_size);
      des3_eblk(cphr->ctx, buf, buf);
      reorder_memory((octet*) buf, cphr->block_size);
      break;
    case serpent:
      serpent_eblk(cphr->ctx, buf, buf);
      break;
    case square:
      square_eblk(cphr->ctx, buf, buf);
      break;
    case tea:
      tea_eblk(cphr->ctx, buf, buf);
      break;
    case twofish:
      twofish_eblk(cphr->ctx, buf, buf);
      break;
    default:
      break;
  }
}

/* Decrypt a block in buffer
 */
void decrypt_block(cipher_t* cphr, uint32* buf)
{
  switch (cphr->id)
  {
    case aes:
      rijndael_dblk(cphr->ctx, buf, buf);
      break;
    case blowfish:
      blowfish_dblk(cphr->ctx, buf, buf);
      break;
    case des:
      reorder_memory((octet*) buf, cphr->block_size);
      des_dblk(cphr->ctx, buf, buf);
      reorder_memory((octet*) buf, cphr->block_size);
      break;
    case des3:
      reorder_memory((octet*) buf, cphr->block_size);
      des3_dblk(cphr->ctx, buf, buf);
      reorder_memory((octet*) buf, cphr->block_size);
      break;
    case serpent:
      serpent_dblk(cphr->ctx, buf, buf);
      break;
    case square:
      square_dblk(cphr->ctx, buf, buf);
      break;
    case tea:
      tea_dblk(cphr->ctx, buf, buf);
      break;
    case twofish:
      twofish_dblk(cphr->ctx, buf, buf);
      break;
    default:
      break;
  }
}
