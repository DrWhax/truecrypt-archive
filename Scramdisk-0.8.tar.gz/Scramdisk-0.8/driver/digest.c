/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: digest.c,v 1.2 2005/08/11 20:49:30 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: digest.c,v $
 *  Revision 1.2  2005/08/11 20:49:30  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <linux/slab.h>
#include "digest.h"

/* Initialize the digest
 */
void init_digest(digest_t* dgst, digest_id id)
{
  dgst->id = undef_digest;
  dgst->name = NULL;
  dgst->hash_size = 0u;
  dgst->ctx = NULL;
  switch (id)
  {
    case sha1:
      dgst->ctx = kmalloc(sizeof(sha1_ctx), GFP_KERNEL);
      if (dgst->ctx != NULL)
      {
        dgst->id = id;
        dgst->name = "SHA1";
        dgst->hash_size = SHA1_HASHSZ;
      }
      break;
    case sha256:
      dgst->ctx = kmalloc(sizeof(sha256_ctx), GFP_KERNEL);
      if (dgst->ctx != NULL)
      {
        dgst->id = id;
        dgst->name = "SHA256";
        dgst->hash_size = SHA256_HASHSZ;
      }
      break;
    case ripemd160:
      dgst->ctx = kmalloc(sizeof(rmd160_ctx), GFP_KERNEL);
      if (dgst->ctx != NULL)
      {
        dgst->id = id;
        dgst->name = "Ripemd160";
        dgst->hash_size = RMD160_HASHSZ;
      }
      break;
    default:
      break;
  }
}

/* Hash the buffer
 */
void hash_buffer(digest_t* dgst, const octet* buf, size_t sz, octet* hash)
{
  switch (dgst->id)
  {
    case sha1:
      sha1_init((sha1_ctx*) dgst->ctx);
      sha1_hash((sha1_ctx*) dgst->ctx, buf, sz);
      sha1_done((sha1_ctx*) dgst->ctx, hash);
      break;
    case sha256:
      sha256_init((sha256_ctx*) dgst->ctx);
      sha256_hash((sha256_ctx*) dgst->ctx, buf, sz);
      sha256_done((sha256_ctx*) dgst->ctx, hash);
      break;
    case ripemd160:
      rmd160_init((rmd160_ctx*) dgst->ctx);
      rmd160_hash((rmd160_ctx*) dgst->ctx, buf, sz);
      rmd160_done((rmd160_ctx*) dgst->ctx, hash);
      break;
    default:
      break;
  }
}
