/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: sector.c,v 1.2 2005/08/11 20:49:30 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: sector.c,v $
 *  Revision 1.2  2005/08/11 20:49:30  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <linux/slab.h>
#include <getiv.h>
#include "sector.h"

#define SD_PASSPHRASE_SIZE 160u
#define SD_BLOCK_SIZE 512u
#define SD_HEADER_BLOCK_SIZE 2048u

static const size_t sect_32_blocks = SD_BLOCK_SIZE/sizeof(uint32);
static const size_t head_32_blocks = SD_HEADER_BLOCK_SIZE/sizeof(uint32);

void sd_init_hash_cipher(octet* phrase, sd_context_t* ctx)
{
  ctx->cphr_ctx = (cipher_t*) kmalloc(sizeof(cipher_t), GFP_KERNEL);
  ctx->dgst_ctx = (digest_t*) kmalloc(sizeof(digest_t), GFP_KERNEL);
  if (ctx->cphr_ctx == NULL || ctx->dgst_ctx == NULL)
    return;
  init_digest(ctx->dgst_ctx, ctx->dgst_id);
  memset(ctx->pw_hash, 0, LARGEST_HASH_SIZE);
  hash_buffer(ctx->dgst_ctx, phrase, SD_PASSPHRASE_SIZE, ctx->pw_hash);
  memset(ctx->master_key, 0, LARGEST_HASH_SIZE);
  memcpy(ctx->master_key, ctx->pw_hash, ctx->dgst_ctx->hash_size);
  reorder_memory(ctx->master_key, ctx->dgst_ctx->hash_size);
  init_cipher(ctx->cphr_ctx, ctx->cphr_id, ctx->master_key,
              ctx->dgst_ctx->hash_size);
}

void sd_init_real_cipher(sd_context_t* ctx)
{
  if (ctx->cphr_ctx == NULL)
    ctx->cphr_ctx = (cipher_t*) kmalloc(sizeof(cipher_t), GFP_KERNEL);
  if (ctx->cphr_ctx == NULL)
    return;
  memcpy(ctx->master_key, &ctx->white_table[OFFS_MASTER_KEY], LARGEST_KEY_SIZE);
  init_cipher(ctx->cphr_ctx, ctx->cphr_id, ctx->master_key, LARGEST_KEY_SIZE);
}

void sd_free_cipher(sd_context_t* ctx)
{
  if (ctx->cphr_ctx != NULL)
  {
    kfree(ctx->cphr_ctx);
    ctx->cphr_ctx = NULL;
  }
  if (ctx->dgst_ctx != NULL)
  {
    kfree(ctx->dgst_ctx);
    ctx->dgst_ctx = NULL;
  }
}

/* Encrypt nsect sectors starting with number sectnum
 */
void sd_encrypt_sectors(uint32 *buf, sd_context_t *ctx, int sectnum, int nsect)
{
  while (nsect--)
  {
    sd_encrypt_sector(buf, ctx, sectnum++);
    buf += sect_32_blocks;
  }
}

/* Encrypt the sector with number sectnum
 */
void sd_encrypt_sector(uint32* buf, sd_context_t* ctx, int sectnum)
{
  unsigned int n;
  uint32 ivl,ivr,cbccl,cbccr;

  getiv64(&ivl, &ivr, &cbccl, &cbccr, sectnum, ctx->white_table);
  switch (ctx->cphr_ctx->block_size)
  {
    case 8u:
      for (n = 0u; n < sect_32_blocks; n += 2u)
      {
        buf[n] ^= ivl;
        buf[n+1] ^= ivr;
        encrypt_block(ctx->cphr_ctx, &buf[n]);
        ivl = buf[n];
        ivr = buf[n+1];
        buf[n] ^= cbccl;
        buf[n+1] ^= cbccr;
      }
      break;
    case 16u:
      if (ctx->win_compatible)
      { // cipher block chaining only on the first 64 bits of block
        for (n = 0u; n < sect_32_blocks; n += 4u)
        {
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          encrypt_block(ctx->cphr_ctx, &buf[n]);
          ivl = buf[n];
          ivr = buf[n+1];
          buf[n] ^= cbccl;
          buf[n+1] ^= cbccr;
        }
      }
      else
      { // full cipher block chaining
        uint32 ivs = 0u, ivt = 0u;
        for (n = 0u; n < sect_32_blocks; n += 4u)
        {
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          buf[n+2] ^= ivs;
          buf[n+3] ^= ivt;
          encrypt_block(ctx->cphr_ctx, &buf[n]);
          ivl = buf[n];
          ivr = buf[n+1];
          ivs = buf[n+2];
          ivt = buf[n+3];
          buf[n] ^= cbccl;
          buf[n+1] ^= cbccr;
          buf[n+2] ^= cbccr;
          buf[n+3] ^= cbccl;
        }
      }
      break;
    default:
      break;
  }
}

/* Decrypt nsect sectors starting with number sectnum
 */
void sd_decrypt_sectors(uint32* buf, sd_context_t* ctx, int sectnum, int nsect)
{
  while (nsect--)
  {
    sd_decrypt_sector(buf, ctx, sectnum++);
    buf += sect_32_blocks;
  }
}

/* Decrypt the sector with number sectnum
 */
void sd_decrypt_sector(uint32* buf, sd_context_t* ctx, int sectnum)
{
  unsigned int n;
  uint32 ivl, ivr, ivl2, ivr2, cbccl, cbccr;

  getiv64(&ivl, &ivr, &cbccl, &cbccr, sectnum, ctx->white_table);
  switch (ctx->cphr_ctx->block_size)
  {
    case 8u:
      for (n = 0u; n < sect_32_blocks; n += 2u)
      {
        ivl2 = buf[n] ^= cbccl;
        ivr2 = buf[n+1] ^= cbccr;
        decrypt_block(ctx->cphr_ctx, &buf[n]);
        buf[n] ^= ivl;
        buf[n+1] ^= ivr;
        ivl = ivl2;
        ivr = ivr2;
      }
      break;
    case 16u:
      if (ctx->win_compatible)
      { // cipher block chaining only on the first 64 bits of block
        for (n = 0u; n < sect_32_blocks; n += 4u)
        {
          ivl2 = buf[n] ^= cbccl;
          ivr2 = buf[n+1] ^= cbccr;
          decrypt_block(ctx->cphr_ctx, &buf[n]);
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          ivl = ivl2;
          ivr = ivr2;
        }
      }
      else
      { // full cipher block chaining
        uint32 ivs = 0u, ivt = 0u, ivs2 = 0u, ivt2 = 0u;
        for (n = 0u; n < sect_32_blocks; n += 4u)
        {
          ivl2 = buf[n] ^= cbccl;
          ivr2 = buf[n+1] ^= cbccr;
          ivs2 = buf[n+2] ^= cbccr;
          ivt2 = buf[n+3] ^= cbccl;
          decrypt_block(ctx->cphr_ctx, &buf[n]);
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          buf[n+2] ^= ivs;
          buf[n+3] ^= ivt;
          ivl = ivl2;
          ivr = ivr2;
          ivs = ivs2;
          ivt = ivt2;
        }
      }
      break;
    default:
      break;
  }
}

/* Decrypt the white table header block
 */
void sd_decrypt_white_table(uint32 *buf, sd_context_t *ctx)
{
  unsigned int n;
  uint32 ivl = 0u, ivr = 0u, ivl2, ivr2;

  switch (ctx->cphr_ctx->block_size)
  {
    case 8u:
      for (n = 0u; n < head_32_blocks; n += 2u)
      {
        ivl2 = buf[n];
        ivr2 = buf[n+1];
        decrypt_block(ctx->cphr_ctx, &buf[n]);
        buf[n] ^= ivl;
        buf[n+1] ^= ivr;
        ivl = ivl2;
        ivr = ivr2;
      }
      break;
    case 16u:
      if (ctx->win_compatible)
      { // cipher block chaining only on the first 64 bits of block
        for (n = 0u; n < head_32_blocks; n += 4u)
        {
          ivl2 = buf[n];
          ivr2 = buf[n+1];
          decrypt_block(ctx->cphr_ctx, &buf[n]);
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          ivl = ivl2;
          ivr = ivr2;
        }
      }
      else
      { // full cipher block chaining
        uint32 ivs = 0u, ivt = 0u, ivs2, ivt2;
        for (n = 0u; n < head_32_blocks; n += 4u)
        {
          ivl2 = buf[n];
          ivr2 = buf[n+1];
          ivs2 = buf[n+2];
          ivt2 = buf[n+3];
          decrypt_block(ctx->cphr_ctx, &buf[n]);
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          buf[n+2] ^= ivs;
          buf[n+3] ^= ivt;
          ivl = ivl2;
          ivr = ivr2;
          ivs = ivs2;
          ivt = ivt2;
        }
      }
      break;
    default:
      break;
  }
}
