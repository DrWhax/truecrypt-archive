/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: sddriver.h,v 1.2 2005/08/11 20:49:30 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: sddriver.h,v $
 *  Revision 1.2  2005/08/11 20:49:30  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#ifndef SDDRIVER_H
#define SDDRIVER_H

#define DEVICE_OFF
#define DEVICE_NO_RANDOM
#define MAJOR_NR 125
#define DEVICE_NAME "scramdisk"
#define SCRAMDISK_RAHEAD 1
#define SD_BLOCK_SIZE 512
#define SD_BLOCK_SHIFT 9
#define SD_MAX_SECTORS 8
#define SD_CRYPT_OFFS 8192
#define SD_FS_BLKOFFS 20
#define SD_FS_CRYPT_START_SECTOR 4
#define SD_MIN_POOL_PAGES 32

#include <linux/version.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
#include <linux/blk.h>
#else
#include <linux/blkdev.h>
#endif
#include <linux/kernel.h>
#include <linux/hdreg.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <asm/uaccess.h>

#include "sdstructs.h"
#include "volume.h"
#include "sector.h"

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
typedef struct sd_read_data
{
  sd_slot_t* slot;
  struct page* page;
  loff_t offset;
  int crypt_sector;
} sd_read_data_t;
#endif

#endif
