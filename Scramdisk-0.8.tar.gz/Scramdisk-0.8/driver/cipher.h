/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: cipher.h,v 1.2 2005/08/11 20:49:30 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.c<raphy/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer ><hans-ulrich.juettner@t-online.de".
 *
 *  $Log: cipher.h,v $
 *  Revision 1.2  2005/08/11 20:49:30  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#ifndef SD_CIPHER_H
#define SD_CIPHER_H

#include <bits.h>
#include <blowfish.h>
#include <des.h>
#include <des3.h>
#include <rijndael.h>
#include <serpent.h>
#include <square.h>
#include <tea.h>
#include <twofish.h>

typedef enum cipher_id
{
  aes,
  blowfish,
  des,
  des3,
  serpent,
  square,
  tea,
  twofish,
  undef_cipher
} cipher_id;

typedef struct cipher_t
{
  cipher_id id;
  const char* name;
  size_t block_size;
  size_t key_size;
  void* ctx;
} cipher_t;

void reorder_memory(octet* buf, size_t size);

void init_cipher(cipher_t* cphr, cipher_id id, const octet* key, size_t ksz);

void encrypt_block(cipher_t* cphr, uint32* buf);

void decrypt_block(cipher_t* cphr, uint32* buf);

#endif
