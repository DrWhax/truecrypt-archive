/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: sdstructs.h,v 1.2 2005/08/11 20:49:30 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: sdstructs.h,v $
 *  Revision 1.2  2005/08/11 20:49:30  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#ifndef SDSTRUCTS_H
#define SDSTRUCTS_H

#define LARGEST_HASH_SIZE 32u
#define LARGEST_KEY_SIZE 32u
#define HEADER_BLOCK_SIZE 2048u
#define OFFS_MASTER_KEY 1024u

#include <linux/version.h>
#include <linux/types.h>
#include <linux/fs.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#include <linux/blkdev.h>
#endif
#include "sdmount.h"

typedef enum sd_state
{
  sd_shutdown,
  sd_inactive,
  sd_active
} sd_state;

typedef struct sd_context
{
  int win_compatible;
  cipher_id cphr_id;
  digest_id dgst_id;
  octet pw_hash[LARGEST_HASH_SIZE];
  octet master_key[LARGEST_KEY_SIZE];
  octet white_table[HEADER_BLOCK_SIZE];
  cipher_t* cphr_ctx;
  digest_t* dgst_ctx;
} sd_context_t;

typedef struct sd_slot
{
  unsigned int uid;
  unsigned long blksz_factor;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
  kdev_t device;
#else
  int slot;
  struct gendisk* disk;
  struct request_queue* rq;
#endif
  struct file* filp;
  sd_state state;
  atomic_t use_count;
  spinlock_t slot_lock;
  sd_mount_t* mount;
  sd_context_t* context;
} sd_slot_t;

#endif
