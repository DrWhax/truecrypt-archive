/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: volume.c,v 1.2 2005/08/11 20:49:30 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: volume.c,v $
 *  Revision 1.2  2005/08/11 20:49:30  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <asm/uaccess.h>
#include <linux/slab.h>
#include <linux/kernel.h>
#include "volume.h"
#include "sector.h"

sd_context_t* scramdisk_mount_container(sd_slot_t* sd_slot)
{
  int n_read;
  octet* header_block;
  octet* check_blocks;
  sd_context_t* ctx;
  mm_segment_t oldfs;
  
  ctx = kmalloc(sizeof(sd_context_t), GFP_KERNEL);
  if (ctx == NULL)
    return ctx;
  ctx->win_compatible = 1;
  ctx->cphr_id = 0;
  ctx->dgst_id = 0;
  header_block = ctx->white_table;

  oldfs = get_fs();
  set_fs(KERNEL_DS);
  while (ctx->cphr_id < undef_cipher)
  {
    /* Seek to the start of the file */
    sd_slot->filp->f_pos = 0;
    n_read = generic_file_read(sd_slot->filp, header_block, 
                               HEADER_BLOCK_SIZE, &sd_slot->filp->f_pos);
    if (n_read < HEADER_BLOCK_SIZE)
    {
      printk(KERN_ERR "scramdisk: Cannot read the header block (%d)\n", n_read);
      kfree(ctx);
      ctx = NULL;
      break;
    }
    /* Initialize cipher with password hash */
    sd_init_hash_cipher(sd_slot->mount->passwordbuffer, ctx);
    /* Decrypt the first whitening table (first 4 sectors) */
    sd_decrypt_white_table((uint32*)header_block, ctx);
    /* Re-initialize cipher with the real key */
    sd_init_real_cipher(ctx);
    /* Seek to the 1st sector of the virtual disk (sector 0) */
    sd_slot->filp->f_pos = CHECKING_BLOCKS_START;
    check_blocks = kmalloc(CHECKING_BLOCKS_SIZE, GFP_KERNEL);
    n_read = generic_file_read(sd_slot->filp, check_blocks, 
                               CHECKING_BLOCKS_SIZE, &sd_slot->filp->f_pos);
    if (n_read < CHECKING_BLOCKS_SIZE)
    {
      printk(KERN_ERR "scramdisk: Cannot read the check blocks (%d)\n", n_read);
      kfree(ctx);
      ctx = NULL;
      break;
    }
    sd_decrypt_sectors((uint32*)check_blocks, ctx, 0, 3);
    if (memcmp(check_blocks, check_blocks+512, 512) == 0 ||
        memcmp(check_blocks, check_blocks+1024, 512) == 0 ||
        memcmp(check_blocks+512, check_blocks+1024, 512) == 0)
    { /* We have found a working digest/cipher combination */
      printk(KERN_INFO "Scramdisk: Container mounted, Digest: %s, Cipher: %s\n",
             ctx->cphr_ctx->name, ctx->dgst_ctx->name);
      kfree(check_blocks);
      break;
    }
    if (++ctx->dgst_id == undef_digest)
    {
      ctx->dgst_id = 0;
      if (ctx->cphr_ctx->block_size > 8u && ctx->win_compatible)
        ctx->win_compatible = 0;
      else
      {
        ctx->win_compatible = 1;
        ++ctx->cphr_id;
      }
    }
  }
  set_fs(oldfs);
  if (ctx->cphr_id == undef_cipher)
  {
    kfree(ctx);
    ctx = NULL;
  }
  return ctx;
}

