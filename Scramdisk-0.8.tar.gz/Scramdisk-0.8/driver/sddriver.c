/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: sddriver.c,v 1.2 2005/08/11 20:49:30 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: sddriver.c,v $
 *  Revision 1.2  2005/08/11 20:49:30  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <linux/version.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#include <linux/init.h>
#include <linux/buffer_head.h>
#endif
#include "sddriver.h"

MODULE_LICENSE("GPL");

static sd_slot_t slots[MAX_SLOTS];
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
static int sd_sizes[MAX_SLOTS];
static int sd_blksizes[MAX_SLOTS];
static int sd_hardsectsizes[MAX_SLOTS];
#endif

int slot_mounted(int slot);
int scramdisk_getfreeslot(void);
int scramdisk_getuid(int slot);
int scramdisk_getdevicesize(int slot);
int scramdisk_getslot(sd_mount_t* sdmount);
int scramdisk_inquire(sd_info_t* sdinfo);
int scramdisk_mount(sd_mount_t* sdmount);
int scramdisk_umount(sd_mount_t* sdmount);
int scramdisk_open(struct inode* inode, struct file* filp);
int scramdisk_release(struct inode* inode, struct file* filp);
int scramdisk_ioctl(struct inode* inode, struct file* filp,
                    unsigned int cmd, unsigned long arg);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
static void scramdisk_end_io(struct buffer_head* bh, int uptodate);
struct buffer_head* scramdisk_get_buffer(int slot, struct buffer_head* rbh);
int scramdisk_read(int slot, struct buffer_head* bh);
int scramdisk_write(int slot, struct buffer_head* bh);
int scramdisk_make_request(request_queue_t* q, int rw, struct buffer_head* bh);
#else
static int scramdisk_read_actor(read_descriptor_t* desc, struct page* page,
                                unsigned long offset, unsigned long size);
int scramdisk_receive(sd_slot_t* p_slot, struct bio_vec* bvec, loff_t pos);
int scramdisk_read(sd_slot_t* p_slot, struct bio* bio);
int scramdisk_send(sd_slot_t* p_slot, struct bio_vec* bv, loff_t pos);
int scramdisk_write(sd_slot_t* p_slot, struct bio* bio);
int scramdisk_make_request(request_queue_t* q, struct bio* bio);
#endif

static struct block_device_operations scramdisk_bdops = {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
  owner: THIS_MODULE,
  open: scramdisk_open,
  release: scramdisk_release,
  ioctl: scramdisk_ioctl
#else
  .owner = THIS_MODULE,
  .open = scramdisk_open,
  .release = scramdisk_release,
  .ioctl = scramdisk_ioctl
#endif
};

int slot_mounted(int slot)
{
  return (slot > 0 && slot < MAX_SLOTS) ? (slots[slot].mount != NULL) : -1;
}

/* Get a free slot number */
int scramdisk_getfreeslot(void)
{
  int i;

  for (i = 1; i < MAX_SLOTS; i++)
  {
    if (slot_mounted(i) == 0)
      return i;
  }
  return -1;
}

/* Get the user id of the specified slot */
int scramdisk_getuid(int slot)
{
  /* Check if a device is mounted on */
  if (slot_mounted(slot) != 1)
    return -EINVAL;
  return (slots[slot].uid);
}

/* Get the size of the device in sectors */
int scramdisk_getdevicesize(int slot)
{
  /* Check if a device is mounted on */
  if (slot == 0 || slot_mounted(slot) != 1)
  {
    printk(KERN_ERR "scramdisk_getdevicesize: slot %d not mounted\n", slot);
    return -EINVAL;
  }
  return (slots[slot].mount->size >> SD_BLOCK_SHIFT);
}

/* Get a slot number from a filename, either container or mount point */
int scramdisk_getslot(sd_mount_t* sdmount)
{
  int i;

  if (sdmount == NULL)
    return -1;
  for (i = 1; i < MAX_SLOTS; i++)
  {
    if (slots[i].mount != NULL &&
        ((slots[i].mount->filename != NULL && sdmount->filename != NULL &&
          strcmp(slots[i].mount->filename, sdmount->filename) == 0) ||
         (slots[i].mount->mnt_point != NULL && sdmount->mnt_point != NULL &&
          strcmp(slots[i].mount->mnt_point, sdmount->mnt_point) == 0)))
      return i;
  }
  return -1;
}

/* Inquire the scramdisk mount structure */
int scramdisk_inquire(sd_info_t* sdinfo)
{
  sd_info_t sdinf;
  if (copy_from_user(&sdinf, sdinfo, sizeof(sd_info_t)) ||
      sdinf.container == NULL || sdinf.mnt_point == NULL)
  {
    printk(KERN_ERR "scramdisk: invalid info structure\n");
    return -EFAULT;
  }
  if (slot_mounted(sdinf.slot) == 1)
  {
    sdinf.uid = slots[sdinf.slot].uid;
    if (sdinf.uid == current->uid || sdinf.uid == current->euid ||
        capable(CAP_SYS_ADMIN))
    {
      sdinf.rd_only = slots[sdinf.slot].mount->rd_only;
      sdinf.size = slots[sdinf.slot].mount->size;
      sdinf.cphr_id = slots[sdinf.slot].mount->cphr_id;
      sdinf.dgst_id = slots[sdinf.slot].mount->dgst_id;
      strncpy(sdinf.container, slots[sdinf.slot].mount->filename, PATH_MAX);
      strncpy(sdinf.mnt_point, slots[sdinf.slot].mount->mnt_point, PATH_MAX);
    }
    else
    {
      sdinf.rd_only = -1;
      sdinf.size = 0u;
      sdinf.cphr_id = undef_cipher;
      sdinf.dgst_id = undef_digest;
      strcpy(sdinf.container, "-");
      strcpy(sdinf.mnt_point, "-");
    }
    if (copy_to_user(sdinfo, &sdinf, sizeof(sd_info_t)))
    {
      printk(KERN_ERR "scramdisk: can't copy info structure to user\n");
      return -EFAULT;
    }
    return sdinf.slot;
  }
  return -1;
}

/* Mount the scramdisk container */
int scramdisk_mount(sd_mount_t* sdmount)
{
  int i;
  int err = 0;
  int mode = 0;
  int slot = 0;
  unsigned long flags = 0ul;
  sd_mount_t sdmnt;
  struct inode* inode;

  slot = scramdisk_getfreeslot();
  if (slot == -1)
    err = -EBUSY;
  else
  {
    slots[slot].uid = current->uid;
    spin_lock_irqsave(slots[slot].slot_lock, flags);
    slots[slot].state = sd_inactive;
    spin_unlock_irqrestore(slots[slot].slot_lock, flags);
    if (copy_from_user(&sdmnt, sdmount, sizeof(sd_mount_t)) ||
        sdmnt.filename == NULL || sdmnt.passwordbuffer == NULL)
    {
      printk(KERN_ERR "scramdisk: invalid mount structure\n");
      return -EFAULT;
    }
    for (i = 1; i < MAX_SLOTS; i++)
    {
      if (slot_mounted(i) == 1 &&
          strcmp(slots[i].mount->filename, sdmnt.filename) == 0)
      {
        printk(KERN_ERR "scramdisk: container already mounted\n");
        return -EEXIST;
      }
    }
    slots[slot].mount = kmalloc(sizeof(sd_mount_t), GFP_KERNEL);
    if (!slots[slot].mount)
    {
      printk(KERN_ERR "scramdisk_mount: no more memory\n");
      return -ENOMEM;
    }
    slots[slot].mount->passwordbuffer = kmalloc(160u, GFP_KERNEL);
    slots[slot].mount->filename = kmalloc(PATH_MAX, GFP_KERNEL);
    if (sdmnt.mnt_point != NULL)
      slots[slot].mount->mnt_point = kmalloc(PATH_MAX, GFP_KERNEL);
    else
      slots[slot].mount->mnt_point = NULL;
    if (!slots[slot].mount->passwordbuffer || !slots[slot].mount->filename)
    {
      printk(KERN_ERR "scramdisk_mount: no more memory\n");
      err = -ENOMEM;
      goto error;
    }
    memcpy(slots[slot].mount->passwordbuffer, sdmnt.passwordbuffer, 160u);
    memset(sdmnt.passwordbuffer, 0, 160u);
    strncpy(slots[slot].mount->filename, sdmnt.filename, PATH_MAX);
    slots[slot].mount->filename[PATH_MAX - 1] = 0;
    if (slots[slot].mount->mnt_point != NULL)
    {
      strncpy(slots[slot].mount->mnt_point, sdmnt.mnt_point, PATH_MAX);
      slots[slot].mount->mnt_point[PATH_MAX - 1] = 0;
    }
    slots[slot].mount->rd_only = sdmnt.rd_only;
    if (sdmnt.rd_only)
    {
      printk(KERN_INFO "scramdisk: mounting container read only\n");
      mode = O_RDONLY;
    }
    else
    {
      printk(KERN_INFO "scramdisk: mounting container read/write\n");
      mode = O_RDWR;
    }
    slots[slot].filp = filp_open(slots[slot].mount->filename, mode, 0);
    if (slots[slot].filp == NULL || IS_ERR(slots[slot].filp))
    {
      printk(KERN_ERR "scramdisk: could not open container '%s'\n",
             slots[slot].mount->filename);
      err = -EFAULT;
      goto error;
    }
    inode = slots[slot].filp->f_dentry->d_inode;
    if (!S_ISREG(inode->i_mode))
    {
      printk(KERN_ERR "scramdisk: container is not a regular file\n");
      err = -EFAULT;
      goto error;
    }
    slots[slot].context = scramdisk_mount_container(&slots[slot]);
    if (slots[slot].context == NULL)
    {
      printk(KERN_ERR "scramdisk: passphrase doesn't match\n");
      err = -EACCES;
      goto error;
    }
    sdmnt.size = inode->i_size - (SD_FS_BLKOFFS << SD_BLOCK_SHIFT);
    sdmnt.cphr_id = slots[slot].context->cphr_id;
    sdmnt.dgst_id = slots[slot].context->dgst_id;
    slots[slot].mount->cphr_id = sdmnt.cphr_id;
    slots[slot].mount->dgst_id = sdmnt.dgst_id;
    slots[slot].mount->size = sdmnt.size;
    slots[slot].blksz_factor = inode->i_blksize >> SD_BLOCK_SHIFT;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
    slots[slot].device = inode->i_dev;
    sd_sizes[slot] = sdmnt.size >> 10;
#else
    set_capacity(slots[slot].disk, sdmnt.size >> SD_BLOCK_SHIFT);
#endif
    if (copy_to_user(sdmount, &sdmnt, sizeof(sd_mount_t)))
    {
      printk(KERN_ERR "scramdisk: can't copy mount structure to user\n");
      err = -EFAULT;
      goto error;
    }
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
    MOD_INC_USE_COUNT;
#endif
    return slot;
error:
    if (slots[slot].filp != NULL && filp_close(slots[slot].filp, NULL))
      printk(KERN_CRIT "scramdisk: cannot close container\n");
    if (slots[slot].mount->passwordbuffer)
    {
      memset(slots[slot].mount->passwordbuffer, 0, 160u);
      kfree(slots[slot].mount->passwordbuffer);
    }
    if (slots[slot].mount->filename)
      kfree(slots[slot].mount->filename);
    if (slots[slot].mount->mnt_point)
      kfree(slots[slot].mount->mnt_point);
    kfree(slots[slot].mount);
    slots[slot].mount = NULL;
  }
  return err;
}

/* Unmount the scramdisk container */
int scramdisk_umount(sd_mount_t* sdmount)
{
  int slot;
  unsigned long flags;

  slot = scramdisk_getslot(sdmount);
  if (slot == -1)
  {
    printk(KERN_ERR "scramdisk: no slot to unmount\n");
    return -EFAULT;
  }
  if (atomic_read(&slots[slot].use_count))
  {
    printk(KERN_ERR "scramdisk: can't unmount, device busy\n");
    return -EBUSY;
  }
  spin_lock_irqsave(slots[slot].slot_lock, flags);
  slots[slot].state = sd_shutdown;
  spin_unlock_irqrestore(slots[slot].slot_lock, flags);
  if (slots[slot].filp != NULL && filp_close(slots[slot].filp, NULL))
    printk(KERN_CRIT "scramdisk: can't close file\n");
  slots[slot].filp = NULL;
  if (slots[slot].mount->passwordbuffer)
  {
    memset(slots[slot].mount->passwordbuffer, 0, 160u);
    kfree(slots[slot].mount->passwordbuffer);
  }
  if (slots[slot].mount->filename)
    kfree(slots[slot].mount->filename);
  if (slots[slot].mount->mnt_point)
    kfree(slots[slot].mount->mnt_point);
  kfree(slots[slot].mount);
  slots[slot].mount = NULL;
  if (slots[slot].context != NULL)
  {
    if (slots[slot].context->pw_hash != NULL)
      memset(slots[slot].context->pw_hash, 0, LARGEST_HASH_SIZE);
    if (slots[slot].context->master_key != NULL)
      memset(slots[slot].context->master_key, 0, LARGEST_KEY_SIZE);
    if (slots[slot].context->white_table != NULL)
      memset(slots[slot].context->white_table, 0, HEADER_BLOCK_SIZE);
    kfree(slots[slot].context);
    slots[slot].context = NULL;
  }
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
  MOD_DEC_USE_COUNT;
#else
  set_capacity(slots[slot].disk, 0);
#endif
  printk(KERN_ERR "scramdisk_umount: slot %d unmounted\n", slot);
  return 0;
}

/* Device Open function */
int scramdisk_open(struct inode* inode, struct file* filp)
{
  int uid, slot;

  if (!inode)
    return -EINVAL;
  if (MAJOR(inode->i_rdev) != MAJOR_NR)
    return -ENODEV;
  slot = MINOR(inode->i_rdev);
  /* Allow all accesses to minor 0, the request node */
  if (slot == 0)
    return 0;
  else if (slot < 0 || slot >= MAX_SLOTS)
  {
    printk(KERN_CRIT "scramdisk_open: wrong slot %d\n", slot);
    return -EINVAL;
  }
  /* Get the current uid for the requested slot */
  uid = scramdisk_getuid(slot);
  /* allow sysadmin to open not mounted device because hotplug.d does that */
  if (uid < 0 && !capable(CAP_SYS_ADMIN))
  {
    printk(KERN_ERR "scramdisk_open: sorry, the device is not mounted\n");
    return -EFAULT;
  }
  if (uid == current->uid || uid == current->euid || capable(CAP_SYS_ADMIN))
  {
    if (atomic_inc_and_test(&slots[slot].use_count))
    {
      atomic_dec(&slots[slot].use_count);
      printk(KERN_WARNING "scramdisk_open: slot %d busy\n", slot);
      return -EBUSY;
    }
    printk(KERN_INFO "scramdisk: slot %d opened\n", slot);
    return 0;
  }
  printk(KERN_ERR "scramdisk_open: not owner of mounted container\n");
  return -EPERM;
}

/* Device Release function */
int scramdisk_release(struct inode* inode, struct file* filp)
{
  int slot;

  if (!inode)
  {
    printk(KERN_CRIT "scramdisk_release: no inode\n");
    return -EINVAL;
  }
  if (MAJOR(inode->i_rdev) != MAJOR_NR)
    return -ENODEV;
  slot = MINOR(inode->i_rdev);
  if (slot == 0)
    return 0;
  else if (slot < 0 && slot >= MAX_SLOTS)
  {
    printk(KERN_CRIT "scramdisk_release: wrong slot %d\n", slot);
    return -EINVAL;
  }
  if (slot_mounted(slot) != 1)
  {
    if (capable(CAP_SYS_ADMIN) && atomic_dec_and_test(&slots[slot].use_count))
    {
      /* sysadmin may close not mounted devices because he may open it */
      printk(KERN_INFO "scramdisk: slot %d released\n", slot);
      return 0;
    }
    printk(KERN_ERR "scramdisk_release: slot %d not mounted\n", slot);
    return -EINVAL;
  }
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
  fsync_dev(MKDEV(MAJOR_NR, slot));
#else
  fsync_bdev(inode->i_bdev);
#endif
  atomic_dec(&slots[slot].use_count);
  printk(KERN_INFO "scramdisk: slot %d released\n", slot);
  return 0;
}

/* Handle custom device commands */
int scramdisk_ioctl(struct inode* inode, struct file* filp,
                    unsigned int cmd, unsigned long arg)
{
  int ret;
  unsigned int size;
  struct hd_geometry hdgeo;

  printk(KERN_CRIT "scramdisk_ioctl called\n");
  if (!inode)
  {
    printk(KERN_CRIT "scramdisk_ioctl invalid inode\n");
    return -EINVAL;
  }
  switch (cmd)
  {
    /* System request for the device size in sectors */
    case BLKGETSIZE:
      if (!access_ok(VERIFY_WRITE, arg, sizeof(unsigned long)))
      {
        printk(KERN_ERR "scramdisk_ioctl: BLKGETSIZE access fault\n");
        return -EFAULT;
      }
      ret = scramdisk_getdevicesize(MINOR(inode->i_rdev));
      printk(KERN_INFO "scramdisk_ioctl: size = %d\n", ret);
      if (ret < 0)
        return ret;
      put_user((unsigned long)ret, (unsigned long*)arg);
      return 0;
    case BLKRRPART:
      /* Don't allow partitioning or re-reading of the partition table */
      return -EINVAL;
    case BLKFLSBUF:
      if (!capable(CAP_SYS_ADMIN))
        return -EPERM;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
      fsync_dev(inode->i_rdev);
      invalidate_buffers(inode->i_rdev);
#else
      fsync_bdev(inode->i_bdev);
      invalidate_bdev(inode->i_bdev, 0);
#endif
      return 0;
    case HDIO_GETGEO:
      if (!access_ok(VERIFY_WRITE, arg, sizeof(hdgeo)))
      {
        printk(KERN_ERR "scramdisk_ioctl: HDIO_GETGEO access fault\n");
        return -EFAULT;
      }
      ret = scramdisk_getdevicesize(MINOR(inode->i_rdev));
      if (ret < 0)
        return ret;
      /* calculate a virtual disk geometry */
      size = ret;
      hdgeo.sectors = 63u;
      hdgeo.heads = 1u;
      hdgeo.start = 0u;
      while (size % hdgeo.sectors)
        --hdgeo.sectors;
      size /= hdgeo.sectors;
      while ((hdgeo.heads < 16u && !(size & 1u)) ||
             (size > 65535u && hdgeo.heads < 128u))
      {
        size >>= 1;
        hdgeo.heads <<= 1;
      }
      hdgeo.cylinders = size > 65535u ? 65535u : size;
      if (copy_to_user((void*)arg, &hdgeo, sizeof(hdgeo)))
      {
        printk(KERN_ERR "scramdisk_ioctl: HDIO_GETGEO copy_to_user fault\n");
        return -EFAULT;
      }
      return 0;
    case SCRAMDISK_IOC_INQUIRE:
      return scramdisk_inquire((sd_info_t*)arg);
    case SCRAMDISK_IOC_MOUNT:
      return scramdisk_mount((sd_mount_t*)arg);
    case SCRAMDISK_IOC_UMOUNT:
      return scramdisk_umount((sd_mount_t*)arg);
    default:
      printk(KERN_ERR "scramdisk_ioctl: unknown IOCTL command\n");
      /* We don't handle any other command types */
      return -EINVAL;
  }
  return -EINVAL; /* Unknown command, invalid */
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
/* End I/O and decrypt the data in case of READ */
static void scramdisk_end_io(struct buffer_head* bh, int uptodate)
{
  struct buffer_head* mbh = bh->b_private;
  int slot = MINOR(bh->b_dev);
  int crypt_sector = mbh->b_rsector + SD_FS_CRYPT_START_SECTOR;
  int n_sectors = bh->b_size >> SD_BLOCK_SHIFT;

  if (uptodate && !test_bit(BH_Dirty, &bh->b_state))
  {
    sd_decrypt_sectors((uint32*)bh->b_data, slots[slot].context,
                       crypt_sector, n_sectors);
    memcpy(mbh->b_data, bh->b_data, bh->b_size);
  }
  mbh->b_end_io(mbh, uptodate);
  __free_page(bh->b_page);
  kmem_cache_free(bh_cachep, bh);
}

/* Get a new buffer head for the real I/O */
struct buffer_head* scramdisk_get_buffer(int slot, struct buffer_head* bh)
{
  unsigned long blknr;
  struct buffer_head* rbh;

  while (1)
  {
    rbh = kmem_cache_alloc(bh_cachep, SLAB_NOIO);
    if (rbh)
      break;
    run_task_queue(&tq_disk);
    schedule_timeout(HZ);
  }
  memset(rbh, 0, sizeof(*rbh));
  rbh->b_size = bh->b_size;
  rbh->b_dev = bh->b_rdev;
  rbh->b_state = (1 << BH_Req) | (1 << BH_Mapped) | (1 << BH_Lock);
  while (1)
  {
    rbh->b_page = alloc_page(GFP_NOIO);
    if (rbh->b_page)
      break;
    run_task_queue(&tq_disk);
    schedule_timeout(HZ);
  }
  rbh->b_data = page_address(rbh->b_page);
  rbh->b_end_io = scramdisk_end_io;
  rbh->b_private = bh;
  init_waitqueue_head(&rbh->b_wait);
  blknr = bmap(slots[slot].filp->f_dentry->d_inode,
               (bh->b_rsector + SD_FS_BLKOFFS)/slots[slot].blksz_factor);
  rbh->b_rsector = blknr*slots[slot].blksz_factor +
                   (bh->b_rsector + SD_FS_BLKOFFS)%slots[slot].blksz_factor;
  rbh->b_rdev = slots[slot].device;
  return rbh;
}

/* Read a number of sectors in to the buffer */
int scramdisk_read(int slot, struct buffer_head* bh)
{
  struct buffer_head* rbh = scramdisk_get_buffer(slot, bh);

  if (buffer_uptodate(bh))
  {
    printk(KERN_WARNING "scramdisk_get_buffer: buffer_head uptodate\n");
    clear_bit(BH_Uptodate, &bh->b_state);
  }
  generic_make_request(READ, rbh);
  return 0;
}
#else

static int scramdisk_read_actor(read_descriptor_t* desc, struct page* page,
                                unsigned long offset, unsigned long size)
{
  int n_sectors;
  int crypt_sector;
  char* raw_buf;
  uint32* sd_buf;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,8)
  sd_read_data_t* p_data = (sd_read_data_t*)desc->buf;
#else
  sd_read_data_t* p_data = (sd_read_data_t*)desc->arg.buf;
#endif

  if (size > desc->count)
    size = desc->count;
  n_sectors = size >> SD_BLOCK_SHIFT;
  crypt_sector = p_data->crypt_sector;
  raw_buf = kmap_atomic(page, KM_USER0) + offset;
  sd_buf = kmap_atomic(p_data->page, KM_USER1) + p_data->offset;
  memcpy(sd_buf, raw_buf, size);
  sd_decrypt_sectors(sd_buf, p_data->slot->context, crypt_sector, n_sectors);
  kunmap_atomic(sd_buf, KM_USER1);
  kunmap_atomic(raw_buf, KM_USER0);
  desc->count -= size;
  desc->written += size;
  p_data->offset += size;
  p_data->crypt_sector += n_sectors;
  return size;
}

int scramdisk_receive(sd_slot_t* p_slot, struct bio_vec* bvec, loff_t pos)
{
  int ret;
  unsigned int len = bvec->bv_len;
  struct file* filp = p_slot->filp;
  sd_read_data_t data;

  data.slot = p_slot;
  data.page = bvec->bv_page;
  data.offset = bvec->bv_offset;
  data.crypt_sector = (pos - SD_CRYPT_OFFS) >> SD_BLOCK_SHIFT;
  ret = filp->f_op->sendfile(filp, &pos, len, scramdisk_read_actor, &data);
  return ret < 0 ? ret : 0;
}

int scramdisk_read(sd_slot_t* p_slot, struct bio* bio)
{
  int segnr;
  int ret = 0;
  loff_t pos = ((loff_t)bio->bi_sector + SD_FS_BLKOFFS) << SD_BLOCK_SHIFT;
  struct bio_vec* bvec;

  bio_for_each_segment(bvec, bio, segnr)
  {
    ret = scramdisk_receive(p_slot, bvec, pos);
    if (ret < 0)
      break;
    pos += bvec->bv_len;
  }
  if (!ret)
    bio_endio(bio, bio->bi_size, 0);
  return ret;
}
#endif

/* Encrypt and Write a number of sectors from the buffer */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
int scramdisk_write(int slot, struct buffer_head* bh)
{
  int n_sectors = bh->b_size >> SD_BLOCK_SHIFT;
  int crypt_sector = bh->b_rsector + SD_FS_CRYPT_START_SECTOR;
  struct buffer_head* rbh = scramdisk_get_buffer(slot, bh);

  if (slots[slot].mount->rd_only)
  {
    printk(KERN_ERR "scramdisk: attempt to write read only device\n");
    return -EACCES;
  }
  set_bit(BH_Dirty, &rbh->b_state);
  memcpy(rbh->b_data, bh->b_data, bh->b_size);
  sd_encrypt_sectors((uint32*)rbh->b_data, slots[slot].context,
                     crypt_sector, n_sectors);
  generic_make_request(WRITE, rbh);
  return 0;
}
#else

int scramdisk_send(sd_slot_t* p_slot, struct bio_vec* bv, loff_t pos)
{
  int len = bv->bv_len;
  int n_sectors;
  int crypt_sector;
  unsigned int size;
  unsigned int bv_offs = bv->bv_offset;
  unsigned int offset = pos & ((pgoff_t)PAGE_CACHE_SIZE - 1);
  pgoff_t index = pos >> PAGE_CACHE_SHIFT;
  struct page* page;
  struct file* filp = p_slot->filp;
  struct address_space* mapping = filp->f_mapping;
  struct address_space_operations* aops = mapping->a_ops;

  down(&mapping->host->i_sem);
  while (len > 0)
  {
    char* raw_buf;
    uint32* sd_buf;

    size = PAGE_CACHE_SIZE - offset;
    if (size > (unsigned int)len)
      size = len;
    page = grab_cache_page(mapping, index);
    if (!page)
      goto fail;
    if (aops->prepare_write(filp, page, offset, offset + size))
      goto unlock;
    raw_buf = kmap_atomic(bv->bv_page, KM_USER0) + bv_offs;
    sd_buf = kmap_atomic(page, KM_USER1) + offset;
    memcpy(sd_buf, raw_buf, size);
    n_sectors = size >> SD_BLOCK_SHIFT;
    crypt_sector = (pos - SD_CRYPT_OFFS) >> SD_BLOCK_SHIFT;
    sd_encrypt_sectors(sd_buf, p_slot->context, crypt_sector, n_sectors);
    kunmap_atomic(sd_buf, KM_USER1);
    kunmap_atomic(raw_buf, KM_USER0);
    flush_dcache_page(page);
    if (aops->commit_write(filp, page, offset, offset + size))
      goto unlock;
    offset = 0u;
    len -= size;
    pos += size;
    bv_offs += size;
    ++index;
    unlock_page(page);
    page_cache_release(page);
  }
  up(&mapping->host->i_sem);
  return 0;
unlock:
  unlock_page(page);
  page_cache_release(page);
fail:
  up(&mapping->host->i_sem);
  printk(KERN_ERR "scramdisk_send: failed\n");
  return -1;
}

int scramdisk_write(sd_slot_t* p_slot, struct bio* bio)
{
  int segnr;
  int ret = 0;
  loff_t pos = ((loff_t)bio->bi_sector + SD_FS_BLKOFFS) << SD_BLOCK_SHIFT;
  struct bio_vec* bvec;

  if (p_slot->mount->rd_only)
  {
    printk(KERN_ERR "scramdisk: attempt to write read only device\n");
    return -EACCES;
  }
  bio_for_each_segment(bvec, bio, segnr)
  {
    ret = scramdisk_send(p_slot, bvec, pos);
    if (ret < 0)
      break;
    pos += bvec->bv_len;
  }
  if (!ret)
    bio_endio(bio, bio->bi_size, 0);
  return ret;
}
#endif

/* Handle device requests */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
int scramdisk_make_request(request_queue_t* q, int rw, struct buffer_head* bh)
{
  int slot;
  int ret = 0;
  unsigned long flags;

  if (bh == NULL)
  {
    printk(KERN_ERR "scramdisk_make_request: buffer_head is NULL\n");
    return 0;
  }
  if (!buffer_locked(bh))
  {
    printk(KERN_ERR "scramdisk_make_request: buffer_head is not locked\n");
    return 0;
  }
  slot = MINOR(bh->b_rdev);
  if (slot <= 0 || slot >= MAX_SLOTS)
  {
    printk(KERN_CRIT "scramdisk_make_request: wrong slot %d\n", slot);
    buffer_IO_error(bh);
    return 0;
  }
  if (bh->b_rsector*SD_BLOCK_SIZE + bh->b_size > sd_sizes[slot]*1024)
  {
    printk(KERN_ERR "scramdisk_make_request: request past end of device\n");
    buffer_IO_error(bh);
    return 0;
  }
  spin_lock_irqsave(slots[slot].slot_lock, flags);
  if (slots[slot].state != sd_inactive)
  {
    spin_unlock_irqrestore(slots[slot].slot_lock, flags);
    printk(KERN_NOTICE "scramdisk_make_request: reentrance\n");
    buffer_IO_error(bh);
    return 0;
  }
  slots[slot].state = sd_active;
  spin_unlock_irqrestore(slots[slot].slot_lock, flags);
#ifdef CONFIG_HIGHMEM
  bh = create_bounce(rw, bh);
#endif
  /* We have a valid request (unless the cmd isn't READ, READA or WRITE) */
  switch (rw)
  {
    case READ:
    case READA:
      ret = scramdisk_read(slot, bh);
      break;
    case WRITE:
      ret = scramdisk_write(slot, bh);
      break;
    default:
      /* We don't handle any other command types */
      ret = -EINVAL;
  }
  if (ret < 0)
    buffer_IO_error(bh);
  spin_lock_irqsave(slots[slot].slot_lock, flags);
  slots[slot].state = sd_inactive;
  spin_unlock_irqrestore(slots[slot].slot_lock, flags);
  return 0;
}
#else

int scramdisk_make_request(request_queue_t* q, struct bio* bio)
{
  int ret = 0;
  int rw = bio_data_dir(bio);
  unsigned long flags;
  sd_slot_t* p_slot = q->queuedata;

  if (bio == NULL)
  {
    printk(KERN_ERR "scramdisk_make_request: bio is NULL\n");
    return 0;
  }
  if (p_slot == NULL || p_slot->mount == NULL)
  {
    /* bio_io_error(bio, bio->bi_size); */
    return -EINVAL;
  }
  if (bio->bi_sector*SD_BLOCK_SIZE + bio->bi_size > p_slot->mount->size)
  {
    printk(KERN_ERR "scramdisk_make_request: request past end of device\n");
    bio_io_error(bio, bio->bi_size);
    return 0;
  }
  spin_lock_irqsave(p_slot->slot_lock, flags);
  if (p_slot->state != sd_inactive)
  {
    spin_unlock_irqrestore(p_slot->slot_lock, flags);
    printk(KERN_NOTICE "scramdisk_make_request: reentrance\n");
    bio_io_error(bio, bio->bi_size);
    return 0;
  }
  p_slot->state = sd_active;
  spin_unlock_irqrestore(p_slot->slot_lock, flags);
  blk_queue_bounce(q, &bio);
  /* We have a valid request (unless the cmd isn't READ, READA or WRITE) */
  switch (rw)
  {
    case READ:
    case READA:
      ret = scramdisk_read(p_slot, bio);
      break;
    case WRITE:
      ret = scramdisk_write(p_slot, bio);
      break;
    default:
      /* We don't handle any other command types */
      ret = -EINVAL;
  }
  if (ret < 0)
    bio_io_error(bio, bio->bi_size);
  spin_lock_irqsave(p_slot->slot_lock, flags);
  p_slot->state = sd_inactive;
  spin_unlock_irqrestore(p_slot->slot_lock, flags);
  return 0;
}
#endif

/* Module initialisation function */
int __init scramdisk_init(void)
{
  int result, i;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
  result = register_blkdev(MAJOR_NR, DEVICE_NAME, &scramdisk_bdops);
  sd_sizes[0] = 0;
  sd_blksizes[0] = SD_BLOCK_SIZE;
  sd_hardsectsizes[0] = SD_BLOCK_SIZE;
#else
  result = register_blkdev(MAJOR_NR, DEVICE_NAME);
#endif
  if (result < 0)
  {
    printk(KERN_CRIT "scramdisk: can't register major %d\n", MAJOR_NR);
    return result;
  }
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
  slots[0].slot = 0;
  slots[0].disk = alloc_disk(1);
  if (slots[0].disk)
  {
    slots[0].disk->major = MAJOR_NR;
    slots[0].disk->first_minor = 0;
    slots[0].disk->fops = &scramdisk_bdops;
    slots[0].disk->queue = NULL;
    sprintf(slots[0].disk->disk_name, "scramdisk/master");
    sprintf(slots[0].disk->devfs_name, "scramdisk/master");
    set_capacity(slots[0].disk, 0);
    add_disk(slots[0].disk);
  }
  else
  {
    printk(KERN_CRIT "scramdisk_init: alloc_disk failed (i = 0)\n");
    return -EIO;
  }
  slots[0].rq = NULL;
#endif
  /* Initialise the sizes, queues and disks */
  for (i = 1; i < MAX_SLOTS; i++)
  {
    spin_lock_init(slots[i].slot_lock);
    atomic_set(&slots[i].use_count, 0);
    slots[i].state = sd_shutdown;
    slots[i].filp = NULL;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
    sd_sizes[i] = 0;
    sd_blksizes[i] = SD_BLOCK_SIZE;
    sd_hardsectsizes[i] = SD_BLOCK_SIZE;
#else
    slots[i].rq = blk_alloc_queue(GFP_KERNEL);
    if (slots[i].rq)
    {
      blk_queue_max_sectors(slots[i].rq, SD_MAX_SECTORS);
      slots[i].disk = alloc_disk(1);
      if (slots[i].disk)
      {
        slots[i].slot = i;
        slots[i].disk->major = MAJOR_NR;
        slots[i].disk->first_minor = i;
        slots[i].disk->fops = &scramdisk_bdops;
        slots[i].disk->queue = slots[i].rq;
        sprintf(slots[i].disk->disk_name, "scramdisk/vol%2.2d", i);
        sprintf(slots[i].disk->devfs_name, "scramdisk/vol%2.2d", i);
        set_capacity(slots[i].disk, 0);
        add_disk(slots[i].disk);
      }
      else
      {
        printk(KERN_CRIT "scramdisk_init: alloc_disk failed (i = %d)\n", i);
        blk_cleanup_queue(slots[i].rq);
      }
    }
    else
    {
      printk(KERN_CRIT "scramdisk_init: blk_alloc_queue failed (i = %d)\n", i);
      slots[i].disk = NULL;
    }
    if (!slots[i].disk)
    {
      int j;
      for (j = 1; j < i; j++)
      {
        put_disk(slots[j].disk);
        blk_cleanup_queue(slots[j].rq);
      }
      put_disk(slots[0].disk);
      unregister_blkdev(MAJOR_NR, DEVICE_NAME);
      return -EIO;
    }
    slots[i].rq->queuedata = &slots[i];
#endif
  }
  /* Set up some standard Kernel block device arrays */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
  blk_queue_make_request(BLK_DEFAULT_QUEUE(MAJOR_NR),
                         &scramdisk_make_request);
  blk_size[MAJOR_NR] = sd_sizes;
  blksize_size[MAJOR_NR] = sd_blksizes;
  hardsect_size[MAJOR_NR] = sd_hardsectsizes;
  read_ahead[MAJOR_NR] = SCRAMDISK_RAHEAD;
#else
  for (i = 1; i < MAX_SLOTS; i++)
    blk_queue_make_request(slots[i].rq, &scramdisk_make_request);
#endif
  printk(KERN_INFO "scramdisk: loaded!\n");
  return result;
}

/* Module removal function */
void __exit scramdisk_exit(void)
{
  int i;

  /* Flush each device */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
  for (i = 1; i < MAX_SLOTS; i++)
    fsync_dev(MKDEV(MAJOR_NR, i));
  /* Clear out the values in the Kernel block device arrays */
  blk_size[MAJOR_NR] = NULL;
  blksize_size[MAJOR_NR] = NULL;
  hardsect_size[MAJOR_NR] = NULL;
  read_ahead[MAJOR_NR] = 0;
#else
  for (i = 1; i < MAX_SLOTS; i++)
  {
    del_gendisk(slots[i].disk);
    put_disk(slots[i].disk);
    blk_cleanup_queue(slots[i].rq);
  }
  del_gendisk(slots[0].disk);
  put_disk(slots[0].disk);
#endif
  unregister_blkdev(MAJOR_NR, DEVICE_NAME);
  printk(KERN_INFO "scramdisk: unloaded\n");
}

module_init(scramdisk_init);

module_exit(scramdisk_exit);

