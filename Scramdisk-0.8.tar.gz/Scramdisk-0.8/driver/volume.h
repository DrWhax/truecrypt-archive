/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: volume.h,v 1.2 2005/08/11 20:49:30 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: volume.h,v $
 *  Revision 1.2  2005/08/11 20:49:30  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#ifndef VOLUME_H
#define VOLUME_H

#include "sdstructs.h"

#define CHECKING_BLOCKS_SIZE 1536
#define CHECKING_BLOCKS_START 8192
#define OFFS_VOLINFO 9728

#define COMMENT_SIZE 256

sd_context_t* scramdisk_mount_container(sd_slot_t* sd_slot);

#endif
