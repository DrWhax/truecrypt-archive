/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: sdmount.cpp,v 1.2 2005/08/11 20:49:32 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: sdmount.cpp,v $
 *  Revision 1.2  2005/08/11 20:49:32  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <sys/mount.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <limits.h>
#include <stdlib.h>
#include <iostream>
#include <cstdio>
#include "mtab.h"
#include "sdpw.h"
#include "args.h"
#include "sdmnt.h"

const char* cipher_name(cipher_id id)
{
  switch (id)
  {
    case aes:
      return "AES";
    case blowfish:
      return "Blowfish";
    case des:
      return "DES";
    case des3:
      return "DES3";
    case serpent:
      return "Serpent";
    case square:
      return "Square";
    case tea:
      return "Tea";
    case twofish:
      return "Twofish";
    default:
      break;
  }
  return "Undefined cipher";
}

const char* digest_name(digest_id id)
{
  switch (id)
  {
    case sha1:
      return "SHA1";
    case sha256:
      return "SHA256";
    case ripemd160:
      return "Ripemd160";
    default:
      break;
  }
  return "Undefined digest";
}

const char* fs_name(int fstype)
{
  switch (fstype)
  {
    case Ext2:
      return "ext2";
    case Ext3:
      return "ext3";
    case ReiserFS:
      return "reiserfs";
    case Minix:
      return "minix";
    case VFat:
      return "vfat";
    case MSDos:
      return "msdos";
    default:
      break;
  }
  return NULL;
}

int main(int argc, char** argv)
{
  uid_t uid = getuid();

  if (seteuid(uid) == 0)
  {
    int rdonly = 0;
    unsigned long flags = MS_MGC_VAL | MS_NODEV;
    MTabLock mtl;
    SdPassphrase sdpw;
    Arguments args(Mount, argc, argv);
    
    if (!args.Good())
      return 1;
    if (access(args.Container(), F_OK | R_OK) != 0)
    {
      std::cerr << "ERROR: No access to container file "
                << args.Container() << "\n";
      return 1;
    }
    if (args.ReadOnly() || access(args.Container(), F_OK | W_OK) != 0)
    {
      rdonly = 1;
      flags |= MS_RDONLY;
    }
    sdpw.SetHidden(args.Hide());
    if (!sdpw.Read())
    {
      std::cerr << "Error reading passphrase\n";
      return 1;
    }
    if (seteuid(0) == 0 && mtl.Lock())
    {
      int ret;
      int slotno;
      char* usr;
      char fsname[32];
      char device[32];
      char options[256];
      FILE* fmt;
      struct mntent mnt;
      struct mntent* pmnt;
      SdMount sd_mount(Mnt);

      if (!sd_mount.Good())
      {
        std::cerr << "ERROR: No more memory\n";
        return 1;
      }
      sd_mount.SetReadOnly(rdonly);
      if (realpath(args.Container(), sd_mount.Filename()) == NULL)
      {
        std::cerr << "ERROR: Couldn't resolve container pathname, error "
                  << errno << ": " << strerror(errno) << "\n";
        return 1;
      }
      fmt = setmntent(_PATH_MOUNTED, "r");
      if (fmt == NULL)
      {
        std::cerr << "ERROR: Could not open " << _PATH_MOUNTED << "\n";
        return 1;
      }
      while ((pmnt = getmntent(fmt)) != NULL)
      {
        if (strcmp(pmnt->mnt_fsname, sd_mount.Filename()) == 0)
          break;
      }
      endmntent(fmt);
      if (pmnt != NULL)
      {
        std::cerr << "ERROR: Container file " << args.Container()
                  << " already mounted\n";
        return 1;
      }
      if (args.FSType() != NoFS)
      {
        if (realpath(args.MountPoint(), sd_mount.MountPoint()) == NULL)
        {
          std::cerr << "ERROR: Couldn't resolve mount point pathname, error "
                    << errno << ": " << strerror(errno) << "\n";
          return 1;
        }
      }
      else
        strcpy(sd_mount.MountPoint(), "-");
      sd_mount.SetPhrase(sdpw.Phrase(), sdpw.Size());
      slotno = sd_mount.Mount();
      if (slotno == -2 && errno == EBUSY)
      {
        std::cerr << "ERROR: No free slot to mount\n";
        return 1;
      }
      else if (slotno == -2 && errno == EEXIST)
      {
        std::cerr << "ERROR: Container "  << args.Container()
                  << " already mounted\n";
        return 1;
      }
      else if (slotno == -2 && errno == EACCES)
      {
        std::cerr << "ERROR: wrong passphrase\n";
        return 1;
      }
      else if (slotno < 0)
      {
        std::cerr << "ERROR (" << errno << "): " << strerror(errno) << "\n";
        return 1;
      }
      sprintf(device, "/dev/scramdisk/vol%2.2d", slotno);
      std::cout << "device is " << device << "\n";
      std::cout << "cipher is " << cipher_name(sd_mount.CphrId()) << "\n";
      std::cout << "digest is " << digest_name(sd_mount.DgstId()) << "\n";
      std::cout << "size is " << sd_mount.Size()/1024u << " kB\n";
      if (args.FSType() == NoFS)
        return 0;
      if (args.FSType() == Auto)
      {
        int fstype;
        ret = 1;
        for (fstype = Ext2; ret && fs_name(fstype) != NULL; ++fstype)
        {
          errno = 0;
          strcpy(fsname, fs_name(fstype));
          ret = mount(device, sd_mount.MountPoint(), fsname, flags, NULL);
        }
      }
      else
      {
        strcpy(fsname, fs_name(args.FSType()));
        ret = mount(device, sd_mount.MountPoint(), fsname, flags, NULL);
      }
      if (ret)
      {
        std::cerr << "ERROR: Could not mount device: " << device << ", error "
                  << errno << ": " << strerror(errno) << "\n";
        return 1;
      }
      usr = getenv("USER");
      if (usr != NULL)
      {
        strcpy(options, sd_mount.ReadOnly() ? "ro,user=" : "rw,user=");
        strncat(options, usr, 247);
      }
      else
        strcpy(options, sd_mount.ReadOnly() ? "ro" : "rw");
      mnt.mnt_fsname = sd_mount.Filename();
      mnt.mnt_dir = sd_mount.MountPoint();
      mnt.mnt_type = fsname;
      mnt.mnt_opts = options;
      mnt.mnt_freq = 0;
      mnt.mnt_passno = 0;
      fmt = setmntent(_PATH_MOUNTED, "a");
      if (fmt != NULL)
      {
        addmntent(fmt, &mnt);
        endmntent(fmt);
      }
      else
        std::cerr << "WARNING: Could not add entry to /etc/mtab\n";
    }
    else
    {
      std::cerr << "ERROR: Could not lock " << _PATH_MOUNTED << "\n";
      return 1;
    }
  }
  return 0;
}
