/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: args.h,v 1.2 2005/08/11 20:49:32 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: args.h,v $
 *  Revision 1.2  2005/08/11 20:49:32  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#ifndef SD_ARGS_H
#define SD_ARGS_H

#include <string>
#include "version.h"

enum Action { Create, Mount, UnMount, Change };

enum FileSystemType { NoFS, Ext2, Ext3, ReiserFS, Minix, VFat, MSDos, Auto };

class Arguments
{
  private:
    Action action;
    FileSystemType fs_type;
    bool good;
    int hide;
    int rd_only;
    int win_compatible;
    int use_backup;
    size_t container_size;
    std::ostream& ostr;
    std::string cfg_file;
    std::string container;
    std::string cipher_name;
    std::string digest_name;
    std::string rnd_name;
    std::string mount_point;
    std::string mkfs_command;
    std::string fsname;

  public:
    Arguments(Action act, int argc, char** argv, std::ostream& os = std::cerr);
    ~Arguments() {}
    void Help(const char* name);
    void ReadCfgFile(const char* program, bool default_cfg, int& nofs);
    bool Good() { return good; }
    bool Hide() { return hide != 0; }
    bool ReadOnly() { return rd_only == 1; }
    bool WinCompatible() { return win_compatible == 1; }
    bool UseBackup() { return use_backup == 1; }
    size_t ContainerSize() { return container_size; }
    const char* CfgFile() { return cfg_file.c_str(); }
    const char* Container() { return container.c_str(); }
    const char* CipherName() { return cipher_name.c_str(); }
    const char* HashName() { return digest_name.c_str(); }
    const char* RandomName() { return rnd_name.c_str(); }
    const char* MountPoint() { return mount_point.c_str(); }
    const char* MkFSCommand() { return mkfs_command.c_str(); }
    FileSystemType FSType() { return fs_type; }
};

#endif
