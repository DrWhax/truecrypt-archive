/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: sdchange.cpp,v 1.2 2005/08/11 20:49:32 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: sdchange.cpp,v $
 *  Revision 1.2  2005/08/11 20:49:32  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <cstdio>
#include "args.h"
#include "sdpw.h"
#include "sdctx.h"

const char* digest_names[] =
{
  "ripemd160",
  "sha1",
  "sha256",
  NULL
};

const char* cipher_names[] =
{
  "aes",
  "blowfish",
  "des",
  "des3",
  "serpent",
  "square",
  "tea",
  "twofish",
  NULL
};

int main(int argc, char** argv)
{
  Arguments args(Change, argc, argv);
  if (!args.Good())
    return 1;
  SdContext sdctx(args.Container());
  SdPassphrase sdpw(false);
  SdPassphrase sdpw_new(true);
  octet header_buffer[HEADER_BLOCK_SIZE];
  octet backup_buffer[HEADER_BLOCK_SIZE];
  octet check_buffer[CHECK_BLOCK_SIZE];
  octet header_buf[HEADER_BLOCK_SIZE];
  octet backup_buf[HEADER_BLOCK_SIZE];
  octet check_buf[CHECK_BLOCK_SIZE];
  octet stock1_buf[HEADER_BLOCK_SIZE];
  octet stock2_buf[HEADER_BLOCK_SIZE];
  sdpw.SetHidden(args.Hide());
  std::cout << "Please enter old passphrase first:\n";
  if (!sdpw.Read())
  {
    std::cerr << "Error reading passphrase\n";
    return 1;
  }
  if (sdctx.Ready())
  {
    int j = 0;
    int k = 0;
    bool pw_bad = true;
    octet* p1;
    octet* p2;

    if (!sdctx.Read(header_buf, HEADER_BLOCK_SIZE) ||
        !sdctx.Read(stock1_buf, HEADER_BLOCK_SIZE) ||
        !sdctx.Read(stock2_buf, HEADER_BLOCK_SIZE) ||
        !sdctx.Read(backup_buf, HEADER_BLOCK_SIZE) ||
        !sdctx.Read(check_buf, CHECK_BLOCK_SIZE))
    {
      std::cerr << "Error reading file \"" << args.Container() << "\"\n";
      return 1;
    }
    for (j = 0; pw_bad && digest_names[j] != NULL; ++j)
    {
      k = 0;
      while (cipher_names[k] != NULL)
      {
        memcpy(header_buffer, header_buf, HEADER_BLOCK_SIZE);
        memcpy(backup_buffer, backup_buf, HEADER_BLOCK_SIZE);
        memcpy(check_buffer, check_buf, CHECK_BLOCK_SIZE);
        if (!sdctx.HashPhrase(digest_names[j], sdpw.Phrase(), sdpw.Size()))
        {
          std::cerr << "Error: hashing passphrase";
          return 1;
        }
        if (!sdctx.InitHashCipher(cipher_names[k]))
        {
          std::cerr << "Error: initializing cipher";
          return 1;
        }
        if (args.UseBackup())
        {
          sdctx.DecryptWhiteTable(backup_buffer);
          sdctx.DecryptWhiteTable(backup_buffer);
          sdctx.DecryptWhiteTable(backup_buffer);
          memcpy(header_buffer, backup_buffer, HEADER_BLOCK_SIZE);
        }
        else
        {
          sdctx.DecryptWhiteTable(header_buffer);
          memcpy(backup_buffer, header_buffer, HEADER_BLOCK_SIZE);
        }
        sdctx.SetWhiteTable(header_buffer);
        if (!sdctx.InitRealCipher(cipher_names[k]))
        {
          std::cerr << "Error: initializing cipher";
          return 1;
        }
        p1 = check_buffer + SD_BLOCK_SIZE;
        p2 = p1 + SD_BLOCK_SIZE;
        sdctx.DecryptSector(check_buffer, 0);
        sdctx.DecryptSector(p1, 1);
        sdctx.DecryptSector(p2, 2);
        if (memcmp(check_buffer, p1, SD_BLOCK_SIZE) == 0 ||
            memcmp(check_buffer, p2, SD_BLOCK_SIZE) == 0 ||
            memcmp(p1, p2, SD_BLOCK_SIZE) == 0)
        {
          pw_bad = false;
          break;
        }
        if (sdctx.BlockSize() == 16u && !sdctx.WinCompatible())
          sdctx.SetWinCompatible(true);
        else
        {
          sdctx.SetWinCompatible(false);
          ++k;
        }
      }
    }
    if (pw_bad)
    {
      std::cerr << "Sorry, the passphrase is wrong\n";
      if (!args.UseBackup())
        std::cerr << "If you are sure, try using the backup block "
                     "(command: -use-backup)\n";
      return 1;
    }
    std::cout << "OK, cipher is " << cipher_names[k]
              << ", digest is " << digest_names[--j] << "\n";
    if (!sdctx.HashPhrase(digest_names[j], sdpw.Phrase(), sdpw.Size()))
    {
      std::cerr << "Error: hashing passphrase";
      return 1;
    }
    if (!sdctx.InitHashCipher(cipher_names[k]))
    {
      std::cerr << "Error: initializing cipher";
      return 1;
    }
    sdctx.DecryptWhiteTable(stock1_buf);
    sdctx.DecryptWhiteTable(stock2_buf);
    sdpw_new.SetHidden(args.Hide());
    std::cout << "Now give the new passphrase:\n";
    if (!sdpw_new.Read())
    {
      std::cerr << "Sorry, passphrases differ, try again:\n";
      if (!sdpw_new.Read())
      {
        std::cerr << "Sorry, passphrases differ again\n";
        return 1;
      }
    }
    if (!sdctx.HashPhrase(digest_names[j], sdpw_new.Phrase(), sdpw_new.Size()))
    {
      std::cerr << "Error: hashing passphrase";
      return 1;
    }
    if (!sdctx.InitHashCipher(cipher_names[k]))
    {
      std::cerr << "Error: initializing cipher";
      return 1;
    }
    if (!sdctx.Rewind())
    {
      std::cerr << "Error rewinding file \"" << args.Container() << "\"\n";
      return 1;
    }
    sdctx.EncryptWhiteTable(header_buffer);
    sdctx.EncryptWhiteTable(stock1_buf);
    sdctx.EncryptWhiteTable(stock2_buf);
    memcpy(backup_buffer, header_buffer, HEADER_BLOCK_SIZE);
    sdctx.EncryptWhiteTable(backup_buffer);
    sdctx.EncryptWhiteTable(backup_buffer);
    if (!sdctx.Write(header_buffer, HEADER_BLOCK_SIZE) ||
        !sdctx.Write(stock1_buf, HEADER_BLOCK_SIZE) ||
        !sdctx.Write(stock2_buf, HEADER_BLOCK_SIZE) ||
        !sdctx.Write(backup_buffer, HEADER_BLOCK_SIZE))
    {
      std::cerr << "Error writing to file \"" << args.Container() << "\"\n";
      return 1;
    }
  }
  else
  {
    std::cerr << "Sorry, could'nt open \"" << args.Container() << "\"\n";
    return 1;
  }
  return 0;
}
