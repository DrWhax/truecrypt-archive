/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: sdctx.cpp,v 1.2 2005/08/11 20:49:32 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: sdctx.cpp,v $
 *  Revision 1.2  2005/08/11 20:49:32  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>

#include <getiv.h>
#include "cipher.h"
#include "digest.h"
#include "sdctx.h"

const int SdContext::head_crypt_steps = HEADER_BLOCK_SIZE/sizeof(uint32);

const int SdContext::sect_crypt_steps = SD_BLOCK_SIZE/sizeof(uint32);

SdContext::SdContext(const char* file, bool win, SdMode mode)
  : win_compatible(win), open_mode(mode), cipher(NULL), digest(NULL), hash(NULL)
{
  master_key = new octet[MASTER_KEY_SIZE];
  white_table = new octet[WHITE_TABLE_SIZE];
  if (file != NULL)
  {
    if (mode == rd)
      file_des = open(file, O_RDONLY, 0600);
    else
      file_des = open(file, O_RDWR | O_CREAT, 0600);
  }
  else
    file_des = -1;
}

SdContext::~SdContext()
{
  if (file_des != -1)
    close(file_des);
  if (hash != NULL)
  {
    memset(hash, 0, digest->Size());
    delete[] hash;
  }
  if (cipher != NULL)
    delete cipher;
  if (digest != NULL)
    delete digest;
  memset(white_table, 0, WHITE_TABLE_SIZE);
  delete[] white_table;
  memset(master_key, 0, MASTER_KEY_SIZE);
  delete[] master_key;
}

size_t SdContext::BlockSize()
{
  return cipher == NULL ? 0u : cipher->BlockSize();
}

/* Hash the passphrase
 */
bool SdContext::HashPhrase(const char* name, const octet* phrase, size_t size)
{
  if (digest != NULL)
  {
    if (hash != NULL)
    {
      memset(hash, 0, digest->Size());
      delete[] hash;
      hash = NULL;
    }
    delete digest;
    digest = NULL;
  }
  if (strcmp(name, "ripemd160") == 0)
    digest = new Ripemd160;
  else if (strcmp(name, "sha1") == 0)
    digest = new SHA1;
  else if (strcmp(name, "sha256") == 0)
    digest = new SHA256();
  else
    return false;
  hash = new octet[digest->Size()];
  if (hash != NULL)
    digest->Hash(phrase, size, hash);
  else
    return false;
  return true;
}

/* Initialize the cipher with the hash as key
 */
bool SdContext::InitHashCipher(const char* name)
{
  if (cipher != NULL)
    delete cipher;
  if (strcmp(name, "aes") == 0)
    cipher = new Rijndael();
  else if (strcmp(name, "blowfish") == 0)
    cipher = new Blowfish(digest->Size());
  else if (strcmp(name, "des") == 0)
    cipher = new DES();
  else if (strcmp(name, "des3") == 0)
    cipher = new DES3();
  else if (strcmp(name, "rijndael") == 0)
    cipher = new Rijndael();
  else if (strcmp(name, "serpent") == 0)
    cipher = new Serpent();
  else if (strcmp(name, "square") == 0)
    cipher = new Square();
  else if (strcmp(name, "tea") == 0)
    cipher = new Tea();
  else if (strcmp(name, "twofish") == 0)
    cipher = new Twofish();
  else
  {
    cipher = NULL;
    return false;
  }
  cipher->ReorderMemory(hash, digest->Size());
  memset(master_key, 0, MASTER_KEY_SIZE);
  memcpy(master_key, hash, digest->Size());
  cipher->Init(master_key);
  return true;
}

/* Initialize the cipher with the master key
 */
bool SdContext::InitRealCipher(const char* name)
{
  if (cipher != NULL)
    delete cipher;
  if (strcmp(name, "aes") == 0)
    cipher = new Rijndael();
  else if (strcmp(name, "blowfish") == 0)
    cipher = new Blowfish(32U);
  else if (strcmp(name, "des") == 0)
    cipher = new DES();
  else if (strcmp(name, "des3") == 0)
    cipher = new DES3();
  else if (strcmp(name, "rijndael") == 0)
    cipher = new Rijndael();
  else if (strcmp(name, "serpent") == 0)
    cipher = new Serpent();
  else if (strcmp(name, "square") == 0)
    cipher = new Square();
  else if (strcmp(name, "tea") == 0)
    cipher = new Tea();
  else if (strcmp(name, "twofish") == 0)
    cipher = new Twofish();
  else
  {
    cipher = NULL;
    return false;
  }
  cipher->Init(master_key);
  return true;
}

/* Set the white table and the master key from the buffer supplied
 */
void SdContext::SetWhiteTable(octet* buffer)
{
  memcpy(white_table, buffer, WHITE_TABLE_SIZE);
  memcpy(master_key, buffer + OFFSET_MASTER_KEY, MASTER_KEY_SIZE);
}

/* Encrypt a header block in CBC mode using 0 as IV
 */
void SdContext::EncryptWhiteTable(octet* buffer)
{
  uint32 ivl = 0U, ivr = 0U;
  uint32* buf = reinterpret_cast<uint32*>(buffer);

  switch (cipher->BlockSize())
  {
    case 8U:
      for (int n = 0; n < head_crypt_steps; n += 2U)
      {
        buf[n] ^= ivl;
        buf[n+1] ^= ivr;
        cipher->EncryptBlock(&buf[n]);
        ivl = buf[n];
        ivr = buf[n+1];
      }
      break;
    case 16U:
      if (win_compatible)
      { // cipher block chaining only on the first 64 bits of block
        for (int n = 0; n < head_crypt_steps; n += 4U)
        {
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          cipher->EncryptBlock(&buf[n]);
          ivl = buf[n];
          ivr = buf[n+1];
        }
      }
      else
      { // full cipher block chaining
        uint32 ivs = 0U, ivt = 0U;
        for (int n = 0; n < head_crypt_steps; n += 4U)
        {
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          buf[n+2] ^= ivs;
          buf[n+3] ^= ivt;
          cipher->EncryptBlock(&buf[n]);
          ivl = buf[n];
          ivr = buf[n+1];
          ivs = buf[n+2];
          ivt = buf[n+3];
        }
      }
      break;
    default:
      break;
  }
}

/* Decrypt a header block in CBC mode using 0 as IV
 */
void SdContext::DecryptWhiteTable(octet* buffer)
{
  uint32 ivl = 0U, ivr = 0U, ivl2, ivr2;
  uint32* buf = reinterpret_cast<uint32*>(buffer);

  switch (cipher->BlockSize())
  {
    case 8U:
      for (int n = 0; n < head_crypt_steps; n += 2U)
      {
        ivl2 = buf[n];
        ivr2 = buf[n+1];
        cipher->DecryptBlock(&buf[n]);
        buf[n] ^= ivl;
        buf[n+1] ^= ivr;
        ivl = ivl2;
        ivr = ivr2;
      }
      break;
    case 16U:
      if (win_compatible)
      { // cipher block chaining only on the first 64 bits of block
        for (int n = 0; n < head_crypt_steps; n += 4U)
        {
          ivl2 = buf[n];
          ivr2 = buf[n+1];
          cipher->DecryptBlock(&buf[n]);
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          ivl = ivl2;
          ivr = ivr2;
        }
      }
      else
      { // full cipher block chaining
        uint32 ivs = 0U, ivt = 0U, ivs2 = 0U, ivt2 = 0U;
        for (int n = 0; n < head_crypt_steps; n += 4U)
        {
          ivl2 = buf[n];
          ivr2 = buf[n+1];
          ivs2 = buf[n+2];
          ivt2 = buf[n+3];
          cipher->DecryptBlock(&buf[n]);
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          buf[n+2] ^= ivs;
          buf[n+3] ^= ivt;
          ivl = ivl2;
          ivr = ivr2;
          ivs = ivs2;
          ivt = ivt2;
        }
      }
      break;
    default:
      break;
  }
}

/* Encrypt a sector in CBC mode
 */
void SdContext::EncryptSector(octet* buffer, unsigned int sector_num)
{
  uint32 ivl, ivr, cbccl, cbccr;
  uint32* buf = reinterpret_cast<uint32*>(buffer);

  getiv64(&ivl, &ivr, &cbccl, &cbccr, sector_num, white_table);
  switch (cipher->BlockSize())
  {
    case 8U:
      for (int n = 0; n < sect_crypt_steps; n += 2U)
      {
        buf[n] ^= ivl;
        buf[n+1] ^= ivr;
        cipher->EncryptBlock(&buf[n]);
        ivl = buf[n];
        ivr = buf[n+1];
        buf[n] ^= cbccl;
        buf[n+1] ^= cbccr;
      }
      break;
    case 16U:
      if (win_compatible)
      { // cipher block chaining only on the first 64 bits of block
        for (int n = 0; n < sect_crypt_steps; n += 4U)
        {
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          cipher->EncryptBlock(&buf[n]);
          ivl = buf[n];
          ivr = buf[n+1];
          buf[n] ^= cbccl;
          buf[n+1] ^= cbccr;
        }
      }
      else
      { // full cipher block chaining
        uint32 ivs = 0U, ivt = 0U;
        for (int n = 0; n < sect_crypt_steps; n += 4U)
        {
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          buf[n+2] ^= ivs;
          buf[n+3] ^= ivt;
          cipher->EncryptBlock(&buf[n]);
          ivl = buf[n];
          ivr = buf[n+1];
          ivs = buf[n+2];
          ivt = buf[n+3];
          buf[n] ^= cbccl;
          buf[n+1] ^= cbccr;
          buf[n+2] ^= cbccr;
          buf[n+3] ^= cbccl;
        }
      }
      break;
    default:
      break;
  }
}

/* Decrypt a sector in CBC mode
 */
void SdContext::DecryptSector(octet* buffer, unsigned int sector_num)
{
  uint32 ivl, ivr, ivl2, ivr2, cbccl, cbccr;
  uint32* buf = reinterpret_cast<uint32*>(buffer);

  getiv64(&ivl, &ivr, &cbccl, &cbccr, sector_num, white_table);
  switch (cipher->BlockSize())
  {
    case 8U:
      for (int n = 0; n < sect_crypt_steps; n += 2U)
      {
        ivl2 = buf[n] ^= cbccl;
        ivr2 = buf[n+1] ^= cbccr;
        cipher->DecryptBlock(&buf[n]);
        buf[n] ^= ivl;
        buf[n+1] ^= ivr;
        ivl = ivl2;
        ivr = ivr2;
      }
      break;
    case 16U:
      if (win_compatible)
      { // cipher block chaining only on the first 64 bits of block
        for (int n = 0; n < sect_crypt_steps; n += 4U)
        {
          ivl2 = buf[n] ^= cbccl;
          ivr2 = buf[n+1] ^= cbccr;
          cipher->DecryptBlock(&buf[n]);
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          ivl = ivl2;
          ivr = ivr2;
        }
      }
      else
      { // full cipher block chaining
        uint32 ivs = 0U, ivt = 0U, ivs2 = 0U, ivt2 = 0U;
        for (int n = 0; n < sect_crypt_steps; n += 4U)
        {
          ivl2 = buf[n] ^= cbccl;
          ivr2 = buf[n+1] ^= cbccr;
          ivs2 = buf[n+2] ^= cbccr;
          ivt2 = buf[n+3] ^= cbccl;
          cipher->DecryptBlock(&buf[n]);
          buf[n] ^= ivl;
          buf[n+1] ^= ivr;
          buf[n+2] ^= ivs;
          buf[n+3] ^= ivt;
          ivl = ivl2;
          ivr = ivr2;
          ivs = ivs2;
          ivt = ivt2;
        }
      }
      break;
    default:
      break;
  }
}

bool SdContext::Read(octet* buffer, size_t size)
{
  if (file_des != -1)
  {
    int nr;
    int max_intr = 5;
    while (size > 0u)
    {
      nr = read(file_des, buffer, size);
      if (nr < 0 && errno == EINTR && max_intr-- > 0)
      {
        errno = 0;
        continue;
      }
      else if (nr <= 0)
        return false;
      buffer += nr;
      size -= nr;
      errno = 0;
    }
    return true;
  }
  return false;
}

bool SdContext::Write(octet* buffer, size_t size)
{
  if (file_des != -1 && open_mode == wr)
  {
    int nw;
    int max_intr = 5;
    while (size > 0u)
    {
      nw = write(file_des, buffer, size);
      if (nw < 0 && errno == EINTR && max_intr-- > 0)
      {
        errno = 0;
        continue;
      }
      else if (nw <= 0)
        return false;
      buffer += nw;
      size -= nw;
      errno = 0;
    }
    return true;
  }
  return false;
}

bool SdContext::Rewind()
{
  if (file_des != -1)
  {
    if (lseek(file_des, 0, SEEK_SET) != static_cast<off_t>(-1))
      return true;
  }
  return false;
}
