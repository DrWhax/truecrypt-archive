/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: mtab.cpp,v 1.2 2005/08/11 20:49:32 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: mtab.cpp,v $
 *  Revision 1.2  2005/08/11 20:49:32  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <sys/file.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <iostream>
#include "mtab.h"

#ifdef _PATH_MOUNTED
#define MOUNTED_LOCK _PATH_MOUNTED "~"
#else
#define MOUNTED_LOCK "/etc/mtab~"
#endif

/* Create the lock file
 * Use the mechanism of ordinary mount/umount in order to be interoperable!
 */
bool MTabLock::Lock()
{
  int tries = 3;
  char* linktarget;
  sigset_t sigset_new;

  if (!sig_changed)
  {
    if (sigfillset(&sigset_new) != 0)
      return false;
    if (sigprocmask(SIG_SETMASK, &sigset_new, &sigset) != 0)
      return false;
    sig_changed = true;
  }
  linktarget = new char[strlen(MOUNTED_LOCK) + 20];
  sprintf(linktarget, MOUNTED_LOCK "%d", getpid());
  while (!lock_created)
  { // Repeat until it was us who made the link
    int errsv, fd, i, j;
    struct flock flock;

    flock.l_type = F_WRLCK;
    flock.l_whence = SEEK_SET;
    flock.l_start = 0;
    flock.l_len = 0;
    i = open(linktarget, O_WRONLY|O_CREAT, 0);
    if (i < 0)
    {
      int errsv = errno;
      /* linktarget does not exist (as a file) and we cannot create it
       * Read-only filesystem?
       * Too many files open in the system?
       * Filesystem full?
       */
      std::cerr << "Can't create lock file " << linktarget << ": "
                << strerror(errsv) << "\n";
      delete[] linktarget;
      return false;
    }
    close(i);
    j = link(linktarget, MOUNTED_LOCK);
    errsv = errno;
    unlink(linktarget);
    if (j < 0 && errsv != EEXIST)
    {
      std::cerr << "Can't link lock file " << MOUNTED_LOCK << ": "
                << strerror(errsv) << "\n";
      delete[] linktarget;
      return false;
    }
    fd = open(MOUNTED_LOCK, O_WRONLY);
    if (fd < 0)
    {
      int errsv = errno;
      // Strange... Maybe the file was just deleted?
      if (errno == ENOENT && tries-- > 0)
        continue;
      std::cerr << "Can't open lock file " << MOUNTED_LOCK << ": "
                << strerror(errsv) << "\n";
      delete[] linktarget;
      return false;
    }
    if (j == 0)
    { // We made the link, now claim the lock
      fcntl(fd, F_SETLK, &flock);
      // Proceed anyway
      lock_created = true;
      close(fd);
    }
    else
    { // Someone else made the link, wait
      if (lock_trials++ > 9)
      {
        std::cerr << "Can't create link " << MOUNTED_LOCK
                  << "\nPerhaps there is a stale lock file?\n";
        delete[] linktarget;
        return false;
      }
      close(fd);
      sleep(1);
    }
  }
  delete[] linktarget;
  return true;
}

/* Remove lock file
 */
void MTabLock::UnLock()
{
  if (sig_changed)
  { // Reset signal mask
    if (sigprocmask(SIG_SETMASK, &sigset, NULL) == 0)
      sig_changed = false;
  }
  if (lock_created)
  {
    unlink(MOUNTED_LOCK);
    lock_created = false;
    lock_trials = 0;
  }
}

MTabContainer::~MTabContainer()
{
  std::list<struct mntent*>::iterator i = mnt_list.begin();
  while (i != mnt_list.end())
  {
    free((*i)->mnt_fsname);
    free((*i)->mnt_dir);
    free((*i)->mnt_type);
    free((*i)->mnt_opts);
    delete (*i);
    ++i;
  }
}


/* Add a struct mntent to the container
 */
void MTabContainer::Add(struct mntent* mnt)
{
  if (mnt != NULL)
  {
    struct mntent* mnt_copy = new struct mntent;
    mnt_copy->mnt_fsname = strdup(mnt->mnt_fsname);
    mnt_copy->mnt_dir = strdup(mnt->mnt_dir);
    mnt_copy->mnt_type = strdup(mnt->mnt_type);
    mnt_copy->mnt_opts = strdup(mnt->mnt_opts);
    mnt_copy->mnt_freq = mnt->mnt_freq;
    mnt_copy->mnt_passno = mnt->mnt_passno;
    mnt_list.push_back(mnt_copy);
  }
}

/* Step to next element of the container and remove the last one
 */
void MTabContainer::Step()
{
  struct mntent* mnt = Next();
  if (mnt != NULL)
  {
    free(mnt->mnt_fsname);
    free(mnt->mnt_dir);
    free(mnt->mnt_type);
    free(mnt->mnt_opts);
    delete mnt;
    mnt_list.pop_front();
  }
}
