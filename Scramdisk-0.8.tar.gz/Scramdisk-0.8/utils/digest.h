/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: digest.h,v 1.2 2005/08/11 20:49:32 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: digest.h,v $
 *  Revision 1.2  2005/08/11 20:49:32  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#ifndef SD_DIGEST_H
#define SD_DIGEST_H

extern "C" {
#include <bits.h>
#include <rmd160.h>
#include <sha1.h>
#include <sha256.h>
}

class Digest
{
  private:
    const char* digest_name;

  protected:
    const size_t size;

  public:
    Digest(const char* name, size_t s) : digest_name(name), size(s) { }
    virtual ~Digest() { }
    virtual void Hash(const octet* phrase, size_t size, octet* hash) = 0;
    const char* Name() { return digest_name; }
    size_t Size() { return size; }
};

class SHA1 : public Digest
{
  private:
    sha1_ctx* ctx;

  public:
    SHA1() : Digest("SHA1", 20U) { ctx = new sha1_ctx; }
    ~SHA1() { delete ctx; }
    virtual void Hash(const octet* phrase, size_t psize, octet* hash)
    {
      sha1_init(ctx);
      sha1_hash(ctx, phrase, psize);
      sha1_done(ctx, hash);
    }
};

class SHA256 : public Digest
{
  private:
    sha256_ctx* ctx;

  public:
    SHA256() : Digest("SHA256", 32U) { ctx = new sha256_ctx; }
    ~SHA256() { delete ctx; }
    virtual void Hash(const octet* phrase, size_t psize, octet* hash)
    {
      sha256_init(ctx);
      sha256_hash(ctx, phrase, psize);
      sha256_done(ctx, hash);
    }
};

class Ripemd160 : public Digest
{
  private:
    rmd160_ctx* ctx;

  public:
    Ripemd160() : Digest("Ripemd160", 20U) { ctx = new rmd160_ctx; }
    ~Ripemd160() { delete ctx; }
    virtual void Hash(const octet* phrase, size_t psize, octet* hash)
    {
      rmd160_init(ctx);
      rmd160_hash(ctx, phrase, psize);
      rmd160_done(ctx, hash);
    }
};

#endif
