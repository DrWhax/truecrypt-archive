/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: cipher.h,v 1.2 2005/08/11 20:49:32 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: cipher.h,v $
 *  Revision 1.2  2005/08/11 20:49:32  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#ifndef SD_CIPHER_H
#define SD_CIPHER_H

#include <string.h>

extern "C" {
#include <bits.h>
#include <blowfish.h>
#include <des.h>
#include <des3.h>
#include <rijndael.h>
#include <serpent.h>
#include <square.h>
#include <rijndael.h>
#include <tea.h>
#include <twofish.h>
}

class Cipher
{
  private:
    const char* cipher_name;

  protected:
    const size_t key_size;
    const size_t block_size;

  public:
    Cipher(const char* name, size_t ksz, size_t bsz)
      : cipher_name(name), key_size(ksz), block_size(bsz) { }
    virtual ~Cipher() { }
    virtual void Init(const octet* key) = 0;
    virtual void EncryptBlock(uint32* buf) = 0;
    virtual void DecryptBlock(uint32* buf) = 0;
    void ReorderMemory(octet* buffer, size_t size);
    const char* Name() { return cipher_name; }
    size_t KeySize() { return key_size; }
    size_t BlockSize() { return block_size; }
};

class Blowfish : public Cipher
{
  private:
    blowfish_ctx* ctx;

  public:
    Blowfish(size_t ksz)
      : Cipher("Blowfish", ksz, 8U) { ctx = new blowfish_ctx; }
    ~Blowfish() { delete ctx; }
    virtual void Init(const octet* key) { blowfish_init(ctx, key, key_size); }
    virtual void EncryptBlock(uint32* buf) { blowfish_eblk(ctx, buf, buf); }
    virtual void DecryptBlock(uint32* buf) { blowfish_dblk(ctx, buf, buf); }
};

class DES : public Cipher
{
  private:
    des_ctx* ctx;

  public:
    DES() : Cipher("DES", 8U, 8U) { ctx = new des_ctx; }
    ~DES() { delete ctx; }
    virtual void Init(const octet* key) { des_init(ctx, key, key_size); }
    virtual void EncryptBlock(uint32* buf)
    {
      ReorderMemory(reinterpret_cast<octet*>(buf), block_size);
      des_eblk(ctx, buf, buf);
      ReorderMemory(reinterpret_cast<octet*>(buf), block_size);
    }
    virtual void DecryptBlock(uint32* buf)
    {
      ReorderMemory(reinterpret_cast<octet*>(buf), block_size);
      des_dblk(ctx, buf, buf);
      ReorderMemory(reinterpret_cast<octet*>(buf), block_size);
    }
};

class DES3 : public Cipher
{
  private:
    des3_ctx* ctx;

  public:
    DES3() : Cipher("DES", 24U, 8U) { ctx = new des3_ctx; }
    ~DES3() { delete ctx; }
    virtual void Init(const octet* key) { des3_init(ctx, key, key_size); }
    virtual void EncryptBlock(uint32* buf)
    {
      ReorderMemory(reinterpret_cast<octet*>(buf), block_size);
      des3_eblk(ctx, buf, buf);
      ReorderMemory(reinterpret_cast<octet*>(buf), block_size);
    }
    virtual void DecryptBlock(uint32* buf)
    {
      ReorderMemory(reinterpret_cast<octet*>(buf), block_size);
      des3_dblk(ctx, buf, buf);
      ReorderMemory(reinterpret_cast<octet*>(buf), block_size);
    }
};

class Rijndael : public Cipher
{
  private:
    rijndael_ctx* ctx;

  public:
    Rijndael() : Cipher("Rijndael", 32U, 16U) { ctx = new rijndael_ctx; }
    ~Rijndael() { delete ctx; }
    virtual void Init(const octet* key) { rijndael_init(ctx, key, key_size); }
    virtual void EncryptBlock(uint32* buf) { rijndael_eblk(ctx, buf, buf); }
    virtual void DecryptBlock(uint32* buf) { rijndael_dblk(ctx, buf, buf); }
};

class Serpent : public Cipher
{
  private:
    serpent_ctx* ctx;

  public:
    Serpent() : Cipher("Serpent", 32U, 16U) { ctx = new serpent_ctx; }
    ~Serpent() { delete ctx; }
    virtual void Init(const octet* key) { serpent_init(ctx, key, key_size); }
    virtual void EncryptBlock(uint32* buf) { serpent_eblk(ctx, buf, buf); }
    virtual void DecryptBlock(uint32* buf) { serpent_dblk(ctx, buf, buf); }
};

class Square : public Cipher
{
  private:
    square_ctx* ctx;

  public:
    Square() : Cipher("Square", 16U, 16U) { ctx = new square_ctx; }
    ~Square() { delete ctx; }
    virtual void Init(const octet* key) { square_init(ctx, key, key_size); }
    virtual void EncryptBlock(uint32* buf) { square_eblk(ctx, buf, buf); }
    virtual void DecryptBlock(uint32* buf) { square_dblk(ctx, buf, buf); }
};

class Tea : public Cipher
{
  private:
    tea_ctx* ctx;

  public:
    Tea() : Cipher("Tea", 16U, 8U) { ctx = new tea_ctx; }
    ~Tea() { delete ctx; }
    virtual void Init(const octet* key)
    {
      octet k[key_size];
      memcpy(k, key, key_size);
      ReorderMemory(k, key_size);
      tea_init(ctx, k, key_size);
    }
    virtual void EncryptBlock(uint32* buf) { tea_eblk(ctx, buf, buf); }
    virtual void DecryptBlock(uint32* buf) { tea_dblk(ctx, buf, buf); }
};

class Twofish : public Cipher
{
  private:
    twofish_ctx* ctx;

  public:
    Twofish() : Cipher("Twofish", 32U, 16U) { ctx = new twofish_ctx; }
    ~Twofish() { delete ctx; }
    virtual void Init(const octet* key) { twofish_init(ctx, key, key_size); }
    virtual void EncryptBlock(uint32* buf) { twofish_eblk(ctx, buf, buf); }
    virtual void DecryptBlock(uint32* buf) { twofish_dblk(ctx, buf, buf); }
};

#endif
