/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: sdmnt.cpp,v 1.2 2005/08/11 20:49:32 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: sdmnt.cpp,v $
 *  Revision 1.2  2005/08/11 20:49:32  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include "sdmnt.h"

SdMount::SdMount(MntAction ma) : good(false), mounted(false), action(ma)
{
  memset(&sd_mount, 0, sizeof(sd_mount));
  sd_mount.filename = static_cast<char*>(malloc(PATH_MAX));
  if (sd_mount.filename != NULL)
  {
    sd_mount.mnt_point = static_cast<char*>(malloc(PATH_MAX));
    if (sd_mount.mnt_point != NULL)
    {
      sd_mount.passwordbuffer = static_cast<char*>(malloc(160u));
      if (sd_mount.passwordbuffer == NULL)
      {
        free(sd_mount.mnt_point);
        free(sd_mount.filename);
      }
      else
        good = true;
    }
    else
      free(sd_mount.filename);
  }
}

SdMount::~SdMount()
{
  if (good)
  {
    int fd = -1;
    if (mounted && action == TmpMnt)
      fd = open("/dev/scramdisk/master", O_RDONLY);
    if (fd >= 0)
    {
      ioctl(fd, SCRAMDISK_IOC_UMOUNT, &sd_mount);
      close(fd);
    }
    if (sd_mount.mnt_point)
      free(sd_mount.mnt_point);
    if (sd_mount.filename)
      free(sd_mount.filename);
    if (sd_mount.passwordbuffer)
    {
      memset(sd_mount.passwordbuffer, 0, 160u);
      free(sd_mount.passwordbuffer);
    }
  }
}

int SdMount::Mount()
{
  int fd = -1;
  if (good && !mounted && action != UMnt)
    fd = open("/dev/scramdisk/master", O_RDONLY);
  if (fd >= 0)
  {
    int slot;
    slot = ioctl(fd, SCRAMDISK_IOC_MOUNT, &sd_mount);
    close(fd);
    mounted = slot > 0;
    return mounted ? slot : -2;
  }
  else
    return -1;
}

bool SdMount::UMount()
{
  int fd = -1;
  if (good && action == UMnt || mounted && action == TmpMnt)
    fd = open("/dev/scramdisk/master", O_RDONLY);
  if (fd >= 0)
  {
    int ret;
    ret = ioctl(fd, SCRAMDISK_IOC_UMOUNT, &sd_mount);
    close(fd);
    mounted = ret < 0;
    return !mounted;
  }
  return false;
}

void SdMount::SetPhrase(const octet* phrase, size_t size)
{
  if (size > 160u)
    size = 160u;
  if (good)
    memcpy(sd_mount.passwordbuffer, phrase, size);
}
