/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: args.cpp,v 1.2 2005/08/11 20:49:32 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: args.cpp,v $
 *  Revision 1.2  2005/08/11 20:49:32  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <fstream>
#include <iostream>
#include <stdlib.h>
#include "args.h"

Arguments::Arguments(Action act, int argc, char** argv, std::ostream& os)
  : action(act), fs_type(NoFS), good(true), hide(-1), rd_only(-1),
    win_compatible(-1), use_backup(-1), container_size(0u), ostr(os)
{
  int nofs = -1;
  bool default_cfg = false;
  bool help_called = false;
  bool help_requested = false;
  bool version_requested = false;
  for (int j = 1; j < argc && good; ++j)
  {
    if ((!strcmp(argv[j], "-h") || !strcmp(argv[j], "-help")))
    {
      help_requested = true;
      if (!help_called)
        Help(argv[0]);
      help_called = true;
    }
    else if ((!strcmp(argv[j], "-v") || !strcmp(argv[j], "-version")))
    {
      ostr << "Scramdisk version " << SD_VERSION << "\n";
      version_requested = true;
    }
    else if (!strcmp(argv[j], "-cfg") && ++j < argc)
    {
      if (cfg_file.empty())
        cfg_file = argv[j];
      else
        good = false;
    }
    else if (!strcmp(argv[j], "-show-pass"))
    {
      hide = 0;
    }
    else if (!strcmp(argv[j], "-no-fs"))
    {
      nofs = 1;
    }
    else if (!strcmp(argv[j], "-read-only"))
    {
      rd_only = 1;
    }
    else if (!strcmp(argv[j], "-win-compatible"))
    {
      win_compatible = 1;
    }
    else if (!strcmp(argv[j], "-use-backup"))
    {
      use_backup = 1;
    }
    else if (!strcmp(argv[j], "-cipher") && ++j < argc)
    {
      if (cipher_name.empty())
        cipher_name = argv[j];
      else
        good = false;
    }
    else if (!strcmp(argv[j], "-digest") && ++j < argc)
    {
      if (digest_name.empty())
        digest_name = argv[j];
      else
        good = false;
    }
    else if ((!strcmp(argv[j], "-c") || !strcmp(argv[j], "-container")) &&
             ++j < argc)
    {
      if (container.empty())
        container = argv[j];
      else
        good = false;
    }
    else if ((!strcmp(argv[j], "-mnt") || !strcmp(argv[j], "-mount-point")) &&
             ++j < argc)
    {
      if (mount_point.empty())
        mount_point = argv[j];
      else
        good = false;
    }
    else if ((!strcmp(argv[j], "-t") || !strcmp(argv[j], "-fstype")) &&
             ++j < argc)
    {
      if (fsname.empty())
        fsname = argv[j];
      else
        good = false;
    }
    else if (!strcmp(argv[j], "-mkfs-command") && ++j < argc)
    {
      if (mkfs_command.empty())
        mkfs_command = argv[j];
      else
        good = false;
    }
    else if ((!strcmp(argv[j], "-rnd") || !strcmp(argv[j], "-random")) &&
             ++j < argc)
    {
      if (rnd_name.empty())
        rnd_name = argv[j];
      else
        good = false;
    }
    else if (!strcmp(argv[j], "-kb") && ++j < argc)
    {
      int k = atoi(argv[j]);
      if (container_size != 0u)
        good = false;
      if (k > 0)
        container_size = static_cast<size_t>(k)*2ul;
      else
        good = false;
    }
    else if (!strcmp(argv[j], "-mb") && ++j < argc)
    {
      int k = atoi(argv[j]);
      if (container_size != 0u)
        good = false;
      if (k > 0)
        container_size = static_cast<size_t>(k)*2048ul;
      else
        good = false;
    }
    else
      good = false;
  }
  if (help_requested || version_requested)
    good = false;
  if (cfg_file.empty())
  {
    default_cfg = true;
    cfg_file = getenv("HOME");
    cfg_file.append("/.scramdisk/scramdiskrc");
  }
  ReadCfgFile(argv[0], default_cfg, nofs);
  cfg_file = "/etc/scramdisk/scramdiskrc";
  ReadCfgFile(argv[0], true, nofs);
  if (mkfs_command.empty())
    mkfs_command = "/sbin/mkfs";
  if (rnd_name.empty())
    rnd_name = "/dev/random";
  if (cipher_name.empty())
    cipher_name = "blowfish";
  if (digest_name.empty())
    digest_name = "sha1";
  if (action == Create || action == Mount)
  {
    if (nofs == 1)
      fs_type = NoFS;
    else if (fsname.empty())
    {
      if (action == Create)
        fs_type = Ext2;
      else
        fs_type = Auto;
    }
    else if (fsname == "ext2")
      fs_type = Ext2;
    else if (fsname == "ext3")
      fs_type = Ext3;
    else if (fsname == "reiserfs")
      fs_type = ReiserFS;
    else if (fsname == "minix")
      fs_type = Minix;
    else if (fsname == "msdos")
      fs_type = MSDos;
    else if (fsname == "vfat")
      fs_type = VFat;
    else if (fsname == "auto" && action == Mount)
      fs_type = Auto;
    else
      good = false;
  }
  else if (action == UnMount && nofs != 1)
    fs_type = Auto;
  if (!help_requested && !version_requested)
  {
    if (container.empty())
    {
      if (action != UnMount)
      {
        ostr << "Sorry, a container must be given\n";
        good = false;
      }
      else if (mount_point.empty())
      {
        ostr << "Sorry, a container or a mount point must be given\n";
        good = false;
      }
    }
    if (action == Create && container_size < 1024u)
    {
      ostr << "Sorry, container size must be at least 512 KB\n";
      good = false;
    }
    if (action == Mount && mount_point.empty() && nofs != 1)
    {
      ostr << "Sorry, a mount point must be given\n";
      good = false;
    }
  }
  if (!good && !help_called && !version_requested)
    Help(argv[0]);
}

void Arguments::Help(const char* name)
{
  ostr << "\nUsage:\n";
  ostr << name << (strlen(name) < 8u ? "\t " : " ")
       << "[-cfg <config_file>] [(-container | -c) <container>] \\\n";
  if (action == Create)
    ostr << "\t [-digest <digest_name>] [-cipher <cipher_name>]"
         << " [(-kb | -mb) <size>] \\\n"
         << "\t [(-fstype | -t) <fs_type>] [-mkfs-command <mkfs_command>]"
         << " [-no-fs] \\\n\t [(-random | -rnd) <random_device>]"
         << " [-win-compatible] [-show-pass] \\\n\t";
  else if (action == Change)
    ostr << "\t [-use-backup] [-show-pass]";
  else if (action == Mount)
    ostr << "\t [(-mount-point | -mnt) <mount_point>] "
         << "[(-fstype | -t) <fs_type>] \\\n\t"
         << " [-no-fs] [-read-only] [-show-pass]";
  else if (action == UnMount)
    ostr << "\t [(-mount-point | -mnt) <mount_point>] [-no-fs] \\\n\t";
  ostr << " [-version | -v] [-help | -h]\n";
  ostr << "\nParameter:\n";
  ostr << "<config_file>\t: name of the configuration file "
       << "(default is $HOME/.scramdisk/scramdiskrc)\n";
  if (action == Create)
  {
    ostr << "<container>\t: name of the container file to be created\n";
    ostr << "<digest_name>\t: name of the digest algorithm\n"
         << "\t\t  (default is sha1, supported algorithms:\n"
         << "\t\t  ripemd160, sha1, sha256)\n";
    ostr << "<cipher_name>\t: name of the cipher algorithm\n"
         << "\t\t  (default is blowfish, supported algorithms:\n\t\t  aes,"
         << " blowfish, des, des3, serpent, square, tea, twofish)\n";
    ostr << "<size>\t\t: size of the container in KB or MB for -kb/-mb "
         << "respectively\n"
         << "\t\t  (the generated file will be 10 KB larger)\n";
    ostr << "<fs_type>\t: type of the filesystem to be created\n"
         << "\t\t  (default is ext2, supported types:\n"
         << "\t\t  ext2, ext3, reiserfs, minix, msdos, vfat)\n";
    ostr << "<mkfs_command>\t: name of the command to create the file "
         << "system\n\t\t  (default is /sbin/mkfs)\n";
    ostr << "-no-fs\t\t: do not create a filesystem"
         << " in the new container\n";
    ostr << "<random_device>\t: name of a device or file from which random"
         << " data shall be read\n\t\t  (default is /dev/random)\n";
    ostr << "-win-compatible\t: create a container compatible with"
         << " scramdisk for windows\n\t\t  "
         << "(this has an effect only for 128 Bit block ciphers,\n\t\t  "
         << "for 64 Bit block ciphers compatibility is given any way)\n";
    ostr << "-show-pass\t: show the passphrase while typing "
         << "(instead of asterisks)\n";
  }
  else if (action == Change)
  {
    ostr << "<container>\t: name of the container file to be changed\n";
    ostr << "-use-backup\t: use the backup header block to retrieve the key\n"
         << "\t\t  (the main header block will be updated\n"
         << "\t\t  if the key opens the container)\n";
    ostr << "-show-pass\t: show the passphrase while typing "
         << "(instead of asterisks)\n";
  }
  else if (action == Mount)
  {
    ostr << "<container>\t: name of the container to be mounted\n";
    ostr << "<mount_point>\t: directory where the container shall be mounted\n";
    ostr << "<fs_type>\t: type of the filesystem to be mounted\n"
         << "\t\t  (default is auto, supported types:\n"
         << "\t\t  auto, ext2, ext3, reiserfs, minix, msdos, vfat)\n";
    ostr << "-no-fs\t\t: do not mount the filesystem, "
         << "only load the encryption key\n";
    ostr << "-read-only\t: mount the container read only\n";
    ostr << "-show-pass\t: show the passphrase while typing"
         << " (instead of asterisks)\n";
  }
  else if (action == UnMount)
  {
    ostr << "<container>\t: name of the container to be unmounted\n";
    ostr << "<mount_point>\t: directory where the container shall be mounted\n";
    ostr << "-no-fs\t\t: do not unmount the filesystem, "
         << "only unload the encryption key\n";
  }
  ostr << "-version\t: print the scramdisk version number\n";
  ostr << "-help\t\t: print this message\n";
}

void Arguments::ReadCfgFile(const char* program, bool default_cfg, int& nofs)
{
  std::string::size_type n;
  std::string section = program;
  if ((n = section.find_last_of('/')) != section.npos)
    section.erase(0u, ++n);
  std::ifstream fs(cfg_file.c_str());
  if (fs)
  {
    std::string l, s, par, val;
    do
    {
      getline(fs, l);
      if ((n = l.find('#')) != l.npos)
        l.erase(n);
      while ((n = l.find_first_of(" \t\v\r\n\f")) != l.npos)
        l.erase(n, 1u);
      if (l.find('[') == 0u && (n = l.find(']')) != l.npos)
        s = l.substr(1u, --n);
      else if (s == section)
      {
        if ((n = l.find('=')) != l.npos)
        {
          par = l.substr(0u, n);
          val = l.substr(++n);
          if (par == "show-pass" && hide == -1)
          {
            if (val == "true")
              hide = 0;
            else if (val == "false")
              hide = 1;
          }
          if (par == "no-fs" && nofs == -1)
          {
            if (val == "true")
              nofs = 1;
            else if (val == "false")
              nofs = 0;
          }
          if (par == "read-only" && rd_only == -1)
          {
            if (val == "true")
              rd_only = 1;
            else if (val == "false")
              rd_only = 0;
          }
          if (par == "win-compatible" && win_compatible == -1)
          {
            if (val == "true")
              win_compatible = 1;
            else if (val == "false")
              win_compatible = 0;
          }
          else if (par == "use-backup" && use_backup == -1)
          {
            if (val == "true")
              use_backup = 1;
            else if (val == "false")
              use_backup = 0;
          }
          else if (par == "container" && container.empty())
            container = val;
          else if (par == "mount-point" && mount_point.empty())
            mount_point = val;
          else if (par == "fs-type" && fsname.empty())
            fsname = val;
          else if (par == "mkfs-command" && mkfs_command.empty())
            mkfs_command = val;
          else if (par == "cipher" && cipher_name.empty())
            cipher_name = val;
          else if (par == "digest" && digest_name.empty())
            digest_name = val;
          else if ((par == "rnd" || par == "random") && rnd_name.empty())
            rnd_name = val;
          else if ((par == "kb" || par == "KB") && container_size == 0u)
          {
            int k = atoi(val.c_str());
            if (k > 0)
              container_size = static_cast<size_t>(k)*2ul;
            else
              good = false;
          }
          else if ((par == "mb" || par == "MB") && container_size == 0u)
          {
            int k = atoi(val.c_str());
            if (k > 0)
              container_size = static_cast<size_t>(k)*2048ul;
            else
              good = false;
          }
        }
      }
    } while (!fs.eof());
  }
  else if (!default_cfg)
  {
    ostr << "Sorry, could not read file '" << cfg_file << "'\n";
    good = false;
  }
}
