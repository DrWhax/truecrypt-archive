/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: sdumount.cpp,v 1.2 2005/08/11 20:49:32 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: sdumount.cpp,v $
 *  Revision 1.2  2005/08/11 20:49:32  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <sys/types.h>
#include <sys/mount.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdlib.h>
#include <iostream>
#include <cstdio>
#include "mtab.h"
#include "args.h"
#include "sdmnt.h"

int main(int argc, char** argv)
{
  uid_t uid = getuid();

  if (seteuid(uid) == 0)
  {
    bool container_given;
    bool mount_point_given;
    MTabLock mtl;
    Arguments args(UnMount, argc, argv);
    SdMount sd_mount(UMnt);

    if (!sd_mount.Good())
    {
      std::cerr << "ERROR: No more memory\n";
      return 1;
    }
    if (!args.Good())
      return 1;
    container_given = (strlen(args.Container()) > 0);
    if (container_given)
    {
      if (access(args.Container(), F_OK | R_OK) != 0)
      {
        std::cerr << "ERROR: No access to container file "
                  << args.Container() << "\n";
        return 1;
      }
      if (realpath(args.Container(), sd_mount.Filename()) == NULL)
      {
        std::cerr << "ERROR: Couldn't resolve container pathname, error "
                  << errno << ": " << strerror(errno) << "\n";
        return 1;
      }
    }
    mount_point_given = (strlen(args.MountPoint()) > 0);
    if (mount_point_given)
    {
      if (realpath(args.MountPoint(), sd_mount.MountPoint()) == NULL)
      {
        std::cerr << "ERROR: Couldn't resolve mount point pathname, error "
                  << errno << ": " << strerror(errno) << "\n";
        return 1;
      }
    }
    if (args.FSType() != NoFS && seteuid(0) == 0 && mtl.Lock())
    {
      bool mounted = false;
      FILE* fmt;
      struct mntent* pmnt;
      class MTabContainer mtab;

      fmt = setmntent(_PATH_MOUNTED, "r");
      if (fmt == NULL)
      {
        std::cerr << "ERROR: Could not open " << _PATH_MOUNTED << "\n";
        return 1;
      }
      while ((pmnt = getmntent(fmt)) != NULL)
      {
        if (container_given)
        {
          if (!mounted && strcmp(pmnt->mnt_fsname, sd_mount.Filename()) == 0)
          {
            mounted = true;
            if (mount_point_given &&
                strcmp(pmnt->mnt_dir, sd_mount.MountPoint()) != 0)
            {
              std::cerr << "ERROR: Wrong mount point " << pmnt->mnt_dir
                        << " in " << _PATH_MOUNTED << "\n";
              endmntent(fmt);
              return 1;
            }
            else
            {
              strncpy(sd_mount.MountPoint(), pmnt->mnt_dir, PATH_MAX);
              sd_mount.MountPoint()[PATH_MAX - 1] = '\0';
            }
          }
          else
            mtab.Add(pmnt);
        }
        else
        {
          if (!mounted && strcmp(pmnt->mnt_dir, sd_mount.MountPoint()) == 0)
          {
            strncpy(sd_mount.Filename(), pmnt->mnt_fsname, PATH_MAX);
            sd_mount.Filename()[PATH_MAX - 1] = '\0';
            if (access(sd_mount.Filename(), F_OK | R_OK) != 0)
            {
              std::cerr << "ERROR: No access to container file "
                        << pmnt->mnt_fsname << " mounted on "
                        << pmnt->mnt_dir << "\n";
              endmntent(fmt);
              return 1;
            }
            mounted = true;
          }
          else
            mtab.Add(pmnt);
        }
      }
      endmntent(fmt);
      if (!mounted)
      {
        std::cerr << "ERROR: container " << sd_mount.Filename()
                  << " seems not to be mounted\n";
        return 1;
      }
      if (umount(sd_mount.MountPoint()))
      {
        std::cerr << "ERROR: Could not unmount container: "
                  << sd_mount.Filename() << ", error " << errno
                  << ": " << strerror(errno) << "\n";
        return 1;
      }
      fmt = setmntent(MOUNTED_TMP, "w");
      while ((pmnt = mtab.Next()) != NULL)
      {
        addmntent(fmt, pmnt);
        mtab.Step();
      }
      endmntent(fmt);
      rename(MOUNTED_TMP, _PATH_MOUNTED);
      mtl.UnLock();
    }
    seteuid(uid); // ignore erros
    if (!sd_mount.UMount())
    {
      std::cerr << "ERROR: Couldn't unmount device\n";
      return 1;
    }
  }
  return 0;
}
