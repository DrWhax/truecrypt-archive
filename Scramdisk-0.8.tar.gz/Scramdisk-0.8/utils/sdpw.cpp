/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: sdpw.cpp,v 1.2 2005/08/11 20:49:32 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: sdpw.cpp,v $
 *  Revision 1.2  2005/08/11 20:49:32  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <iostream>
#include <string.h>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include "sdpw.h"

#define ASCII_BS  0x08
#define ASCII_ESC 0x1b
#define ASCII_DEL 0x7f

void SdPassphrase::GetLine(int j, octet* buf)
{
  int c;
  int k = 0;
  printf(prompt, j+1);
  c = fgetc(stdin);
  while (c != EOF && c != '\n')
  {
    if (c == ASCII_ESC)
    {
      fputc('\a', stdout);
      c = fgetc(stdin);
      while (c != '~')
        c = fgetc(stdin);
      // most keybord escape sequences end in '~'
      // TODO: what about the other ones
    }
    else if (c == ASCII_BS || c == ASCII_DEL)
    {
      if (k > 0)
      {
        buf[--k] = '\0';
        fputc('\b', stdout);
        fputc(' ', stdout);
        fputc('\b', stdout);
      }
      else
        fputc('\a', stdout);
    }
    else
    {
      if (k < 40)
      {
        buf[k++] = c;
        if (hidden)
          fputc('*', stdout);
        else
          fputc(c, stdout);
      }
      else
        fputc('\a', stdout);
    }
    fflush(stdout);
    c = fgetc(stdin);
  }
  fputc('\n', stdout);
}

SdPassphrase::SdPassphrase(bool check, char* pr, char* ch_msg)
  : read(false), hidden(true), with_check(check), prompt(pr), check_msg(ch_msg)
{
  memset(pwbuf, 0, 160u);
};

SdPassphrase::~SdPassphrase()
{
  memset(pwbuf, 0, 160u);
};

void SdPassphrase::Clear()
{
  read = false;
  memset(pwbuf, 0, 160u);
};

bool SdPassphrase::Read()
{
  bool ok = true;
  int j;
  struct termios ts, ts_save;
  // change terminal settings
  if (tcgetattr(STDIN_FILENO, &ts) != 0)
  {
    perror("tcgetattr");
    return false;
  }
  ts_save = ts;
  ts.c_lflag &= ~ECHO;
  ts.c_lflag &= ~ICANON;
  ts.c_cc[VMIN] = 1;
  ts.c_cc[VTIME] = 0;
  if (tcsetattr(STDIN_FILENO, TCSAFLUSH, &ts) != 0)
  {
    perror("tcsetattr");
    return false;
  }
  // read four lines
  for (j = 0; j < 4; ++j)
    GetLine(j, pwbuf+40*j);
  if (with_check)
  {
    octet buf[160];
    memset(buf, 0, 160u);
    printf(check_msg);
    for (j = 0; j < 4; ++j)
      GetLine(j, buf+40*j);
    ok = (memcmp(pwbuf, buf, 160) == 0);
    memset(buf, 0, 160u);
  }
  // restore terminal settings
  if (tcsetattr(STDIN_FILENO, TCSANOW, &ts_save) != 0)
  {
    perror("tcsetattr");
    return false;
  }
  return ok;
}
