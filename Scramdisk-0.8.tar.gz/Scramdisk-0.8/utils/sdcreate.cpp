/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: sdcreate.cpp,v 1.2 2005/08/11 20:49:32 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: sdcreate.cpp,v $
 *  Revision 1.2  2005/08/11 20:49:32  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#include <sys/mount.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <cstdio>
#include "rnd.h"
#include "args.h"
#include "sdpw.h"
#include "sdctx.h"
#include "sdmnt.h"

int main(int argc, char** argv)
{
  uid_t uid = getuid();
  gid_t gid = getgid();

  if (seteuid(uid) == 0)
  {
    Arguments args(Create, argc, argv);
    if (!args.Good())
      return 1;
    SdPassphrase sdpw(true);
    sdpw.SetHidden(args.Hide());
    if (!sdpw.Read())
    {
      std::cerr << "Sorry, passphrases differ\n";
      return 1;
    }
    SdContext sdctx(args.Container(), args.WinCompatible());
    if (!sdctx.HashPhrase(args.HashName(), sdpw.Phrase(), sdpw.Size()))
    {
      std::cerr << "Sorry, the hash '" << args.HashName()
                << "' is not supported\n";
      return 1;
    }
    SdMount sd_mount(TmpMnt);
    if (!sd_mount.Good())
    {
      std::cerr << "ERROR: No more memory\n";
      return 1;
    }
    if (args.FSType() != NoFS)
      sd_mount.SetPhrase(sdpw.Phrase(), sdpw.Size());
    if (sdctx.Ready())
    {
      int slotno;
      unsigned int j = 0u;
      bool ok = true;
      char cmd[256];
      octet header_buf[HEADER_BLOCK_SIZE];
      octet stock1_buf[HEADER_BLOCK_SIZE];
      octet stock2_buf[HEADER_BLOCK_SIZE];
      octet backup_buf[HEADER_BLOCK_SIZE];
      octet sect_buf[SD_BLOCK_SIZE];
      Random rnd(args.RandomName());

      rnd.Gather(2u*HEADER_BLOCK_SIZE + SD_BLOCK_SIZE);
      rnd.Get(header_buf, HEADER_BLOCK_SIZE);
      if (!sdctx.InitHashCipher(args.CipherName()))
      {
        std::cerr << "Sorry, the cipher '" << args.CipherName()
                  << "' is not supported\n";
        return 1;
      }
      sdctx.SetWhiteTable(header_buf);
      sdctx.EncryptWhiteTable(header_buf);
      rnd.Get(stock1_buf, HEADER_BLOCK_SIZE);
      sdctx.EncryptWhiteTable(stock1_buf);
      memset(stock2_buf, 0, HEADER_BLOCK_SIZE);
      sdctx.EncryptWhiteTable(stock2_buf);
      memcpy(backup_buf, header_buf, HEADER_BLOCK_SIZE);
      sdctx.EncryptWhiteTable(backup_buf);
      sdctx.EncryptWhiteTable(backup_buf);
      if (!sdctx.Write(header_buf, HEADER_BLOCK_SIZE) ||
          !sdctx.Write(stock1_buf, HEADER_BLOCK_SIZE) ||
          !sdctx.Write(stock2_buf, HEADER_BLOCK_SIZE) ||
          !sdctx.Write(backup_buf, HEADER_BLOCK_SIZE))
      {
        std::cerr << "Error writing to file \"" << args.Container() << "\"\n";
        return 1;
      }
      rnd.Get(sect_buf, SD_BLOCK_SIZE);
      if (!sdctx.InitRealCipher(args.CipherName()))
      {
        std::cerr << "Sorry, the cipher '" << args.CipherName()
                  << "' is not supported\n";
        return 1;
      }
      while (ok && j < 4u)
      {
        sdctx.EncryptSector(sect_buf, j++);
        ok = sdctx.Write(sect_buf, SD_BLOCK_SIZE);
        if (j < 3u)
          rnd.GetLast(sect_buf, SD_BLOCK_SIZE);
        else
          memset(sect_buf, 0, SD_BLOCK_SIZE);
      }
      if (!ok)
      {
        std::cerr << "Error writing to file \"" << args.Container() << "\"\n";
        return 1;
      }
      for (j = 0u; ok && j < args.ContainerSize(); ++j)
      {
        memset(sect_buf, 0, SD_BLOCK_SIZE);
        sdctx.EncryptSector(sect_buf, j + 4u);
        ok = sdctx.Write(sect_buf, SD_BLOCK_SIZE);
      }
      if (args.FSType() != NoFS)
      {
        char* fsopt;
        switch (args.FSType())
        {
          case Ext2:
            fsopt = "ext2";
            break;
          case Ext3:
            fsopt = "ext2 -j";
            break;
          case ReiserFS:
            fsopt = "reiserfs";
            break;
          case Minix:
            fsopt = "minix";
            break;
          case MSDos:
          case VFat:
            fsopt = "msdos";
            break;
          default:
            fsopt = "ext2";
        }
        if (realpath(args.Container(), sd_mount.Filename()) == NULL)
        {
          std::cerr << "ERROR: Couldn't resolve container pathname\nerror: "
                    << strerror(errno) << "\n";
          return 1;
        }
        slotno = sd_mount.Mount();
        if (slotno == -1)
        {
          std::cerr << "ERROR: Couldn't open master file\nerror: "
                    << strerror(errno) << "\n";
          return 1;
        }
        else if (slotno <= 0)
        {
          std::cerr << "ERROR: No slot to mount (slotno = " << slotno << ")\n";
          return 1;
        }
        if (snprintf(cmd, 256ul, "%s -t %s /dev/scramdisk/vol%2.2d",
                     args.MkFSCommand(), fsopt, slotno) == -1)
        {
          std::cerr << "ERROR: Command too long\n";
          return 1;
        }
        if (seteuid(0) == 0 && setreuid(0, 0) == 0)
        {
          if (system(cmd) == -1)
          {
            std::cerr << "ERROR: Couldn't create file system\nerror: "
                      << strerror(errno) << "\n";
            return 1;
          }
        }
        else
        {
          std::cerr << "ERROR: Couldn't change user ID to super user\nerror: "
                    << strerror(errno) << "\n";
          return 1;
        }
        if (args.FSType() != MSDos && args.FSType() != VFat)
        {
          char tmpmnt[32];
          char device[32];
          char lostfound[64];
          sprintf(device, "/dev/scramdisk/vol%2.2d", slotno);
          sprintf(tmpmnt, "/tmp/sdmnt-%u", static_cast<unsigned int>(getpid()));
          strcpy(lostfound, tmpmnt);
          strcat(lostfound, "/lost+found");
          sleep(2);
          if (mkdir(tmpmnt, 0755) == -1)
          {
            std::cerr << "ERROR: Could not create mount point " << tmpmnt
                      << "\nerror: " << strerror(errno) << "\n";
            rmdir(tmpmnt);
            return 1;
          }
          if (args.FSType() == Ext3)
            fsopt = "ext3";
          if (mount(device, tmpmnt, fsopt, MS_MGC_VAL, NULL))
          {
            std::cerr << "ERROR: Could not mount device: '" << device
                      << "', dir '" << tmpmnt << "', fsopt '" << fsopt
                      << "'\nerror: " << strerror(errno) << "\n";
            rmdir(tmpmnt);
            return 1;
          }
          chown(tmpmnt, uid, gid);
          if (args.FSType() != Minix)
            chown(lostfound, uid, gid);
          errno = 0; // ignore errors of chown
          if (umount(tmpmnt))
          {
            std::cerr << "ERROR: Could not unmount device: " << device
                      << "\nerror: " << strerror(errno) << "\n";
            return 1;
          }
          if (rmdir(tmpmnt) == -1)
          {
            std::cerr << "ERROR: Could not remove mount point " << tmpmnt
                      << "\nerror: " << strerror(errno) << "\n";
            return 1;
          }
        }
      }
    }
    else
    {
      std::cerr << "Sorry, could'nt open \"" << args.Container() << "\"\n";
      return 1;
    }
  }
  return 0;
}
