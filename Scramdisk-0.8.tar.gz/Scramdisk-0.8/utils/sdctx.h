/*                             Scramdisk for Linux
 *                             ===================
 *
 *  $Id: sdctx.h,v 1.2 2005/08/11 20:49:32 huj Exp $
 *  Author: Hans-Ulrich Juettner
 *  Copyright (c) 2005 - Hans-Ulrich Juettner
 *
 *  Scramdisk for Linux is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  Scramdisk for Linux is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Scramdisk for Linux -- see the file COPYING. If not,
 *  write to the Free Software Foundation, Inc., 59 Temple Place,
 *  Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Scramdisk for Linux is a Windows container-compatible on-the-fly
 *  encryption system.  For details, see the Scramdisk World-Wide-Web page,
 *  `http://www.samsimpson.com/cryptography/scramdisk/', or send a mail to
 *  the Scramdisk for Linux developer <hans-ulrich.juettner@t-online.de>.
 *
 *  $Log: sdctx.h,v $
 *  Revision 1.2  2005/08/11 20:49:32  huj
 *  Changes for installation on Debian
 *
 *  Revision 1.1  2005/05/22 20:10:23  huj
 *  First public version 0.8.2
 *
 */

#ifndef SD_SDCONTEXT_H
#define SD_SDCONTEXT_H

#define SD_BLOCK_SIZE 512u
#define HEADER_BLOCK_SIZE 2048u
#define CHECK_BLOCK_SIZE 1536u
#define WHITE_TABLE_SIZE 1024u
#define MASTER_KEY_SIZE 32u
#define OFFSET_MASTER_KEY 1024
#define BACKUP_BLOCK_START 6144

#include <bits.h>

class Cipher;
class Digest;

enum SdMode {rd, wr};

class SdContext
{
  private:
    static const int head_crypt_steps;
    static const int sect_crypt_steps;
    int file_des;
    bool win_compatible;
    SdMode open_mode;
    Cipher* cipher;
    Digest* digest;
    octet* hash;
    octet* master_key;
    octet* white_table;

  public:
    SdContext(const char* file, bool win = false, SdMode mode = wr);
    ~SdContext();
    bool Ready() { return file_des != -1; }
    bool WinCompatible() { return win_compatible; }
    void SetWinCompatible(bool win) { win_compatible = win; }
    const octet* Hash() { return hash; }
    size_t BlockSize();
    bool HashPhrase(const char* name, const octet* phrase, size_t size);
    bool InitHashCipher(const char* name);
    bool InitRealCipher(const char* name);
    void SetWhiteTable(octet* buffer);
    void EncryptWhiteTable(octet* buffer);
    void DecryptWhiteTable(octet* buffer);
    void EncryptSector(octet* buffer, unsigned int sector_num);
    void DecryptSector(octet* buffer, unsigned int sector_num);
    bool Read(octet* buffer, size_t size);
    bool Write(octet* buffer, size_t size);
    bool Rewind();
};

#endif
