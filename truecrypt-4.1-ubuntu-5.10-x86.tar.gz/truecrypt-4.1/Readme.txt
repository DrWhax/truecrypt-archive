This archive contains TrueCrypt 4.1 binaries for Linux.


Requirements
============

The default Linux kernel that came with the Linux distribution for which this
package has been built for.



Installation
============

.RPM packages:
rpm -i truecrypt.rpm


.DEB packages:
dpkg -i truecrypt.deb



Non-Administrator Usage
=======================

TrueCrypt requires administrator (root) privileges. If you intend to
use TrueCrypt from a user account, you should execute the following command
as an administrator:

chmod u+s /usr/bin/truecrypt



Documentation
=============

http://www.truecrypt.org/documentation.php



What Is New in This Version of Truecrypt
========================================

For a comprehensive list of changes, please refer to the TrueCrypt User Guide
or visit http://www.truecrypt.org/history.php



Frequently Asked Questions
==========================

http://www.truecrypt.org/faq.php



Licensing Information
=====================

Before installing/running/using TrueCrypt, you must agree to the license
contained in the file 'License.txt'.



Further Information
===================

http://www.truecrypt.org

